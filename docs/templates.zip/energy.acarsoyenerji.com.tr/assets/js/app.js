$(function(){
	
	'use strict';

	var App = {};

	App.viewPadding = function()
	{
		$("#view").css({
			paddingTop: $("#header").outerHeight(),
			paddingBottom: $("#footer").outerHeight()
		});
	};

	$("#mobile-nav-open span").click(function(event){
		event.preventDefault();
		$("body").css("overflow","hidden");
		$("#md-mobilemenu").fadeIn();
	});

	$("#md-mobilemenu-close").click(function(event){
		event.preventDefault();
		$("body").css("overflow","");
		$("#md-mobilemenu").fadeOut();
	});

	$( window ).resize(function(event){
		App.viewPadding();
	})

	$( window ).load(function(event){
		App.viewPadding();
	});

});