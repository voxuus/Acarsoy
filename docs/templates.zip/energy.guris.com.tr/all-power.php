<!DOCTYPE html>
<html lang="en" dir="ltr">
	<head>
		<?php require_once 'include/head.php'; ?>
	</head>
	<body>
		<?php require_once 'include/header.php'; ?>
		<div class="analysis-header">
			<div class="colgroup col-middle">
				<div class="col-hd-6 col-lg-6">
					<div class="inline-item analysis-icon">
						<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 58 58" xml:space="preserve">
							<path style="fill: #ee6143;" d="M27,28.134V0.038C11.918,1.067,0,13.619,0,28.962C0,36.25,2.695,42.905,7.134,48L27,28.134z"/>
							<path style="fill: #26a783;" d="M31,26.962h26.924C56.94,12.541,45.421,1.022,31,0.038V26.962z"/>
							<path style="fill: #fdc44c;" d="M50.386,48.615c4.343-4.71,7.151-10.858,7.614-17.653H32.733L50.386,48.615z"/>
							<path style="fill: #00aeef;" d="M28.414,32.376L9.962,50.828c5.095,4.439,11.75,7.134,19.038,7.134 c6.99,0,13.396-2.479,18.401-6.599L28.414,32.376z"/>
						</svg>
					</div>
					<h1 class="inline-item">All Power <strong>Analysis</strong></h1>
				</div>
				<div class="col-hd-6 col-lg-6">
					<div class="analysis-close">
						<a href="index.php" title="Anasayfaya Dön">
							<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 47.971 47.971" style="enable-background:new 0 0 47.971 47.971;" xml:space="preserve">
								<path d="M28.228,23.986L47.092,5.122c1.172-1.171,1.172-3.071,0-4.242c-1.172-1.172-3.07-1.172-4.242,0L23.986,19.744L5.121,0.88 c-1.172-1.172-3.07-1.172-4.242,0c-1.172,1.171-1.172,3.071,0,4.242l18.865,18.864L0.879,42.85c-1.172,1.171-1.172,3.071,0,4.242 C1.465,47.677,2.233,47.97,3,47.97s1.535-0.293,2.121-0.879l18.865-18.864L42.85,47.091c0.586,0.586,1.354,0.879,2.121,0.879 s1.535-0.293,2.121-0.879c1.172-1.171,1.172-3.071,0-4.242L28.228,23.986z"/>
							</svg>
						</a>
					</div>
				</div>
			</div>
		</div>
		<div class="analysis-wrapper" id="all">
			<div class="colgroup">
				<div class="col-hd-4 col-lg-4">
					<div class="box-title notmargin">Cumulative Production vs Budget</div>
					<div class="box">
						<div id="chart-1"></div>
					</div>
				</div>
				<div class="col-hd-4 col-lg-4">
					<div class="box-title notmargin">Production and Los Production</div>
					<div class="box">
						<div id="chart-2"></div>
					</div>
				</div>
				<div class="col-hd-4 col-lg-4">
					<div class="box-title notmargin">Key Metrics</div>
					<div class="box key-metrics">
						<div class="middle">
							<h6>Production</h6>
							<h3><?php echo rand(50,99); ?>.<?php echo rand(0,99); ?> GWh</h3>
							<p>26,93 GWh (11.5%) below budget</p>
						</div>
					</div>
				</div>
			</div>
			<div class="colgroup">
				<div class="col-hd-12 col-lg-12">
					<h6 class="box-title">All Data</h6>
					<div class="box scroll" style="min-height: auto">
						<table class="warning-list">
							<thead>
								<tr>
									<th width="60">Site</th>
									<th width="40">#</th>
									<th width="175">Production</th>
									<th width="175">Lost Production</th>
									<th width="175">Yield</th>
									<th width="175">Availability</th>
									<th width="175">Latency</th>
								</tr>
							</thead>
							<tbody>
								<?php
									$number1 = rand(0,100);
									$number2 = rand(0,100);
									$number3 = rand(0,100);
									$number4 = rand(0,100);
									$number5 = rand(0,100);
								?>
								<tr class="wind">
									<td><span class="device">Wind</span></td>
									<td>10</td>
									<td>
										<div class="bar">
											<span><?php echo $number1; ?></span>
											<div class="percent" style="width: <?php echo $number1; ?>%;"></div>
										</div>
									</td>
									<td>
										<div class="bar">
											<span><?php echo $number2; ?></span>
											<div class="percent" style="width: <?php echo $number2; ?>%;"></div>
										</div>
									</td>
									<td>
										<div class="bar">
											<span><?php echo $number3; ?></span>
											<div class="percent" style="width: <?php echo $number3; ?>%;"></div>
										</div>
									</td>
									<td>
										<div class="bar">
											<span><?php echo $number4; ?></span>
											<div class="percent" style="width: <?php echo $number4; ?>%;"></div>
										</div>
									</td>
									<td>
										<div class="bar">
											<span><?php echo $number5; ?></span>
											<div class="percent" style="width: <?php echo $number5; ?>%;"></div>
										</div>
									</td>
								</tr>
								<?php
									$number1 = rand(0,100);
									$number2 = rand(0,100);
									$number3 = rand(0,100);
									$number4 = rand(0,100);
									$number5 = rand(0,100);
								?>
								<tr class="solar">
									<td><span class="device">Solar</span></td>
									<td>10</td>
									<td>
										<div class="bar">
											<span><?php echo $number1; ?></span>
											<div class="percent" style="width: <?php echo $number1; ?>%;"></div>
										</div>
									</td>
									<td>
										<div class="bar">
											<span><?php echo $number2; ?></span>
											<div class="percent" style="width: <?php echo $number2; ?>%;"></div>
										</div>
									</td>
									<td>
										<div class="bar">
											<span><?php echo $number3; ?></span>
											<div class="percent" style="width: <?php echo $number3; ?>%;"></div>
										</div>
									</td>
									<td>
										<div class="bar">
											<span><?php echo $number4; ?></span>
											<div class="percent" style="width: <?php echo $number4; ?>%;"></div>
										</div>
									</td>
									<td>
										<div class="bar">
											<span><?php echo $number5; ?></span>
											<div class="percent" style="width: <?php echo $number5; ?>%;"></div>
										</div>
									</td>
								</tr>
								<?php
									$number1 = rand(0,100);
									$number2 = rand(0,100);
									$number3 = rand(0,100);
									$number4 = rand(0,100);
									$number5 = rand(0,100);
								?>
								<tr class="hes">
									<td><span class="device">Hes</span></td>
									<td>10</td>
									<td>
										<div class="bar">
											<span><?php echo $number1; ?></span>
											<div class="percent" style="width: <?php echo $number1; ?>%;"></div>
										</div>
									</td>
									<td>
										<div class="bar">
											<span><?php echo $number2; ?></span>
											<div class="percent" style="width: <?php echo $number2; ?>%;"></div>
										</div>
									</td>
									<td>
										<div class="bar">
											<span><?php echo $number3; ?></span>
											<div class="percent" style="width: <?php echo $number3; ?>%;"></div>
										</div>
									</td>
									<td>
										<div class="bar">
											<span><?php echo $number4; ?></span>
											<div class="percent" style="width: <?php echo $number4; ?>%;"></div>
										</div>
									</td>
									<td>
										<div class="bar">
											<span><?php echo $number5; ?></span>
											<div class="percent" style="width: <?php echo $number5; ?>%;"></div>
										</div>
									</td>
								</tr>
								<?php
									$number1 = rand(0,100);
									$number2 = rand(0,100);
									$number3 = rand(0,100);
									$number4 = rand(0,100);
									$number5 = rand(0,100);
								?>
								<tr class="jes">
									<td><span class="device">Jes</span></td>
									<td>10</td>
									<td>
										<div class="bar">
											<span><?php echo $number1; ?></span>
											<div class="percent" style="width: <?php echo $number1; ?>%;"></div>
										</div>
									</td>
									<td>
										<div class="bar">
											<span><?php echo $number2; ?></span>
											<div class="percent" style="width: <?php echo $number2; ?>%;"></div>
										</div>
									</td>
									<td>
										<div class="bar">
											<span><?php echo $number3; ?></span>
											<div class="percent" style="width: <?php echo $number3; ?>%;"></div>
										</div>
									</td>
									<td>
										<div class="bar">
											<span><?php echo $number4; ?></span>
											<div class="percent" style="width: <?php echo $number4; ?>%;"></div>
										</div>
									</td>
									<td>
										<div class="bar">
											<span><?php echo $number5; ?></span>
											<div class="percent" style="width: <?php echo $number5; ?>%;"></div>
										</div>
									</td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
		<script type="text/javascript">
			App.chart.allPower();
			App.event.notshadow();
		</script>
	</body>
</html>