'use strict';

var App = {};

App.event = function()
{
	return {

		mapCategory: function()
		{
			$('#map-category a').click(function(event)
			{
				// Stop default events.
				event.preventDefault();

				// Clicked element.
				var el = $( this );

				if ( !el.hasClass('active') )
				{
					// Delete the active class of all elements.
					$('#map-category a').removeClass('active');

					// Add the active class to the clicked element.
					el.addClass('active');

					// Hide all .maximum-production and .map-total elements.
					$('.maximum-production, .map-total').fadeOut();

					// Get the type value of the clicked element.
					var type = el.attr('data-type');

					// Show graph and total elements according to the clicked element.
					$('#chart'+ type +', #total'+ type +'').fadeIn();
					$('.all-charts').removeClass('true');
					$('.all-charts#'+ type).addClass('true');
				}

			});
		},
		notshadow: function()
		{
			$('#gb-header').addClass('ns-yb');
		},
		unitsToggle: function()
		{
			$('#buttons .units').click(function(event)
			{
				// Stop default events.
				event.preventDefault();

				$('.blur').attr('data-blur', true);

				$('#units').addClass('active').fadeIn();
			});

			var unitsBoolen = false;

			$('#units-table tr').mouseenter(function(){

				var el    = $( this ),
					units = $('#units-sticky'),
					top   = el.offset().top,
					text1 = el.attr('data-text-1'),
					text2 = el.attr('data-text-2'),
					text3 = el.attr('data-text-3'),
					text4 = el.attr('data-text-4'),
					text5 = el.attr('data-text-5'),
					text6 = el.attr('data-text-6'),
					text7 = el.attr('data-text-7'),
					text8 = el.attr('data-text-8');

				unitsBoolen = true;
				
				var windowHeight = $( window ).outerHeight() - units.outerHeight();

				if ( windowHeight > top )
				{
					units.show().css('top', top);
				}
				else
				{
					units.show().css('top', top - ( units.outerHeight() - el.outerHeight()));
				}

				units.find('.data-text-1').html( text1 );
				units.find('.data-text-2').html( text2 );
				units.find('.data-text-3').html( text3 );
				units.find('.data-text-4').html( text4 );
				units.find('.data-text-5').html( text5 );
				units.find('.data-text-6').html( text6 );
				units.find('.data-text-7').html( text7 );
				units.find('.data-text-8').html( text8 );
			})

			$('#units-right').click(function()
			{
				if ( unitsBoolen === true )
				{
					unitsBoolen = false;
					$('#units-sticky').hide();
				}
				else
				{
					$('#units').removeClass('active').fadeOut();
					$('#units-sticky').hide();
					$('.blur').attr('data-blur', '');
				}
			});

			$('.allChartsClose').click(function( event ) {
				event.preventDefault();
				$('.all-charts').removeClass('active');
			});

			$('.allChartsOpen').click(function( event ) {
				event.preventDefault();
				$('.all-charts').removeClass('active');
				$('.all-charts.true').addClass('active');
			});
		}
	}

}();


$(function(){
	
	var bodySpace = function(){

		$('body').css({
			paddingTop: $('#gb-header').outerHeight()
		});
	}

	var sidebar = function(){

		$('#analysis-nav li a').click(function(event){

			if ( !$( this ).parents('ul').hasClass('clicked') )
			{
				event.preventDefault();
				$( this ).parents('ul').addClass('clicked');

				$( this ).parents('ul').children('li').show();
			}
		});
	}

	if ( $( window ).outerWidth() < 1199 )
	{
		// Run the bodySpace function.
		sidebar();
	}

	$( window )

	.resize(function(){

		// Run the bodySpace function.
		bodySpace();

		if ( $( window ).outerWidth() < 1199 )
		{
			// Run the bodySpace function.
			sidebar();
		}

	})
	.load(function(){

		// Run the bodySpace function.
		bodySpace();
	})

});