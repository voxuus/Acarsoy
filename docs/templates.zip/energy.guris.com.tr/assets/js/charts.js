App.chart = function()
{
	return {

		maximumProduction: function()
		{
			function chart(id, title, color, val)
			{
				Highcharts.chart(id,
				{
					chart:
					{
						type   : "column",
						height : 250,
						marginTop: 55,
						spacing: [10, 20, 20, 20]
					},
					credits:
					{
						enabled: false
					},
					legend:
					{
						enabled: false
					},
					title:
					{
						text: title,
						style:
						{
							"color"     : "#454545",
							"fontSize"  : "11.2px"
						},
						widthAdjust: -5,
						margin: 0,
						y: 12
					},
					xAxis:
					{
						visible: false
					},
					plotOptions:
					{
						column:
						{
							stacking: "normal"
						}
					},
					yAxis: {
						tickAmount: 6,
						min: 0,
						max: 20,
						showFirstLabel: false,
						labels: {
							style:
							{
								"color"     : "#454545",
								"fontSize"  : "10px"
							}
						},
						title: {
							text: false
						},
						opposite: true
					},
					series:
					[
						{
							name: '',
							enableMouseTracking: false,
							color: '#eee',
							data: [20 - val]
						},
						{
							name: 'All',
							color: color,
							data: [val]
						}
					]
				});
			}

			chart('chartall','Maksimum Üretim','#1b252c', 15);
			chart('chartwind','Wind Üretim','#26a783', 15);
			chart('chartsolar','Solar Üretim','#fdc44c', 15);
			chart('charthes','Hes Üretim','#00aeef', 15);
			chart('chartjes','Jes Üretim','#ee6143', 15);
		},
		allCharts: function()
		{
			function chart(id, val)
			{
				Highcharts.chart(id,
				{
					chart:
					{
						type   : "bar",
						marginTop: 20,
						height: 400,
						spacing: [10, 1, 20, 0]
					},
					credits:
					{
						enabled: false
					},
					legend:
					{
						enabled: false
					},
					title:
					{
						text: '',
					},
					xAxis:
					{
						visible: false
					},
					plotOptions:
					{
						bar: {
							dataLabels: {
								enabled: true
							}
						}
					},
					yAxis: {
						tickAmount: 6,
						min: 0,
						max: 100,
						labels: {
							style:
							{
								"color"     : "#454545",
								"fontSize"  : "10px"
							}
						},
						title: {
							text: false
						},
						opposite: true
					},
					series: val
				});
			}

			chart('chartAll', [
				{
					name: 'Wind 1',
					color: '#26a783',
					data: [15]
				},
				{
					name: 'Wind 2',
					color: '#26a783',
					data: [25]
				},
				{
					name: 'Wind 3',
					color: '#26a783',
					data: [20]
				},
				{
					name: 'Wind 4',
					color: '#26a783',
					data: [60]
				},
				{
					name: 'Wind 5',
					color: '#26a783',
					data: [13]
				},
				{
					name: 'Solar 1',
					color: '#fdc44c',
					data: [15]
				},
				{
					name: 'Solar 2',
					color: '#fdc44c',
					data: [25]
				},
				{
					name: 'Solar 3',
					color: '#fdc44c',
					data: [20]
				},
				{
					name: 'Solar 4',
					color: '#fdc44c',
					data: [60]
				},
				{
					name: 'Solar 5',
					color: '#fdc44c',
					data: [13]
				},
				{
					name: 'Hes 1',
					color: '#00aeef',
					data: [15]
				},
				{
					name: 'Hes 2',
					color: '#00aeef',
					data: [25]
				},
				{
					name: 'Hes 3',
					color: '#00aeef',
					data: [20]
				},
				{
					name: 'Hes 4',
					color: '#00aeef',
					data: [60]
				},
				{
					name: 'Hes 5',
					color: '#00aeef',
					data: [13]
				},
				{
					name: 'Jes 1',
					color: '#ee6143',
					data: [15]
				},
				{
					name: 'Jes 2',
					color: '#ee6143',
					data: [25]
				},
				{
					name: 'Jes 3',
					color: '#ee6143',
					data: [20]
				},
				{
					name: 'Jes 4',
					color: '#ee6143',
					data: [60]
				},
				{
					name: 'Jes 5',
					color: '#ee6143',
					data: [13]
				}
			]);

			chart('chartWind', [
				{
					name: 'Wind 1',
					color: '#26a783',
					data: [15]
				},
				{
					name: 'Wind 2',
					color: '#26a783',
					data: [25]
				},
				{
					name: 'Wind 3',
					color: '#26a783',
					data: [20]
				},
				{
					name: 'Wind 4',
					color: '#26a783',
					data: [60]
				},
				{
					name: 'Wind 5',
					color: '#26a783',
					data: [13]
				}
			]);

			chart('chartSolar', [
				{
					name: 'Solar 1',
					color: '#fdc44c',
					data: [15]
				},
				{
					name: 'Solar 2',
					color: '#fdc44c',
					data: [25]
				},
				{
					name: 'Solar 3',
					color: '#fdc44c',
					data: [20]
				},
				{
					name: 'Solar 4',
					color: '#fdc44c',
					data: [60]
				},
				{
					name: 'Solar 5',
					color: '#fdc44c',
					data: [13]
				}
			]);

			chart('chartHes', [
				{
					name: 'Hes 1',
					color: '#00aeef',
					data: [15]
				},
				{
					name: 'Hes 2',
					color: '#00aeef',
					data: [25]
				},
				{
					name: 'Hes 3',
					color: '#00aeef',
					data: [20]
				},
				{
					name: 'Hes 4',
					color: '#00aeef',
					data: [60]
				},
				{
					name: 'Hes 5',
					color: '#00aeef',
					data: [13]
				}
			]);

			chart('chartJes', [
				{
					name: 'Jes 1',
					color: '#ee6143',
					data: [15]
				},
				{
					name: 'Jes 2',
					color: '#ee6143',
					data: [25]
				},
				{
					name: 'Jes 3',
					color: '#ee6143',
					data: [20]
				},
				{
					name: 'Jes 4',
					color: '#ee6143',
					data: [60]
				},
				{
					name: 'Jes 5',
					color: '#ee6143',
					data: [13]
				}
			]);
		},
		allPower: function()
		{
			Highcharts.chart('chart-1', {
				chart: {
					type: 'area',
					marginTop: 60,
					height: 330
				},
				credits: {
					enabled: false
				},
				labels: {
					style: { "color": "#757575", "font-size": "12px" }
				},
				legend: {
					align: 'center',
					verticalAlign: 'top',
					padding: 8,
					margin: 0,
					reversed: true,
				},
				title: {
					text: false
				},
				xAxis: {
					categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
					lineWidth: 0,
					labels: {
						autoRotation: 0,
						padding: 0
					}
				},
				yAxis: [{
					tickAmount: 6,
					min: 0,
					max: 100,
					showFirstLabel: false,
					title: {
						text: false
					}
				},
				{
					tickAmount: 6,
					min: 0,
					max: 100,
					showFirstLabel: false,
					title: {
						text: false
					},
					opposite: true
				}],
				plotOptions: {
					area: {
						marker: {
							enabled: false,
							symbol: 'circle',
							radius: 2,
							states: {
								hover: {
									enabled: true
								}
							}
						}
					}
				},
				series: [{
					lineWidth: 0,
					color: '#333333',
					fillOpacity: 0.5,
					name: 'Actual 206 252 MWh',
					data: [6, 16, 26, 36, 46, 56, 66, 76, 86, 96, 86, 96]
				}, {
					color: '#1d2830',
					fillOpacity: 0.5,
					name: 'Budget 233 184 MWh',
					data: [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 80, 90]
				}]
			});

			Highcharts.chart('chart-2', {
				chart: {
					type: 'column',
					marginTop: 60,
					height: 330
				},
				credits: {
					enabled: false
				},
				labels: {
					style: { "color": "#757575" }
				},
				legend: {
					align: 'center',
					verticalAlign: 'top',
					padding: 8,
					margin: 0,
					reversed: true,
				},
				title: {
					text: false
				},
				xAxis: {
					categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
					lineWidth: 0,
					labels: {
						autoRotation: 0,
						padding: 0
					}
				},
				yAxis: {
					tickAmount: 7,
					min: 0,
					max: 15,
					showFirstLabel: false,
					title: {
						text: false
					}
				},
				plotOptions: {
					column: {
						stacking: 'normal',
						borderWidth: 0,
						cropThreshold: 100
					}
				},
				series: [{
					color: '#ea717a',
					name: 'Lost Production',
					data: [5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
				}, {
					color: '#68bfaa',
					name: 'Production',
					data: [5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
				}]
			});
		},
		solar: function()
		{
			Highcharts.chart('chart-1', {
				chart: {
					type: 'line',
					height: 330,
					marginTop: 60
				},
				credits: {
					enabled: false
				},
				labels: {
					style: { "color": "#757575" }
				},
				legend: {
					align: 'center',
					verticalAlign: 'top',
					padding: 8,
					margin: 0,
					reversed: true,
				},
				title: {
					text: false
				},
				xAxis: {
					categories: ['10', '12', '14', '16', '18', '20', '22', '00', '02', '04', '06', '08'],
					lineWidth: 0,
					labels: {
						autoRotation: 0,
						padding: 0
					}
				},
				yAxis: [
					{
						tickAmount: 6,
						min: 0,
						max: 500,
						showFirstLabel: false,
						title: {
							text: false
						}
					},
					{
						tickAmount: 6,
						min: 0,
						max: 100,
						showFirstLabel: false,
						title: {
							text: false
						},
						opposite: true
					}
				],
				title: {
					text: false
				},
				series: [{
					color: 'rgb(104, 191, 170)',
					name: 'Flow',
					data: [[0, 50],[1, 120],[5, 270],[11, 0]],
					marker: {
						enabled: false
					},
					states: {
						hover: {
							lineWidth: 0
						}
					}
				}, {
					color: 'rgb(234, 113, 122)',
					name: 'Pressure',
					data: [[0, 155],[1, 60],[5, 400],[11, 100]],
					marker: {
						enabled: false
					},
					states: {
						hover: {
							lineWidth: 0
						}
					}
				}, {
					color: 'rgb(253, 196, 76)',
					name: 'Temperature',
					data: [[0, 15],[1, 100],[5, 80],[11, 0]],
					marker: {
						enabled: false
					},
					states: {
						hover: {
							lineWidth: 0
						}
					}
				}]
			});

			Highcharts.chart('chart-2', {
				chart: {
					type: 'column',
					height: 330,
					marginTop: 60
				},
				credits: {
					enabled: false
				},
				labels: {
					style: { "color": "#757575" }
				},
				legend: {
					enabled: false
				},
				title: {
					text: '14.4 kW',
					style: { "color": "#757575", "fontSize": "16px" },
					margin: 0,
					y: 25
				},
				xAxis: {
					categories: ['POWER'],
					lineWidth: 0,
					labels: {
						autoRotation: 0,
						padding: 0
					}
				},
				yAxis: [{
					tickAmount: 6,
					min: 0,
					max: 500,
					showFirstLabel: false,
					title: {
						text: false
					}
				}, {
					tickAmount: 6,
					min: 0,
					max: 500,
					showFirstLabel: false,
					title: {
						text: false
					},
					opposite: true
				}],
				plotOptions: {
					column: {
						stacking: 'normal'
					}
				},
				series: [
					{
						color: 'rgba(253, 196, 76, 0.4)',
						data: [250]
					}, {
						color: 'rgb(253, 196, 76)',
						data: [250]
					}
				]
			});

			Highcharts.chart('chart-3', {
				chart: {
					type: 'area',
					marginTop: 60,
					height: 330
				},
				credits: {
					enabled: false
				},
				labels: {
					style: { "color": "#757575", "font-size": "12px" }
				},
				legend: {
					align: 'center',
					verticalAlign: 'top',
					padding: 8,
					margin: 0,
					reversed: true,
				},
				title: {
					text: false
				},
				xAxis: {
					categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
					lineWidth: 0,
					labels: {
						autoRotation: 0,
						padding: 0
					}
				},
				yAxis: [{
					tickAmount: 6,
					min: 0,
					max: 100,
					showFirstLabel: false,
					title: {
						text: false
					}
				},
				{
					tickAmount: 6,
					min: 0,
					max: 100,
					showFirstLabel: false,
					title: {
						text: false
					},
					opposite: true
				}],
				plotOptions: {
					area: {
						marker: {
							enabled: false,
							symbol: 'circle',
							radius: 2,
							states: {
								hover: {
									enabled: true
								}
							}
						}
					}
				},
				series: [{
					color: 'rgb(253, 196, 76)',
					fillOpacity: 0.5,
					name: 'Production 18.38 MWh',
					data: [0, 16, 26, 36, 46, 56, 66, 76, 86, 96, 86, 96]
				}]
			});

			Highcharts.chart('chart-4', {
				chart: {
					type: 'column',
					marginTop: 60,
					height: 330
				},
				credits: {
					enabled: false
				},
				labels: {
					style: { "color": "#757575" }
				},
				legend: {
					align: 'center',
					verticalAlign: 'top',
					padding: 8,
					margin: 0,
					reversed: true,
				},
				title: {
					text: false
				},
				xAxis: {
					categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
					lineWidth: 0,
					labels: {
						autoRotation: 0,
						padding: 0
					}
				},
				yAxis: {
					tickAmount: 7,
					min: 0,
					max: 15,
					showFirstLabel: false,
					title: {
						text: false
					}
				},
				plotOptions: {
					column: {
						stacking: 'normal',
						borderWidth: 0,
						cropThreshold: 100
					}
				},
				series: [{
					color: '#ea717a',
					name: 'Lost Production',
					data: [5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
				}, {
					color: 'rgb(253, 196, 76)',
					name: 'Production',
					data: [5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
				}]
			});

			Highcharts.chart('chart-5', {
				chart: {
					marginTop: 60
				},
				credits: {
					enabled: false
				},
				labels: {
					style: { "color": "#757575" }
				},
				legend: {
					align: 'center',
					verticalAlign: 'top',
					padding: 8,
					margin: 0,
					reversed: true,
				},
				title: {
					text: false
				},
				xAxis: {
					categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
					lineWidth: 0,
					labels: {
						autoRotation: 0,
						padding: 0
					}
				},
				yAxis: {
					tickAmount: 6,
					min: 95,
					max: 100,
					showFirstLabel: false,
					title: {
						text: false
					}
				},
				title: {
					text: false
				},
				series: [
					{
						type: 'line',
						color: '#68bfaa',
						lineWidth: 1,
						name: 'Avg. 97.89%',
						dashStyle: 'Dash',
						data: [[0, 97.89],[11, 97.89]],
						marker: {
							enabled: false
						},
						states: {
							hover: {
								lineWidth: 0
							}
						}
					},
					{
						type: 'line',
						color: '#68bfaa',
						name: 'Data Availability',
						data: [[1, 95],[0, 99.3]],
						marker: {
							enabled: false
						},
						states: {
							hover: {
								lineWidth: 0
							}
						}
					}
				]
			});

			Highcharts.chart('chart-6', {
				chart: {
					type: 'column',
					marginTop: 60
				},
				credits: {
					enabled: false
				},
				labels: {
					style: { "color": "#757575" }
				},
				legend: {
					align: 'center',
					verticalAlign: 'top',
					padding: 8,
					margin: 0,
					reversed: true,
				},
				title: {
					text: false
				},
				xAxis: {
					categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
					lineWidth: 0,
					labels: {
						autoRotation: 0,
						padding: 0
					}
				},
				yAxis: {
					tickAmount: 6,
					min: 0,
					max: 100,
					showFirstLabel: false,
					title: {
						text: false
					}
				},
				plotOptions: {
					column: {
						borderWidth: 0,
					}
				},
				series: [
					{
						type: 'line',
						color: 'rgb(253, 196, 76)',
						name: 'Target N/A',
						data: null,
						marker: {
							enabled: false
						},
						states: {
							hover: {
								lineWidth: 0
							}
						}
					},
					{
						type: 'line',
						color: 'rgb(253, 196, 76)',
						lineWidth: 1,
						name: 'Avg. 5%',
						dashStyle: 'Dash',
						data: [[0, 5],[11, 4]],
						marker: {
							enabled: false
						},
						states: {
							hover: {
								lineWidth: 0
							}
						}
					},
					{
						color: 'rgb(253, 196, 76)',
						name: 'Avality',
						data: [35,25, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
					}
				]
			});

			Highcharts.chart('chart-7', {
				chart: {
					type: 'column',
					marginTop: 60
				},
				credits: {
					enabled: false
				},
				labels: {
					style: { "color": "#757575" }
				},
				legend: {
					align: 'center',
					verticalAlign: 'top',
					padding: 8,
					margin: 0,
					reversed: true,
				},
				title: {
					text: false
				},
				xAxis: {
					categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
					lineWidth: 0,
					labels: {
						autoRotation: 0,
						padding: 0
					}
				},
				yAxis: {
					tickAmount: 5,
					min: 0,
					max: 8,
					showFirstLabel: false,
					title: {
						text: false
					}
				},
				plotOptions: {
					column: {
						borderWidth: 0,
					}
				},
				series: [
					{
						type: 'line',
						color: 'rgb(253, 196, 76)',
						lineWidth: 1,
						name: 'Avg. 5%',
						dashStyle: 'Dash',
						data: [[0, 5],[11, 5]],
						marker: {
							enabled: false
						},
						states: {
							hover: {
								lineWidth: 0
							}
						}
					},
					{
						color: 'rgb(253, 196, 76)',
						name: 'Yield',
						data: [4,5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
					}
				]
			});
		},
		jes: function()
		{
			Highcharts.chart('chart-1', {
				chart: {
					type: 'line',
					height: 330,
					marginTop: 60
				},
				credits: {
					enabled: false
				},
				labels: {
					style: { "color": "#757575" }
				},
				legend: {
					align: 'center',
					verticalAlign: 'top',
					padding: 8,
					margin: 0,
					reversed: true,
				},
				title: {
					text: false
				},
				xAxis: {
					categories: ['10', '12', '14', '16', '18', '20', '22', '00', '02', '04', '06', '08'],
					lineWidth: 0,
					labels: {
						autoRotation: 0,
						padding: 0
					}
				},
				yAxis: [
					{
						tickAmount: 6,
						min: 0,
						max: 500,
						showFirstLabel: false,
						title: {
							text: false
						}
					},
					{
						tickAmount: 6,
						min: 0,
						max: 100,
						showFirstLabel: false,
						title: {
							text: false
						},
						opposite: true
					}
				],
				title: {
					text: false
				},
				series: [{
					color: 'rgb(104, 191, 170)',
					name: 'Flow',
					data: [[0, 50],[1, 120],[5, 270],[11, 0]],
					marker: {
						enabled: false
					},
					states: {
						hover: {
							lineWidth: 0
						}
					}
				}, {
					color: 'rgb(234, 113, 122)',
					name: 'Pressure',
					data: [[0, 155],[1, 60],[5, 400],[11, 100]],
					marker: {
						enabled: false
					},
					states: {
						hover: {
							lineWidth: 0
						}
					}
				}, {
					color: 'rgb(238, 97, 67)',
					name: 'Temperature',
					data: [[0, 15],[1, 100],[5, 80],[11, 0]],
					marker: {
						enabled: false
					},
					states: {
						hover: {
							lineWidth: 0
						}
					}
				}]
			});

			Highcharts.chart('chart-2', {
				chart: {
					type: 'column',
					height: 330,
					marginTop: 60
				},
				credits: {
					enabled: false
				},
				labels: {
					style: { "color": "#757575" }
				},
				legend: {
					enabled: false
				},
				title: {
					text: '14.4 kW',
					style: { "color": "#757575", "fontSize": "16px" },
					margin: 0,
					y: 25
				},
				xAxis: {
					categories: ['POWER'],
					lineWidth: 0,
					labels: {
						autoRotation: 0,
						padding: 0
					}
				},
				yAxis: [{
					tickAmount: 6,
					min: 0,
					max: 500,
					showFirstLabel: false,
					title: {
						text: false
					}
				}, {
					tickAmount: 6,
					min: 0,
					max: 500,
					showFirstLabel: false,
					title: {
						text: false
					},
					opposite: true
				}],
				plotOptions: {
					column: {
						stacking: 'normal'
					}
				},
				series: [
					{
						color: 'rgba(238, 97, 67, 0.4)',
						data: [250]
					}, {
						color: 'rgb(238, 97, 67)',
						data: [250]
					}
				]
			});

			Highcharts.chart('chart-3', {
				chart: {
					type: 'area',
					marginTop: 60,
					height: 330
				},
				credits: {
					enabled: false
				},
				labels: {
					style: { "color": "#757575", "font-size": "12px" }
				},
				legend: {
					align: 'center',
					verticalAlign: 'top',
					padding: 8,
					margin: 0,
					reversed: true,
				},
				title: {
					text: false
				},
				xAxis: {
					categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
					lineWidth: 0,
					labels: {
						autoRotation: 0,
						padding: 0
					}
				},
				yAxis: [{
					tickAmount: 6,
					min: 0,
					max: 100,
					showFirstLabel: false,
					title: {
						text: false
					}
				},
				{
					tickAmount: 6,
					min: 0,
					max: 100,
					showFirstLabel: false,
					title: {
						text: false
					},
					opposite: true
				}],
				plotOptions: {
					area: {
						marker: {
							enabled: false,
							symbol: 'circle',
							radius: 2,
							states: {
								hover: {
									enabled: true
								}
							}
						}
					}
				},
				series: [{
					color: 'rgb(238, 97, 67)',
					fillOpacity: 0.5,
					name: 'Production 18.38 MWh',
					data: [0, 16, 26, 36, 46, 56, 66, 76, 86, 96, 86, 96]
				}]
			});

			Highcharts.chart('chart-4', {
				chart: {
					type: 'column',
					marginTop: 60,
					height: 330
				},
				credits: {
					enabled: false
				},
				labels: {
					style: { "color": "#757575" }
				},
				legend: {
					align: 'center',
					verticalAlign: 'top',
					padding: 8,
					margin: 0,
					reversed: true,
				},
				title: {
					text: false
				},
				xAxis: {
					categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
					lineWidth: 0,
					labels: {
						autoRotation: 0,
						padding: 0
					}
				},
				yAxis: {
					tickAmount: 7,
					min: 0,
					max: 15,
					showFirstLabel: false,
					title: {
						text: false
					}
				},
				plotOptions: {
					column: {
						stacking: 'normal',
						borderWidth: 0,
						cropThreshold: 100
					}
				},
				series: [{
					color: '#ea717a',
					name: 'Lost Production',
					data: [5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
				}, {
					color: 'rgb(238, 97, 67)',
					name: 'Production',
					data: [5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
				}]
			});

			Highcharts.chart('chart-5', {
				chart: {
					marginTop: 60
				},
				credits: {
					enabled: false
				},
				labels: {
					style: { "color": "#757575" }
				},
				legend: {
					align: 'center',
					verticalAlign: 'top',
					padding: 8,
					margin: 0,
					reversed: true,
				},
				title: {
					text: false
				},
				xAxis: {
					categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
					lineWidth: 0,
					labels: {
						autoRotation: 0,
						padding: 0
					}
				},
				yAxis: {
					tickAmount: 6,
					min: 95,
					max: 100,
					showFirstLabel: false,
					title: {
						text: false
					}
				},
				title: {
					text: false
				},
				series: [
					{
						type: 'line',
						color: '#68bfaa',
						lineWidth: 1,
						name: 'Avg. 97.89%',
						dashStyle: 'Dash',
						data: [[0, 97.89],[11, 97.89]],
						marker: {
							enabled: false
						},
						states: {
							hover: {
								lineWidth: 0
							}
						}
					},
					{
						type: 'line',
						color: 'rgb(238, 97, 67)',
						name: 'Data Availability',
						data: [[1, 95],[0, 99.3]],
						marker: {
							enabled: false
						},
						states: {
							hover: {
								lineWidth: 0
							}
						}
					}
				]
			});

			Highcharts.chart('chart-6', {
				chart: {
					type: 'column',
					marginTop: 60
				},
				credits: {
					enabled: false
				},
				labels: {
					style: { "color": "#757575" }
				},
				legend: {
					align: 'center',
					verticalAlign: 'top',
					padding: 8,
					margin: 0,
					reversed: true,
				},
				title: {
					text: false
				},
				xAxis: {
					categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
					lineWidth: 0,
					labels: {
						autoRotation: 0,
						padding: 0
					}
				},
				yAxis: {
					tickAmount: 6,
					min: 0,
					max: 100,
					showFirstLabel: false,
					title: {
						text: false
					}
				},
				plotOptions: {
					column: {
						borderWidth: 0,
					}
				},
				series: [
					{
						type: 'line',
						color: 'rgb(238, 97, 67)',
						name: 'Target N/A',
						data: null,
						marker: {
							enabled: false
						},
						states: {
							hover: {
								lineWidth: 0
							}
						}
					},
					{
						type: 'line',
						color: 'rgb(238, 97, 67)',
						lineWidth: 1,
						name: 'Avg. 5%',
						dashStyle: 'Dash',
						data: [[0, 5],[11, 4]],
						marker: {
							enabled: false
						},
						states: {
							hover: {
								lineWidth: 0
							}
						}
					},
					{
						color: 'rgb(238, 97, 67)',
						name: 'Avality',
						data: [35,25, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
					}
				]
			});

			Highcharts.chart('chart-7', {
				chart: {
					type: 'column',
					marginTop: 60
				},
				credits: {
					enabled: false
				},
				labels: {
					style: { "color": "#757575" }
				},
				legend: {
					align: 'center',
					verticalAlign: 'top',
					padding: 8,
					margin: 0,
					reversed: true,
				},
				title: {
					text: false
				},
				xAxis: {
					categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
					lineWidth: 0,
					labels: {
						autoRotation: 0,
						padding: 0
					}
				},
				yAxis: {
					tickAmount: 5,
					min: 0,
					max: 8,
					showFirstLabel: false,
					title: {
						text: false
					}
				},
				plotOptions: {
					column: {
						borderWidth: 0,
					}
				},
				series: [
					{
						type: 'line',
						color: 'rgb(238, 97, 67)',
						lineWidth: 1,
						name: 'Avg. 5%',
						dashStyle: 'Dash',
						data: [[0, 5],[11, 5]],
						marker: {
							enabled: false
						},
						states: {
							hover: {
								lineWidth: 0
							}
						}
					},
					{
						color: 'rgb(238, 97, 67)',
						name: 'Yield',
						data: [4,5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
					}
				]
			});
		},
		wind: function()
		{
			Highcharts.chart('chart-1', {
				chart: {
					type: 'line',
					height: 330,
					marginTop: 60
				},
				credits: {
					enabled: false
				},
				labels: {
					style: { "color": "#757575" }
				},
				legend: {
					align: 'center',
					verticalAlign: 'top',
					padding: 8,
					margin: 0,
					reversed: true,
				},
				title: {
					text: false
				},
				xAxis: {
					categories: ['10', '12', '14', '16', '18', '20', '22', '00', '02', '04', '06', '08'],
					lineWidth: 0,
					labels: {
						autoRotation: 0,
						padding: 0
					}
				},
				yAxis: [
					{
						tickAmount: 6,
						min: 0,
						max: 500,
						showFirstLabel: false,
						title: {
							text: false
						}
					},
					{
						tickAmount: 6,
						min: 0,
						max: 100,
						showFirstLabel: false,
						title: {
							text: false
						},
						opposite: true
					}
				],
				title: {
					text: false
				},
				series: [{
					color: 'rgb(104, 191, 170)',
					name: 'Flow',
					data: [[0, 50],[1, 120],[5, 270],[11, 0]],
					marker: {
						enabled: false
					},
					states: {
						hover: {
							lineWidth: 0
						}
					}
				}, {
					color: 'rgb(234, 113, 122)',
					name: 'Pressure',
					data: [[0, 155],[1, 60],[5, 400],[11, 100]],
					marker: {
						enabled: false
					},
					states: {
						hover: {
							lineWidth: 0
						}
					}
				}, {
					color: 'rgb(253, 196, 76)',
					name: 'Temperature',
					data: [[0, 15],[1, 100],[5, 80],[11, 0]],
					marker: {
						enabled: false
					},
					states: {
						hover: {
							lineWidth: 0
						}
					}
				}]
			});
		}
	}
}();