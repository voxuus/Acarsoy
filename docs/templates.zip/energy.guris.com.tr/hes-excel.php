<!DOCTYPE html>
<html lang="en" dir="ltr">
	<head>
		<?php require_once 'include/head.php'; ?>
	</head>
	<body>
		<?php require_once 'include/header.php'; ?>
		<?php
			$rand  = rand(0,100);
			$title = rand(0,8);
		?>
		<script type="text/javascript">
			$(function(){

				$('body').css('background-image','url("assets/images/main/excel3.jpg")');
				$('#prev').show();

				Highcharts.chart('excel-chart', {
					chart: {
						plotBackgroundColor: null,
						plotBorderWidth: 0,
						plotShadow: false,
						backgroundColor: 'rgba(255,255,255,0)'
					},
					credits: {
						enabled: false
					},
					title: {
						text: '%<?php echo $rand; ?><br><span style="font-size: 20px; color: #fdc44c; display: block">TOPLAM</span>',
						align: 'center',
						verticalAlign: 'middle',
						y: 0,
						margin: 0,
						style: { "color": "#ffffff", "fontSize": "70px", "fontWeight": "200" }
					},
					tooltip: {
						pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
					},
					plotOptions: {
						pie: {
							dataLabels: {
								enabled: true,
								distance: 0
							},
							startAngle: -360,
							endAngle: 0,
							center: ['50%', '50%']
						}
					},
					series: [{
						type: 'pie',
						name: 'Analysis',
						innerSize: '97%',
						borderWidth: 0,
						data: [
							['', <?php echo $rand; ?>],
							['', <?php echo 100 - $rand; ?>]
						]
					}]
				});
			});
		</script>
		<div id="excel" class="hes">
			<a href="" title="" class="export">CSV’ye Aktar</a>
			<a href="" title="" class="icon"><img src="assets/images/icon/hes.png" alt=""></a>
			<h1>Hes Title</h1>
			<table>
				<thead>
					<tr>
						<th></th>
						<th>UNIT 1</th>
						<th>UNIT 2</th>
						<th>UNIT 3</th>
					</tr>
				</thead>
				<tbody>
					<?php for ($i=0; $i < 15; $i++) { ?>
					<tr>
						<td width="120">Sıcaklık</td>
						<td>20.80A</td>
						<td>22.06A</td>
						<td>23.45A</td>
					</tr>
					<?php } ?>
				</tbody>
			</table>
		</div>
		<div id="excel-chart"></div>
	</body>
</html>