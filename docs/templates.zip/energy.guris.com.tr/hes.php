<!DOCTYPE html>
<html lang="en" dir="ltr">
	<head>
		<?php require_once 'include/head.php'; ?>
	</head>
	<body>
		<?php require_once 'include/header.php'; ?>
		<?php
			function linear( $max, $value )
			{
				$red    = '#fb005e';
				$yellow = '#fbf74f';
				$green  = '#04e26e';
				$orange = '#fdb63a';

				$max = $max / 4;

				if ( $value <= ( $max * 1) )
				{
					return '[[0, "'.$red.'"]]';
				}
				else
				{
					if ( $value <= ( $max * 2) )
					{
						return '[[0, "'.$orange.'"], [1, "'.$red.'"]]';
					}
					else
					{
						if ( $value <= ( $max * 3) )
						{
							return '[[0, "'.$orange.'"], [1, "'.$red.'"], [2, "'.$yellow.'"]]';
						}
						else
						{
							return '[[0, "'.$orange.'"], [1, "'.$red.'"], [2, "'.$yellow.'"]]';
						}
					}
				}
			};

			function charts( $id, $title, $array )
			{
				if ( @$array['yAxisDouble'] === true )
				{
					$yAxis = '
						[{
							tickAmount: '.$array["tickAmount"].',
							min: 0,
							max: '.$array["maxValue"].',
							title: {
								text: false
							}
						},
						{
							tickAmount: '.$array["tickAmount"].',
							min: 0,
							max: '.$array["maxValue"].',
							title: {
								text: false
							},
							opposite: true
						}]
					';
				}
				else
				{
					$yAxis = '
						{
							tickAmount: '.$array["tickAmount"].',
							min: 0,
							max: '.$array["maxValue"].',
							title: {
								text: false
							},
							opposite: true
						}
					';
				}

				return '
				Highcharts.chart("'.$id.'",
				{
					chart:
					{
						type   : "column",
						height : 330,
						margin : [55, 35, 40, 35],
						spacing: [0, 0, 0, 0],
					},
					credits:
					{
						enabled: false
					},
					legend:
					{
						enabled: false
					},
					plotOptions:
					{
						column:
						{
							stacking: "normal",
							groupPadding: 0.3
						}
					},
					title:
					{
						text: \'<span style="font-weight: 700">'.$title.'</span>\',
						style:
						{
							"color"     : "#454545",
							"fontSize"  : "11.2px"
						},
						widthAdjust: -5,
						margin: 0,
						y: 25
					},
					xAxis:
					{
						categories: ["'.$array["xAxiscategories"].'"],
						lineWidth: 0,
						labels:
						{
							autoRotation: 0,
							padding: 0
						}
					},
					yAxis: '.$yAxis.',
					series:
					[
						{
							color:
							{
								linearGradient: {  x2: 0, y2: 1 },
								stops:
								[
									[0, "#cdf9dd"],
									[1, "#f9eac7"]
								]
							},
							data: ['.$array["maxValue"].']
						},
						{
							color:
							{
								linearGradient: {  x2: 0, y2: 1 },
								stops: '.linear($array["maxValue"], $array["value"]).'
							},
							data: ['.$array["value"].']
						}
					]
				});
				';
			};
		?>
		<div class="analysis-header">
			<div class="colgroup col-middle">
				<div class="col-hd-6 col-lg-6">
					<div class="inline-item analysis-icon">
						<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 58 58" xml:space="preserve">
							<path style="fill:#00aeef;" d="M27,28.134V0.038C11.918,1.067,0,13.619,0,28.962C0,36.25,2.695,42.905,7.134,48L27,28.134z"/>
							<path style="fill:#fdc44c;" d="M31,26.962h26.924C56.94,12.541,45.421,1.022,31,0.038V26.962z"/>
							<path style="fill:#ee6143;" d="M50.386,48.615c4.343-4.71,7.151-10.858,7.614-17.653H32.733L50.386,48.615z"/>
							<path style="fill:#26a783;" d="M28.414,32.376L9.962,50.828c5.095,4.439,11.75,7.134,19.038,7.134 c6.99,0,13.396-2.479,18.401-6.599L28.414,32.376z"/>
						</svg>
					</div>
					<h1 class="inline-item">Hes <strong>Analysis</strong></h1>
				</div>
				<div class="col-hd-6 col-lg-6">
					<div class="analysis-close">
						<a href="index.php" title="Anasayfaya Dön">
							<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 47.971 47.971" style="enable-background:new 0 0 47.971 47.971;" xml:space="preserve">
								<path d="M28.228,23.986L47.092,5.122c1.172-1.171,1.172-3.071,0-4.242c-1.172-1.172-3.07-1.172-4.242,0L23.986,19.744L5.121,0.88 c-1.172-1.172-3.07-1.172-4.242,0c-1.172,1.171-1.172,3.071,0,4.242l18.865,18.864L0.879,42.85c-1.172,1.171-1.172,3.071,0,4.242 C1.465,47.677,2.233,47.97,3,47.97s1.535-0.293,2.121-0.879l18.865-18.864L42.85,47.091c0.586,0.586,1.354,0.879,2.121,0.879 s1.535-0.293,2.121-0.879c1.172-1.171,1.172-3.071,0-4.242L28.228,23.986z"/>
							</svg>
						</a>
					</div>
				</div>
			</div>
		</div>
		<div class="analysis-wrapper" id="wind">
			<div class="colgroup">
				<div class="col-hd-12 col-lg-12">
					<div class="box-title notmargin">Tribune Name</div>
					<div class="box" id="chart-1"></div>
				</div>
			</div>
			<br>
			<div class="colgroup">
				<div class="col-hd-4 col-lg-4 col-md-6 col-xs-12">
					<div class="box">
						<div class="colgroup nopadding col-center col-hd-3 col-lg-4 col-xs-4 col-pv-6">
							<div>
								<div id="chart-5"></div>
							</div>
							<div>
								<div id="chart-6"></div>
							</div>
							<div>
								<div id="chart-7"></div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-hd-8 col-lg-8 col-md-6 col-xs-12">
					<div class="box">
						<div class="colgroup">
							<div class="col-hd-4 col-lg-4 col-md-4">
								<div id="chart-2"></div>
							</div>
							<div class="col-hd-4 col-lg-4 col-md-4">
								<div id="chart-3"></div>
							</div>
							<div class="col-hd-4 col-lg-4 col-md-4">
								<div id="chart-4"></div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<script type="text/javascript">
			App.chart.wind();
			App.event.notshadow();

			<?php
				echo charts('chart-2','POWER (MW)', array (
					"value" => 0.0,
					"maxValue" => 100,
					"tickAmount" => 6,
					"yAxisDouble"=> true,
					"xAxiscategories" => "0.0 MW / 0.4%",
				));

				echo charts('chart-3','POWER (MW)', array (
					"value" => 0.0,
					"maxValue" => 100,
					"tickAmount" => 6,
					"yAxisDouble"=> true,
					"xAxiscategories" => "0.0 MW / 0.4%",
				));

				echo charts('chart-4','WIND SPEED (MW)', array (
					"value" => 2.9,
					"maxValue" => 20,
					"tickAmount" => 9,
					"yAxisDouble"=> true,
					"xAxiscategories" => "2.9 m/s",
				));

				// Box 1 also contains 7 charts

				echo charts('chart-5','POWER (KW)', array (
					"value" => 9.2,
					"maxValue"   => 30,
					"tickAmount" => 4,
					"xAxiscategories" => "9.2 kW",
				));

				echo charts('chart-6','REACTIVE POWER (KVAR)', array (
					"value"      => 0.8,
					"maxValue"   => 10,
					"tickAmount" => 5,
					"xAxiscategories" => "0.8 kvar",
				));

				echo charts('chart-7','WIND SPEED (M/S)', array (
					"value"      => 2.9,
					"maxValue"   => 20,
					"tickAmount" => 5,
					"xAxiscategories" => "2.9 m/s",
				));
			?>
		</script>
	</body>
</html>