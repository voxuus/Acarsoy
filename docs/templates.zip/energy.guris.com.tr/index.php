<!DOCTYPE html>
<html lang="en" dir="ltr">
	<head>
		<?php require_once 'include/head.php'; ?>
	</head>
	<body>
		<?php require_once 'include/header.php'; ?>
		<div class="maximum-production blur" id="chartall" style="display: block"></div>
		<div class="maximum-production blur" id="chartwind"></div>
		<div class="maximum-production blur" id="chartsolar"></div>
		<div class="maximum-production blur" id="charthes"></div>
		<div class="maximum-production blur" id="chartjes"></div>
		<div class="all-charts true" id="all">
			<a href="" class="allChartsClose" title="">
				<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 47.971 47.971" style="enable-background:new 0 0 47.971 47.971;" xml:space="preserve">
					<path d="M28.228,23.986L47.092,5.122c1.172-1.171,1.172-3.071,0-4.242c-1.172-1.172-3.07-1.172-4.242,0L23.986,19.744L5.121,0.88 c-1.172-1.172-3.07-1.172-4.242,0c-1.172,1.171-1.172,3.071,0,4.242l18.865,18.864L0.879,42.85c-1.172,1.171-1.172,3.071,0,4.242 C1.465,47.677,2.233,47.97,3,47.97s1.535-0.293,2.121-0.879l18.865-18.864L42.85,47.091c0.586,0.586,1.354,0.879,2.121,0.879 s1.535-0.293,2.121-0.879c1.172-1.171,1.172-3.071,0-4.242L28.228,23.986z"/>
				</svg>
			</a>
			<h3>All power plants</h3>
			<div id="chartAll"></div>
		</div>
		<div class="all-charts" id="wind">
			<a href="" class="allChartsClose" title="">
				<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 47.971 47.971" style="enable-background:new 0 0 47.971 47.971;" xml:space="preserve">
					<path d="M28.228,23.986L47.092,5.122c1.172-1.171,1.172-3.071,0-4.242c-1.172-1.172-3.07-1.172-4.242,0L23.986,19.744L5.121,0.88 c-1.172-1.172-3.07-1.172-4.242,0c-1.172,1.171-1.172,3.071,0,4.242l18.865,18.864L0.879,42.85c-1.172,1.171-1.172,3.071,0,4.242 C1.465,47.677,2.233,47.97,3,47.97s1.535-0.293,2.121-0.879l18.865-18.864L42.85,47.091c0.586,0.586,1.354,0.879,2.121,0.879 s1.535-0.293,2.121-0.879c1.172-1.171,1.172-3.071,0-4.242L28.228,23.986z"/>
				</svg>
			</a>
			<h3>All wind power plants</h3>
			<div id="chartWind"></div>
		</div>
		<div class="all-charts" id="solar">
			<a href="" class="allChartsClose" title="">
				<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 47.971 47.971" style="enable-background:new 0 0 47.971 47.971;" xml:space="preserve">
					<path d="M28.228,23.986L47.092,5.122c1.172-1.171,1.172-3.071,0-4.242c-1.172-1.172-3.07-1.172-4.242,0L23.986,19.744L5.121,0.88 c-1.172-1.172-3.07-1.172-4.242,0c-1.172,1.171-1.172,3.071,0,4.242l18.865,18.864L0.879,42.85c-1.172,1.171-1.172,3.071,0,4.242 C1.465,47.677,2.233,47.97,3,47.97s1.535-0.293,2.121-0.879l18.865-18.864L42.85,47.091c0.586,0.586,1.354,0.879,2.121,0.879 s1.535-0.293,2.121-0.879c1.172-1.171,1.172-3.071,0-4.242L28.228,23.986z"/>
				</svg>
			</a>
			<h3>All solar power plants</h3>
			<div id="chartSolar"></div>
		</div>
		<div class="all-charts" id="hes">
			<a href="" class="allChartsClose" title="">
				<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 47.971 47.971" style="enable-background:new 0 0 47.971 47.971;" xml:space="preserve">
					<path d="M28.228,23.986L47.092,5.122c1.172-1.171,1.172-3.071,0-4.242c-1.172-1.172-3.07-1.172-4.242,0L23.986,19.744L5.121,0.88 c-1.172-1.172-3.07-1.172-4.242,0c-1.172,1.171-1.172,3.071,0,4.242l18.865,18.864L0.879,42.85c-1.172,1.171-1.172,3.071,0,4.242 C1.465,47.677,2.233,47.97,3,47.97s1.535-0.293,2.121-0.879l18.865-18.864L42.85,47.091c0.586,0.586,1.354,0.879,2.121,0.879 s1.535-0.293,2.121-0.879c1.172-1.171,1.172-3.071,0-4.242L28.228,23.986z"/>
				</svg>
			</a>
			<h3>All hes power plants</h3>
			<div id="chartHes"></div>
		</div>
		<div class="all-charts" id="jes">
			<a href="" class="allChartsClose" title="">
				<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 47.971 47.971" style="enable-background:new 0 0 47.971 47.971;" xml:space="preserve">
					<path d="M28.228,23.986L47.092,5.122c1.172-1.171,1.172-3.071,0-4.242c-1.172-1.172-3.07-1.172-4.242,0L23.986,19.744L5.121,0.88 c-1.172-1.172-3.07-1.172-4.242,0c-1.172,1.171-1.172,3.071,0,4.242l18.865,18.864L0.879,42.85c-1.172,1.171-1.172,3.071,0,4.242 C1.465,47.677,2.233,47.97,3,47.97s1.535-0.293,2.121-0.879l18.865-18.864L42.85,47.091c0.586,0.586,1.354,0.879,2.121,0.879 s1.535-0.293,2.121-0.879c1.172-1.171,1.172-3.071,0-4.242L28.228,23.986z"/>
				</svg>
			</a>
			<h3>All jes power plants</h3>
			<div id="chartJes"></div>
		</div>
		<div class="map-total blur" id="totalall" style="display: block">
			<h6>00 mVAR</h6>
			<h6>122 mW</h6>
			<h4>All Total</h4>
		</div>
		<div class="map-total blur" id="totalwind">
			<h6>00 mVAR</h6>
			<h6>122 mW</h6>
			<h4>Wind Total</h4>
		</div>
		<div class="map-total blur" id="totalsolar">
			<h6>00 mVAR</h6>
			<h6>122 mW</h6>
			<h4>Solar Total</h4>
		</div>
		<div class="map-total blur" id="totalhes">
			<h6>00 mVAR</h6>
			<h6>122 mW</h6>
			<h4>Hes Total</h4>
		</div>
		<div class="map-total blur" id="totaljes">
			<h6>00 mVAR</h6>
			<h6>122 mW</h6>
			<h4>Jes Total</h4>
		</div>
		<div id="units" class="active">
			<div id="units-table">
				<table>
					<tbody>
						<?php for ($i=1; $i < 50; $i++) { ?>
						<tr
							data-text-1="<?php echo rand(0,100) ?>°"
							data-text-2="<?php echo rand(0,999) ?>m/s"
							data-text-3="<?php echo rand(0,10) ?>"
							data-text-4="<?php echo rand(0,10) ?>"
							data-text-5="<?php echo rand(0,10) ?>"
							data-text-6="<?php echo rand(0,10) ?>"
							data-text-6="<?php echo rand(0,100) ?>">
							<td class="code">T<?php echo $i; ?></td>
							<td><?php echo rand(0,50) ?>.<?php echo rand(0,50) ?>kW</td>
							<td>-<?php echo rand(0,50) ?>.<?php echo rand(0,50) ?>kVAR</td>
							<td>-<?php echo rand(0,10) ?>.<?php echo rand(0,10) ?>°C</td>
							<td>-<?php echo rand(0,10) ?>.<?php echo rand(0,10) ?>m/s</td>
						</tr>
						<?php } ?>
					</tbody>
				</table>
			</div>
			<div id="units-sticky">
				<div class="colgroup">
					<div class="col-hd-3 col-lg-3">
						<h5>WIND DIRECTION</h5>
						<h6 class="data-text-1">124</h6>
					</div>
					<div class="col-hd-3 col-lg-3">
						<h5>WIND SPEED</h5>
						<h6 class="data-text-2">124</h6>
					</div>
					<div class="col-hd-3 col-lg-3">
						<h5>AVAILABLE</h5>
						<h6 class="data-text-3">124</h6>
					</div>
					<div class="col-hd-3 col-lg-3">
						<h5>OUT OF SERVICE</h5>
						<h6 class="data-text-4">124</h6>
					</div>
				</div>
				<div class="colgroup">
					<div class="col-hd-3 col-lg-3">
						<h5>LOW WIND STOP</h5>
						<h6 class="data-text-5">124</h6>
					</div>
					<div class="col-hd-3 col-lg-3">
						<h5>HIGH WIND STOP</h5>
						<h6 class="data-text-6">124</h6>
					</div>
					<div class="col-hd-3 col-lg-3">
						<h5>PARK PILOT</h5>
						<h6 class="data-text-7">124</h6>
					</div>
					<div class="col-hd-3 col-lg-3">
						<h5>READY FO PRO.</h5>
						<h6 class="data-text-8">124</h6>
					</div>
				</div>
			</div>
			<div id="units-right"></div>
		</div>
		<div id="buttons" class="blur">
			<a href="" title="" class="dashboard"><span>Dashboard</span></a>
			<div></div>
			<a href="" title="" class="units"><span>Units</span></a>
			<div></div>
			<a href="" title="" class="allChartsOpen"><span>All Charts</span></a>
		</div>
		<nav id="map-category" class="blur">
			<ul>
				<li>
					<a href="" title="" class="active" data-type="all">
						<img src="assets/images/icon/mc-all.png" alt="">
						<h6>ALL</h6>
					</a>
				</li>
				<li>
					<a href="" title="" data-type="wind">
						<img src="assets/images/icon/mc-wind.png" alt="">
						<h6>WIND</h6>
					</a>
				</li>
				<li>
					<a href="" title="" data-type="solar">
						<img src="assets/images/icon/mc-solar.png" alt="">
						<h6>SOLAR</h6>
					</a>
				</li>
				<li>
					<a href="" title="" data-type="hes">
						<img src="assets/images/icon/mc-hes.png" alt="">
						<h6>HES</h6>
					</a>
				</li>
				<li>
					<a href="" title="" data-type="jes">
						<img src="assets/images/icon/mc-jes.png" alt="">
						<h6>JES</h6>
					</a>
				</li>
			</ul>
		</nav>
		<script type="text/javascript">
			App.chart.maximumProduction();
			App.chart.allCharts();
			App.event.mapCategory();
			App.event.unitsToggle();
		</script>
		<!--
			// Ana sayfa tüm tür kutuları
			{type}: wind | solar | hes | jes

			<a href="" title="" class="map-pin-box" data-type="{type}">
				<div class="box-left">
					<div class="icon"><img src="assets/images/icon/{type}.png" alt=""></div>
					<div class="temp">35°C</div>
				</div>
				<div class="box-right">
					<div class="text">
						<h4>İStanbul</h4>
						<h5>23 MW</h5>
						<h6>3 m/s</h6>
					</div>
				</div>
			</a>

			// Wind
			{status}: true | false

			<a href="" title="" class="map-pin-wind" data-status="{status}">
				<div class="marker">
					<img src="assets/images/icon/marker.png" alt="">
					<div class="propeller"></div>
				</div>
				<h6>
					h1<br>
					h2<br>
					h3
				</h6>
			</a>
		-->
		<!-- Geçici map, öylesine arkaplanda birşey olsun diye koydum. -->
		<div id="map" class="blur" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: 1; opacity: 0.8;background: url('assets/images/main/map.jpg') no-repeat center center; background-size: cover;">
		</div>
	</body>
</html>