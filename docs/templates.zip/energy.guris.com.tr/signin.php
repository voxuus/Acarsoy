<!DOCTYPE html>
<html lang="en" dir="ltr">
	<head>
		<?php require_once 'include/head.php'; ?>
	</head>
	<body style="background-image: url('assets/images/main/singin.jpg');">
		<div id="signin">
			<div id="middle">
				<div id="box">
					<div id="box-img">
						<img src="assets/images/main/guris.png" alt="">
					</div>
					<div id="box-group">
						<h1>Login to System</h1>
						<input type="text" name="" placeholder="Username">
						<input type="password" name="" placeholder="Password">
						<p>
							<input type="checkbox" name="rememberme" id="rememberme" value="Remember me">
							<label for="rememberme">Remember me</label>
						</p>
						<button type="submit">SING IN</button>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>