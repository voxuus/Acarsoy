<!DOCTYPE html>
<html lang="en" dir="ltr">
	<head>
		<?php require_once 'include/head.php'; ?>
	</head>
	<body>
		<?php require_once 'include/header.php'; ?>
		<?php
			$rand  = rand(0,100);
			$title = rand(0,8);
		?>
		<script type="text/javascript">
			$(function(){

				$('body').css('background-image','url("assets/images/main/excel.jpg")');
				$('#prev').show();

				Highcharts.chart('excel-chart', {
					chart: {
						plotBackgroundColor: null,
						plotBorderWidth: 0,
						plotShadow: false,
						backgroundColor: 'rgba(255,255,255,0)'
					},
					credits: {
						enabled: false
					},
					title: {
						text: '%<?php echo $rand; ?><br><span style="font-size: 20px; color: #fdc44c; display: block">TOPLAM</span>',
						align: 'center',
						verticalAlign: 'middle',
						y: 0,
						margin: 0,
						style: { "color": "#ffffff", "fontSize": "70px", "fontWeight": "200" }
					},
					tooltip: {
						pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
					},
					plotOptions: {
						pie: {
							dataLabels: {
								enabled: true,
								distance: 0
							},
							startAngle: -360,
							endAngle: 0,
							center: ['50%', '50%']
						}
					},
					series: [{
						type: 'pie',
						name: 'Analysis',
						innerSize: '97%',
						borderWidth: 0,
						data: [
							['', <?php echo $rand; ?>],
							['', <?php echo 100 - $rand; ?>]
						]
					}]
				});
			});
		</script>
		<div id="excel" class="solar">
			<a href="" title="" class="export">CSV’ye Aktar</a>
			<a href="" title="" class="icon"><img src="assets/images/icon/solar.png" alt=""></a>
			<h1>Solar Title</h1>
			<table>
				<thead>
					<tr>
						<th>NO</th>
						<th>SINYAL</th>
						<th>SINYAL TIPI</th>
						<th>MODBUSS ADRESS</th>
					</tr>
				</thead>
				<tbody>
					<tr><td colspan="4" class="title">H01 ( KESICILI GIRIS HÜCRESİ)</td></tr>
					<tr>
						<td>1</td>
						<td>1H01/Ayirici/Status ACIK</td>
						<td>Digital</td>
						<td>2210</td>
					</tr>
					<tr>
						<td>2</td>
						<td>1H01/Ayirici/Status KAPALI</td>
						<td>Digital</td>
						<td>2200</td>
					</tr>
					<tr>
						<td>3</td>
						<td>1H01/Toprak Ayiricisi/Status ACIK</td>
						<td>Digital</td>
						<td>2211</td>
					</tr>
					<tr>
						<td>4</td>
						<td>1H01/Toprak Ayiricisi/Status KAPALI</td>
						<td>Digital</td>
						<td>2201</td>
					</tr>
					<tr><td colspan="4" class="title">H02 ( OLCU HUCRESI )</td></tr>
					<tr>
						<td>5</td>
						<td>1H02/Ayirici/Status ACIK</td>
						<td>Digital</td>
						<td>2212</td>
					</tr>
					<tr>
						<td>6</td>
						<td>1H02/Ayirici/Status KAPALI</td>
						<td>Digital</td>
						<td>2202</td>
					</tr>
					<tr>
						<td>7</td>
						<td>1H02/Toprak Ayiricisi/Status ACIK</td>
						<td>Digital</td>
						<td>2213</td>
					</tr>
					<tr>
						<td>8</td>
						<td>1H02/Toprak Ayiricisi/Status KAPALI</td>
						<td>Digital</td>
						<td>2203</td>
					</tr>
					<tr><td colspan="4" class="title">OLCU HUCRESI - KALITE KAYDEDICI</td></tr>
					<tr>
						<td>9</td>
						<td>1H02/Vab Faz arası gerilim AB</td>
						<td>Analog</td>
						<td>1086</td>
					</tr>
						<td>10</td>
						<td>1H02/Vbc Faz arası gerilim BC</td>
						<td>Analog</td>
						<td>1092</td>
					<tr>
						<td>11</td>
						<td>1H02/Vac Faz arası gerilim AC</td>
						<td>Analog</td>
						<td>1088</td>
					</tr>
					<tr>
						<td>12</td>
						<td>1H02/F Frekans</td>
						<td>Analog</td>
						<td>1040</td>
					</tr>
					<tr>
						<td>13</td>
						<td>1H02/Ia Faz Akimi A</td>
						<td>Analog</td>
						<td>1042</td>
					</tr>
					<tr>
						<td>14</td>
						<td>1H02/Ib Faz Akimi B</td>
						<td>Analog</td>
						<td>1044</td>
					</tr>
					<tr>
						<td>15</td>
						<td>1H02/Ic Faz Akimi C</td>
						<td>Analog</td>
						<td>1046</td>
					</tr>
					<tr>
						<td>16</td>
						<td>1H02/P Aktif Guc</td>
						<td>Analog</td>
						<td>048</td>
					</tr>
					<tr>
						<td>17</td>
						<td>1H02/Q Reaktif Guc</td>
						<td>Analog</td>
						<td>1064</td>
					</tr>
					<tr>
						<td>18</td>
						<td>1H02/S Gorunur Guc</td>
						<td>Analog</td>
						<td>1066</td>
					</tr>
					<tr>
						<td>19</td>
						<td>1H02/CosFi</td>
						<td>Analog</td>
						<td>1038</td>
					</tr>
					<tr>
						<td>20</td>
						<td>1H02/PF Guc Faktoru</td>
						<td>Analog</td>
						<td>1050</td>
					</tr>
					<tr>
						<td>21</td>
						<td>1H02/Wp+ Tuketilen Aktif Enerji</td>
						<td>Analog</td>
						<td>1100</td>
					</tr>
					<tr>
						<td>22</td>
						<td>1H02/Wp- Uretilen Aktif Enerji</td>
						<td>Analog</td>
						<td>1098</td>
					</tr>
					<tr>
						<td>23</td>
						<td>1H02/Wq+ Tuketilen Reaktif Enerji</td>
						<td>Analog</td>
						<td>1104</td>
					</tr>
					<tr>
						<td>24</td>
						<td>1H02/Wq- Uretilen Reaktif Enerji</td>
						<td>Analog</td>
						<td>1102</td>
					</tr>
					<tr>
						<td>25</td>
						<td>RTU/Kalite Kaydedici Haberlesme Ariza</td>
						<td>Digital</td>
						<td>1190</td>
					</tr>
					<tr><td colspan="4" class="title">H03 ( KESICILI TRAFO KORUMA HUCRESI )</td></tr>
					<tr>
						<td>26</td>
						<td>1H03/Koruma Rolesi Arizali</td>
						<td>Digital</td>
						<td>10001</td>
					</tr>
					<tr>
						<td>27</td>
						<td>1H03/Kesici/Status ACIK</td>
						<td>Digital</td>
						<td>2217</td>
					</tr>
					<tr>
						<td>28</td>
						<td>1H03/Kesici/Status KAPALI</td>
						<td>Digital</td>
						<td>2216</td>
					</tr>
					<tr>
						<td>29</td>
						<td>1H03/Ayirici/Status ACIK</td>
						<td>Digital</td>
						<td>2214</td>
					</tr>
					<tr>
						<td>30</td>
						<td>1H03/Ayirici/Status KAPALI</td>
						<td>Digital</td>
						<td>2204</td>
					</tr>
					<tr>
						<td>31</td>
						<td>1H03/Toprak Ayiricisi/Status ACIK</td>
						<td>Digital</td>
						<td>2215</td>
					</tr>
					<tr>
						<td>32</td>
						<td>1H03/Toprak Ayiricisi/Status KAPALI</td>
						<td>Digital</td>
						<td>2205</td>
					</tr>
					<tr>
						<td>33</td>
						<td>1H03/Koruma Acma</td>
						<td>Digital</td>
						<td>10002</td>
					</tr>
					<tr>
						<td>34</td>
						<td>RTU/Role 1 Haberlesme Ariza</td>
						<td>Digital</td>
						<td>1194</td>
					</tr>
					<tr><td colspan="4" class="title">INVERTER</td></tr>
					<tr>
						<td>35</td>
						<td>Inverter/Alarm</td>
						<td>Digital</td>
						<td>10004</td>
					</tr>
					<tr>
						<td>36</td>
						<td>Inverter/Haberleşme Arızası</td>
						<td>Digital</td>
						<td>48</td>
					</tr>
					<tr>
						<td>37</td>
						<td>Inverter/Running</td>
						<td>Digital</td>
						<td>10005</td>
					</tr>
					<tr>
						<td>38</td>
						<td>Inverter/Failure</td>
						<td>Digital</td>
						<td>10006</td>
					</tr>
					<tr>
						<td>39</td>
						<td>Inverter/Giris DC Gerilimi</td>
						<td>Analog</td>
						<td>131</td>
					</tr>
					<tr>
						<td>40</td>
						<td>Inverter/Giris DC-1 Akimi</td>
						<td>Analog</td>
						<td>10010</td>
					</tr>
					<tr>
						<td>41</td>
						<td>Inverter/Giris DC Gucu</td>
						<td>Analog</td>
						<td>135</td>
					</tr>
					<tr>
						<td>42</td>
						<td>Inverter/Cikis L1-2 Gerilimi</td>
						<td>Analog</td>
						<td>10036</td>
					</tr>
					<tr>
						<td>43</td>
						<td>Inverter/Cikis L1 faz akimi</td>
						<td>Analog</td>
						<td>10038</td>
					</tr>
					<tr>
						<td>44</td>
						<td>Inverter/Giris DC-2 Akimi</td>
						<td>Analog</td>
						<td>10012</td>
					</tr>
					<tr>
						<td>45</td>
						<td>Inverter/Giris DC-3 Akimi</td>
						<td>Analog</td>
						<td>10014</td>
					</tr>
					<tr>
						<td>46</td>
						<td>Inverter/Giris DC-4 Akimi</td>
						<td>Analog</td>
						<td>10016</td>
					</tr>
					<tr>
						<td>47</td>
						<td>Inverter/Giris DC-5 Akimi</td>
						<td>Analog</td>
						<td>10018</td>
					</tr>
					<tr>
						<td>48</td>
						<td>Inverter/Giris DC-6 Akimi</td>
						<td>Analog</td>
						<td>10020</td>
					</tr>
					<tr>
						<td>49</td>
						<td>Inverter/Giris DC-7 Akimi</td>
						<td>Analog</td>
						<td>10022</td>
					</tr>
					<tr>
						<td>50</td>
						<td>Inverter/Giris DC-8 Akimi</td>
						<td>Analog</td>
						<td>10024</td>
					</tr>
					<tr>
						<td>51</td>
						<td>Inverter/Cikis AC Gücü</td>
						<td>Analog</td>
						<td>10026</td>
					</tr>
					<tr>
						<td>52</td>
						<td>Inverter/Cikis L2 faz akimi</td>
						<td>Analog</td>
						<td>10028</td>
					</tr>
					<tr>
						<td>53</td>
						<td>Inverter/Cikis L3 faz akimi</td>
						<td>Analog</td>
						<td>10030</td>
					</tr>
					<tr>
						<td>54</td>
						<td>Inverter/Cikis L1-3 Gerilimi</td>
						<td>Analog</td>
						<td>10032</td>
					</tr>
					<tr>
						<td>55</td>
						<td>Inverter/Cikis L2-3 Gerilimi</td>
						<td>Analog</td>
						<td>10034</td>
					</tr>
					<tr><td colspan="4" class="title">REDRESÖR</td></tr>
					<tr>
						<td>56</td>
						<td>Redresör Cikis gerilimi(+10V)</td>
						<td>Analog</td>
						<td>1034</td>
					</tr>
					<tr>
						<td>57</td>
						<td>Redresör Yük Akimi(+10V)</td>
						<td>Analog</td>
						<td>1036</td>
					</tr>

					<tr><td colspan="4" class="title">ENSTRÜMAN</td></tr>
					<tr>
						<td>58</td>
						<td>Ruzgar hizi</td>
						<td>Analog</td>
						<td>1000</td>
					</tr>
					<tr>
						<td>59</td>
						<td>Ortam Sicaklik</td>
						<td>Analog</td>
						<td>1002</td>
					</tr>
					<tr>
						<td>60</td>
						<td>Isinim</td>
						<td>Analog</td>
						<td>1004</td>
					</tr>
					<tr>
						<td>61</td>
						<td>Panel Sicaklik</td>
						<td>Analog</td>
						<td>1006</td>
					</tr>
				</tbody>
			</table>
		</div>
		<div id="excel-chart"></div>
	</body>
</html>