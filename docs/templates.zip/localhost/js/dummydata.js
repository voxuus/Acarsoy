// grid dummy data
var dummyData = {
	'Mobile App': '\
		<li class="product"><a href="mobile.robosoft.com.tr/tr/index.html" target="_blank">Anasayfa</a></li>\
		<li class="product"><a href="mobile.robosoft.com.tr/tr/about.html" target="_blank">Hakkımızda</a></li>\
		<li class="product"><a href="mobile.robosoft.com.tr/tr/services/index.html" target="_blank">Servisler</a></li>\
		<li class="product"><a href="mobile.robosoft.com.tr/tr/services/services-1.html" target="_blank">Servis Detay</a></li>\
		<li class="product"><a href="mobile.robosoft.com.tr/tr/products/index.html" target="_blank">Ürünler</a></li>\
		<li class="product"><a href="mobile.robosoft.com.tr/tr/products/industrial-reporting.html" target="_blank">Ürün Detay</a></li>\
		<li class="product"><a href="mobile.robosoft.com.tr/tr/references.html" target="_blank">Referanslar</a></li>\
		<li class="product"><a href="mobile.robosoft.com.tr/tr/news.html" target="_blank">Haberler</a></li>\
		<li class="product"><a href="mobile.robosoft.com.tr/tr/contact.html" target="_blank">İletişim</a></li>',
	'Web Broşür': '\
		<li class="product"><a href="web.robosoft.com.tr/tr/index.html" target="_blank">Anasayfa</a></li>\
		<li class="product"><a href="web.robosoft.com.tr/tr/robosoft.html" target="_blank">Robosoft</a></li>\
		<li class="product"><a href="web.robosoft.com.tr/tr/references.html" target="_blank">Referanslar</a></li>\
		<li class="product"><a href="web.robosoft.com.tr/tr/products.html" target="_blank">Ürünler</a></li>\
		<li class="product"><a href="web.robosoft.com.tr/tr/services.html" target="_blank">Hizmetler</a></li>\
		<li class="product"><a href="web.robosoft.com.tr/tr/contact.html" target="_blank">İletişim</a></li>',
	'RBS Report': '\
		<li class="product"><a href="rbsreport.com/index.php" title="Anasayfa" target="_blank">Anasayfa</a></li>\
		<li class="product"><a href="rbsreport.com/about.php" title="Hakkımızda" target="_blank">Hakkımızda</a></li>\
		<li class="product"><a href="rbsreport.com/contact.php" title="İletişim" target="_blank">İletişim</a></li>\
		<li class="product"><a href="rbsreport.com/faq.php" title="SSS" target="_blank">SSS</a></li>\
		<li class="product"><a href="rbsreport.com/support-form.php" title="Destek Formu" target="_blank">Destek Formu</a></li>\
		<li class="product"><a href="rbsreport.com/downloads.php" title="İndirilenler" target="_blank">İndirilenler</a></li>\
		<li class="product"><a href="rbsreport.com/product.php" title="Ürün" target="_blank">Ürün</a></li>\
		<li class="product"><a href="rbsreport.com/login.php" title="Giriş Yap" target="_blank">Giriş Yap</a></li>\
		<li class="product"><a href="rbsreport.com/register.php" title="Kayıt Ol" target="_blank">Kayıt Ol</a></li>\
		<li class="product"><a href="rbsreport.com/references.php" title="Referanslar" target="_blank">Referanslar</a></li>\
		<li class="product"><a href="rbsreport.com/reset-password.php" title="Şifre Sıfırla" target="_blank">Şifre Sıfırla</a></li>\
		<li class="product"><a href="rbsreport.com/account.php" title="Hesap" target="_blank">Hesap</a></li>\
		<li class="product"><a href="rbsreport.com/transfer-notice-form.php" title="Ödeme Bildirim Formu" target="_blank">Ödeme Bildirim Formu</a></li>\
		<li class="product"><a href="rbsreport.com/my-purchases.php" title="Satın Aldıklarım" target="_blank">Satın Aldıklarım</a></li>\
		<li class="product"><a href="rbsreport.com/buy.php" title="Satın Al" target="_blank">Satın Al</a></li>\
		<li class="product"><a href="rbsreport.com/license-code.php" title="Lisans Kodları" target="_blank">Lisans Kodları</a></li>',
	'Güriş Enerji': '\
		<li class="product"><a href="energy.guris.com.tr/index.php" title="Home" target="_blank">Home</a></li>\
		<li class="product"><a href="energy.guris.com.tr/all-power.php" title="All Power" target="_blank">All Power</a></li>\
		<li class="product"><a href="energy.guris.com.tr/hes.php" title="Hes" target="_blank">Hes</a></li>\
		<li class="product"><a href="energy.guris.com.tr/hes-excel.php" title="Hes Excel" target="_blank">Hes Excel</a></li>\
		<li class="product"><a href="energy.guris.com.tr/jes.php" title="Jes" target="_blank">Jes</a></li>\
		<li class="product"><a href="energy.guris.com.tr/signin.php" title="Sign In" target="_blank">Sign In</a></li>\
		<li class="product"><a href="energy.guris.com.tr/solar.php" title="Solar" target="_blank">Solar</a></li>\
		<li class="product"><a href="energy.guris.com.tr/solar-excel.php" title="Solar Excel" target="_blank">Solar Excel</a></li>\
		<li class="product"><a href="energy.guris.com.tr/wind.php" title="Wind" target="_blank">Wind</a></li>',
	'Makine İzleme': '\
		<li class="product"><a href="makineizleme/index.php" title="Anasayafa" target="_blank">Anasayfa</a></li>\
		<li class="product"><a href="makineizleme/machines.php" title="Makineler" target="_blank">Makineler</a></li>\
		<li class="product"><a href="makineizleme/reports.php" title="Raporlar" target="_blank">Raporlar</a></li>\
		<li class="product"><a href="makineizleme/addinfo.php" title="Bilgi Ekle" target="_blank">Bilgi Ekle</a></li>\
		<li class="product"><a href="makineizleme/signin.php" title="Giriş Yap" target="_blank">Giriş Yap</a></li>',
	'Acarsoy Enerji': '\
		<li class="product"><a href="energy.acarsoyenerji.com.tr/index.html" title="Login" target="_blank">Giriş Sayfası</a></li>\
		<li class="product"><a href="energy.acarsoyenerji.com.tr/home.html" title="Makineler" target="_blank">Anasayfa</a></li>\
		<li class="product"><a href="energy.acarsoyenerji.com.tr/res.html" title="RES" target="_blank">RES</a></li>\
		<li class="product"><a href="energy.acarsoyenerji.com.tr/trend.html" title="Trend" target="_blank">Trend</a></li>\
		<li class="product"><a href="energy.acarsoyenerji.com.tr/turbine.html" title="Türbin" target="_blank">Türbin</a></li>\
		<li class="product"><a href="energy.acarsoyenerji.com.tr/turbines.html" title="Türbinler" target="_blank">Türbinler</a></li>'
}
