<!DOCTYPE html>
<html lang="tr" dir="ltr">
	<head>
		<?php require_once 'include/head.php'; ?>
	</head>
	<body>
		<header id="gb-header">
			<div class="colgroup col-middle">
				<div class="col-hd-8 col-lg-8 col-md-6 col-xs-12">
					<hgroup>
						<h1>BİLGİ EKLE</h1>
						<h6>Uygun Kurdele Makine İzleme</h6>
					</hgroup>
				</div>
				<div class="col-hd-4 col-lg-4 col-md-6 col-xs-12">
					<div class="colgroup col-middle">
						<div class="col-hd-6 col-lg-6 col-pv-4 button-scope">
							<a href="" title="" class="button">
								<span>DASHBOARD</span>
								<img src="assets/images/icon/header-home.png" width="20" alt="">
							</a>
						</div>
						<div class="col-hd-6 col-lg-6 col-pv-8">
							<a href="" title="" class="user-dropdown">Selçuk Aker</a>
						</div>
					</div>
				</div>
			</div>
		</header>
		<div id="container">
			<div id="addinfo">
				<?php for ($i=1; $i < 80; $i++) { ?>
				<table>
					<tbody>
						<tr>
							<td rowspan="2" nowrap><h2>INT <?php echo $i; ?></h2></td>
							<td><h6>Bilgi Adı</h6></td>
							<td><h6>Bilgi Adı</h6></td>
							<td><h6>Bilgi Adı</h6></td>
							<td><h6>Bilgi Adı</h6></td>
							<td><h6>Bilgi Adı</h6></td>
							<td rowspan="2" width="1">
								<button type="submit" class="link save">KAYDET</button>
								<button type="submit" class="link remove">SİL</button>
							</td>
						</tr>
						<tr>
							<td><input type="text" name="" placeholder="Bilgi Adı"></td>
							<td><input type="text" name="" placeholder="Bilgi Adı"></td>
							<td><input type="text" name="" placeholder="Bilgi Adı"></td>
							<td><input type="text" name="" placeholder="Bilgi Adı"></td>
							<td><input type="text" name="" placeholder="Bilgi Adı"></td>
						</tr>
					</tbody>
				</table>
				<?php } ?>
			</div>
		</div>
		<?php require_once 'include/footer.php'; ?>
	</body>
</html>