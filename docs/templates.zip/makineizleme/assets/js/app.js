'use strict';

var App = {};

App.event = function()
{
	return {

		eventToggleClick: function()
		{
			$('.events-open').click(function(event) {
				event.preventDefault();
				$('body').css('overflow', 'hidden');
				$('#events').fadeIn();
			});

			$('.events-close').click(function(event) {
				event.preventDefault();
				$('body').css('overflow', '');
				$('#events').fadeOut();
			});
		},
	}

}();
