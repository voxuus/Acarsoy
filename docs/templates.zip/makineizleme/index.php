<!DOCTYPE html>
<html lang="tr" dir="ltr">
	<head>
		<?php require_once 'include/head.php'; ?>
	</head>
	<body>
		<header id="gb-header">
			<div class="colgroup col-middle">
				<div class="col-hd-8 col-lg-8 col-md-6 col-xs-12">
					<hgroup>
						<h1>DASHBOARD</h1>
						<h6>Uygun Kurdele Makine İzleme</h6>
					</hgroup>
				</div>
				<div class="col-hd-4 col-lg-4 col-md-6 col-xs-12">
					<div class="colgroup col-middle">
						<div class="col-hd-6 col-lg-6 col-pv-4 button-scope">
							<a href="" title="" class="button">
								<span>BİLGİ GİRİŞİ</span>
								<img src="assets/images/icon/header-info.png" width="20" alt="">
							</a>
						</div>
						<div class="col-hd-6 col-lg-6 col-pv-8">
							<a href="" title="" class="user-dropdown">Selçuk Aker</a>
						</div>
					</div>
				</div>
			</div>
		</header>
		<div id="container">
			<div class="panel">
				<div class="panel-title">
					<h4>Anlık Performans</h4>
				</div>
				<div class="panel-content" style="position: relative;">
					<!--
						<select name="" id="working-hours">
							<option value="#chart-day">Gündüz</option>
							<option value="#chart-night">Gece</option>
						</select>
					-->
					<h2 class="chart-title"></h2>
					<div class="chart-section" id="chart-index-1"></div>
					<div class="chart-section" id="chart-index-2"></div>
					<div class="chart-section" id="chart-index-3"></div>
					<div class="chart-section" id="chart-index-4"></div>
					<div class="chart-section" id="chart-index-5"></div>
					<div class="chart-section" id="chart-index-6"></div>
					<div class="chart-section" id="chart-index-all"></div>
					<ul class="chart-days">
						<li><a href="#chart-index-1" class="show-chart" title="<small>16.06.2017</small> Perşembe">Perşembe</a></li>
						<li><a href="#chart-index-2" class="show-chart" title="<small>17.06.2017</small> Cuma">Cuma</a></li>
						<li><a href="#chart-index-3" class="show-chart" title="<small>18.06.2017</small> Cumartesi">Cumartesi</a></li>
						<li><a href="#chart-index-4" class="show-chart" title="<small>19.06.2017</small> Pazartesi">Pazartesi</a></li>
						<li><a href="#chart-index-5" class="show-chart" title="<small>20.06.2017</small> Salı">Salı</a></li>
						<li><a href="#chart-index-6" class="show-chart active" title="<small>21.06.2017</small> Çarşamba">Çarşamba</a></li>
					</ul>
					<div style="text-align: center;">
						<a href="#chart-index-all" class="show-chart all-chart" title="<small>16.06.2017 - 21.06.2017</small> Tüm hafta verileri.">Tüm hafta verileri.</a>
					</div>
				</div>
			</div>
			<div class="colgroup">
				<div class="col-hd-10 col-lg-9 col-md-8 col-xs-12">
					<div class="events-open">OLAYLARI GÖRÜNTÜLE</div>
					<div class="colgroup">
						<div class="col-hd-6 col-lg-6 col-xs-12">
							<div class="panel">
								<div class="panel-title">
									<h4>Haftalık Verimli Makineler</h4>
								</div>
								<div class="panel-content">
									<div class="colgroup col-middle statistics up">
										<div class="col-hd-7 col-lg-7 col-sm-12">
											<h6>Haftalık Verimli Makineler</h6>
											<div class="machine">
												<img src="assets/images/icon/machine.png" alt="">
												<span>74 Makine</span>
											</div>
											<div class="rate">5633 kurdele</div>
										</div>
										<div class="col-hd-5 col-lg-5 md-none-i">
											<?php $percent = rand(0,100); ?>
											<div class="svg">
												<span><?php echo $percent; ?></span>
												<svg x="0px" y="0px" viewBox="0 0 110 110" enable-background="new 0 0 110 100" xml:space="preserve">
													<circle	class="circle" cx="55" cy="55" r="52.5"/>    
													<circle class="circle-color" cx="55" cy="55" r="52.5" stroke-dasharray="<?php echo (330 / 100) * $percent; ?>, 330"/>               
												</svg>
											</div>
										</div>
									</div>
								</div>
								<div class="statistic-bar up"><div style="width: <?php echo $percent; ?>%"></div></div>
							</div>
						</div>
						<div class="col-hd-6 col-lg-6 col-xs-12">
							<div class="panel">
								<div class="panel-title">
									<h4>Haftalık Verimsiz Makineler</h4>
								</div>
								<div class="panel-content">
									<div class="colgroup col-middle statistics down">
										<div class="col-hd-7 col-lg-7 col-sm-12">
											<h6>Haftalık Verimsiz Makineler</h6>
											<div class="machine">
												<img src="assets/images/icon/machine.png" alt="">
												<span>6 Makine</span>
											</div>
											<div class="rate">77 kurdele</div>
										</div>
										<div class="col-hd-5 col-lg-5 md-none-i">
											<?php $percent = rand(0,100); ?>
											<div class="svg">
												<span><?php echo $percent; ?></span>
												<svg x="0px" y="0px" viewBox="0 0 110 110" enable-background="new 0 0 110 100" xml:space="preserve">
													<circle	class="circle" cx="56" cy="56" r="52.5"/>    
													<circle class="circle-color" cx="56" cy="56" r="52.5" stroke-dasharray="<?php echo (330 / 100) * $percent; ?>, 330"/>               
												</svg>
											</div>
										</div>
									</div>
								</div>
								<div class="statistic-bar down"><div style="width: <?php echo $percent; ?>%"></div></div>
							</div>
						</div>
					</div>
					<br>
					<div class="colgroup">
						<div class="col-hd-6 col-lg-6 col-xs-12">
							<div class="panel">
								<div class="panel-title">
									<h4>Haftalık Verimli Makineler</h4>
								</div>
								<div class="panel-content">
									<div class="colgroup col-middle statistics up">
										<div class="col-hd-7 col-lg-7 col-sm-12">
											<h6>Haftalık Verimli Makineler</h6>
											<div class="machine">
												<img src="assets/images/icon/machine.png" alt="">
												<span>74 Makine</span>
											</div>
											<div class="rate">5633 kurdele</div>
										</div>
										<div class="col-hd-5 col-lg-5 md-none-i">
											<?php $percent = rand(0,100); ?>
											<div class="svg">
												<span><?php echo $percent; ?></span>
												<svg x="0px" y="0px" viewBox="0 0 110 110" enable-background="new 0 0 110 100" xml:space="preserve">
													<circle	class="circle" cx="55" cy="55" r="52.5"/>    
													<circle class="circle-color" cx="55" cy="55" r="52.5" stroke-dasharray="<?php echo (330 / 100) * $percent; ?>, 330"/>               
												</svg>
											</div>
										</div>
									</div>
								</div>
								<div class="statistic-bar up"><div style="width: <?php echo $percent; ?>%"></div></div>
							</div>
						</div>
						<div class="col-hd-6 col-lg-6 col-xs-12">
							<div class="panel">
								<div class="panel-title">
									<h4>Haftalık Verimsiz Makineler</h4>
								</div>
								<div class="panel-content">
									<div class="colgroup col-middle statistics down">
										<div class="col-hd-7 col-lg-7 col-sm-12">
											<h6>Haftalık Verimsiz Makineler</h6>
											<div class="machine">
												<img src="assets/images/icon/machine.png" alt="">
												<span>6 Makine</span>
											</div>
											<div class="rate">77 kurdele</div>
										</div>
										<div class="col-hd-5 col-lg-5 md-none-i">
											<?php $percent = rand(0,100); ?>
											<div class="svg">
												<span><?php echo $percent; ?></span>
												<svg x="0px" y="0px" viewBox="0 0 110 110" enable-background="new 0 0 110 100" xml:space="preserve">
													<circle	class="circle" cx="56" cy="56" r="52.5"/>    
													<circle class="circle-color" cx="56" cy="56" r="52.5" stroke-dasharray="<?php echo (330 / 100) * $percent; ?>, 330"/>               
												</svg>
											</div>
										</div>
									</div>
								</div>
								<div class="statistic-bar down"><div style="width: <?php echo $percent; ?>%"></div></div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-hd-2 col-lg-3 col-md-4 col-xs-12">
					<div class="panel">
						<div class="panel-title">
							<h4>Olaylar</h4>
						</div>
						<div class="panel-content" style="padding-bottom: 0">
							<div id="events">
								<div class="events-close">
									<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 52 52" xml:space="preserve">
										<path d="M26,0C11.664,0,0,11.663,0,26s11.664,26,26,26s26-11.663,26-26S40.336,0,26,0z M26,50C12.767,50,2,39.233,2,26 S12.767,2,26,2s24,10.767,24,24S39.233,50,26,50z"/>
										<path d="M35.707,16.293c-0.391-0.391-1.023-0.391-1.414,0L26,24.586l-8.293-8.293c-0.391-0.391-1.023-0.391-1.414,0 s-0.391,1.023,0,1.414L24.586,26l-8.293,8.293c-0.391,0.391-0.391,1.023,0,1.414C16.488,35.902,16.744,36,17,36 s0.512-0.098,0.707-0.293L26,27.414l8.293,8.293C34.488,35.902,34.744,36,35,36s0.512-0.098,0.707-0.293 c0.391-0.391,0.391-1.023,0-1.414L27.414,26l8.293-8.293C36.098,17.316,36.098,16.684,35.707,16.293z"/>
									</svg>
								</div>
								<ul>
									<?php for ($i=0; $i < 10; $i++) { ?>
									<li>
										<time datetime="2017-01-12">2017-01-12</time>
										<p>INT 28 Çok Isındı.</p>
									</li>
									<?php } ?>
								</ul>
							</div>
							<div class="events-open" style="margin-bottom: 15px">OLAYLARI GÖRÜNTÜLE</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<script type="text/javascript">

			App.event.eventToggleClick();

			var chart = { height: 350, marginTop: 60, },
				credits = { enabled: false },
				title = { text: '' },
				xAxis = {
					categories: ["0","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23"],
					lineWidth: 0,
					labels: { autoRotation: 0, padding: 0 }
				},
				yAxis = { tickAmount: 5, min: 0, max: 80, title: { text: false } },
				legend = { align: 'center', verticalAlign: 'top', padding: 8, margin: 0 };
			
			function data( value )
			{
				return [
					{ name: "00:00 - 01:00", y: value[0] },
					{ name: "01:00 - 02:00", y: value[1] },
					{ name: "02:00 - 03:00", y: value[2] },
					{ name: "03:00 - 04:00", y: value[3] },
					{ name: "04:00 - 05:00", y: value[4] },
					{ name: "05:00 - 06:00", y: value[5] },
					{ name: "06:00 - 07:00", y: value[6] },
					{ name: "07:00 - 08:00", y: value[7] },
					{ name: "08:00 - 09:00", y: value[8] },
					{ name: "09:00 - 10:00", y: value[9] },
					{ name: "10:00 - 11:00", y: value[10] },
					{ name: "11:00 - 12:00", y: value[11] },
					{ name: "12:00 - 13:00", y: value[12] },
					{ name: "13:00 - 14:00", y: value[13] },
					{ name: "14:00 - 15:00", y: value[14] },
					{ name: "15:00 - 16:00", y: value[15] },
					{ name: "16:00 - 17:00", y: value[16] },
					{ name: "17:00 - 18:00", y: value[17] },
					{ name: "18:00 - 19:00", y: value[18] },
					{ name: "19:00 - 20:00", y: value[19] },
					{ name: "20:00 - 21:00", y: value[20] },
					{ name: "21:00 - 22:00", y: value[21] },
					{ name: "22:00 - 23:00", y: value[22] },
					{ name: "23:00 - 24:00", y: value[23] }
				];
			}

			Highcharts.chart('chart-index-1', {
				chart: chart,
				credits: credits,
				title: title,
				xAxis: xAxis,
				yAxis: yAxis,
				legend: legend,
				series: [{
					name: 'Yüksek Verimli Makineler',
					color: '#81C56C',
					data: data([50,55,60,65,70,65,60,55,50,55,60,65,70,65,60,55,50,55,60,65,70,65,60,55])
				}, {
					name: 'Düşük Verimli Makineler',
					color: '#EF3936',
					data: data([10,15,20,25,30,25,20,15,10,15,20,25,30,25,20,15,10,15,20,25,30,25,20,15])
				}]
			});
		
			Highcharts.chart('chart-index-2', {
				chart: chart,
				credits: credits,
				title: title,
				xAxis: xAxis,
				yAxis: yAxis,
				legend: legend,
				series: [{
					name: 'Yüksek Verimli Makineler',
					color: '#81C56C',
					data: data([50,55,60,65,70,65,60,55,50,55,60,65,70,65,60,55,50,55,60,65,70,65,60,55])
				}, {
					name: 'Düşük Verimli Makineler',
					color: '#EF3936',
					data: data([10,15,20,25,30,25,20,15,10,15,20,25,30,25,20,15,10,15,20,25,30,25,20,15])
				}]
			});
		
			Highcharts.chart('chart-index-3', {
				chart: chart,
				credits: credits,
				title: title,
				xAxis: xAxis,
				yAxis: yAxis,
				legend: legend,
				series: [{
					name: 'Yüksek Verimli Makineler',
					color: '#81C56C',
					data: data([50,55,60,65,70,65,60,55,50,55,60,65,70,65,60,55,50,55,60,65,70,65,60,55])
				}, {
					name: 'Düşük Verimli Makineler',
					color: '#EF3936',
					data: data([10,15,20,25,30,25,20,15,10,15,20,25,30,25,20,15,10,15,20,25,30,25,20,15])
				}]
			});
		
			Highcharts.chart('chart-index-4', {
				chart: chart,
				credits: credits,
				title: title,
				xAxis: xAxis,
				yAxis: yAxis,
				legend: legend,
				series: [{
					name: 'Yüksek Verimli Makineler',
					color: '#81C56C',
					data: data([50,55,60,65,70,65,60,55,50,55,60,65,70,65,60,55,50,55,60,65,70,65,60,55])
				}, {
					name: 'Düşük Verimli Makineler',
					color: '#EF3936',
					data: data([10,15,20,25,30,25,20,15,10,15,20,25,30,25,20,15,10,15,20,25,30,25,20,15])
				}]
			});
		
			Highcharts.chart('chart-index-5', {
				chart: chart,
				credits: credits,
				title: title,
				xAxis: xAxis,
				yAxis: yAxis,
				legend: legend,
				series: [{
					name: 'Yüksek Verimli Makineler',
					color: '#81C56C',
					data: data([50,55,60,65,70,65,60,55,50,55,60,65,70,65,60,55,50,55,60,65,70,65,60,55])
				}, {
					name: 'Düşük Verimli Makineler',
					color: '#EF3936',
					data: data([10,15,20,25,30,25,20,15,10,15,20,25,30,25,20,15,10,15,20,25,30,25,20,15])
				}]
			});
		
			Highcharts.chart('chart-index-6', {
				chart: chart,
				credits: credits,
				title: title,
				xAxis: xAxis,
				yAxis: yAxis,
				legend: legend,
				series: [{
					name: 'Yüksek Verimli Makineler',
					color: '#81C56C',
					data: data([50,55,60,65,70,65,60,55,50,55,60,65,70,65,60,55,50,55,60,65,70,65,60,55])
				}, {
					name: 'Düşük Verimli Makineler',
					color: '#EF3936',
					data: data([10,15,20,25,30,25,20,15,10,15,20,25,30,25,20,15,10,15,20,25,30,25,20,15])
				}]
			});
		
			Highcharts.chart('chart-index-all', {
				chart: chart,
				credits: credits,
				title: title,
				xAxis: {
					categories: [
						"0","","","","","","","","","","","","","","","","","","","","","","","",
						"0","","","","","","","","","","","","","","","","","","","","","","","",
						"0","","","","","","","","","","","","","","","","","","","","","","","",
						"0","","","","","","","","","","","","","","","","","","","","","","","",
						"0","","","","","","","","","","","","","","","","","","","","","","","",
						"0","","","","","","","","","","","","","","","","","","","","","","","",
					],
					lineWidth: 0,
					labels: { autoRotation: 0, padding: 0 }
				},
				yAxis: yAxis,
				legend: legend,
				series: [{
					name: 'Yüksek Verimli Makineler',
					color: '#81C56C',
					data: [
						{ name: "Perşembe: 00:00 - 01:00", y: 50 },
						{ name: "Perşembe: 01:00 - 02:00", y: 55 },
						{ name: "Perşembe: 02:00 - 03:00", y: 60 },
						{ name: "Perşembe: 03:00 - 04:00", y: 65 },
						{ name: "Perşembe: 04:00 - 05:00", y: 70 },
						{ name: "Perşembe: 05:00 - 06:00", y: 65 },
						{ name: "Perşembe: 06:00 - 07:00", y: 60 },
						{ name: "Perşembe: 07:00 - 08:00", y: 50 },
						{ name: "Perşembe: 08:00 - 09:00", y: 55 },
						{ name: "Perşembe: 09:00 - 10:00", y: 60 },
						{ name: "Perşembe: 10:00 - 11:00", y: 65 },
						{ name: "Perşembe: 11:00 - 12:00", y: 70 },
						{ name: "Perşembe: 12:00 - 13:00", y: 65 },
						{ name: "Perşembe: 13:00 - 14:00", y: 60 },
						{ name: "Perşembe: 14:00 - 15:00", y: 55 },
						{ name: "Perşembe: 15:00 - 16:00", y: 50 },
						{ name: "Perşembe: 16:00 - 17:00", y: 55 },
						{ name: "Perşembe: 17:00 - 18:00", y: 60 },
						{ name: "Perşembe: 18:00 - 19:00", y: 65 },
						{ name: "Perşembe: 19:00 - 20:00", y: 70 },
						{ name: "Perşembe: 20:00 - 21:00", y: 65 },
						{ name: "Perşembe: 21:00 - 22:00", y: 60 },
						{ name: "Perşembe: 22:00 - 23:00", y: 55 },
						{ name: "Perşembe: 23:00 - 24:00", y: 50 },
						{ name: "Cuma: 00:00 - 01:00", y: 50 },
						{ name: "Cuma: 01:00 - 02:00", y: 55 },
						{ name: "Cuma: 02:00 - 03:00", y: 60 },
						{ name: "Cuma: 03:00 - 04:00", y: 65 },
						{ name: "Cuma: 04:00 - 05:00", y: 70 },
						{ name: "Cuma: 05:00 - 06:00", y: 65 },
						{ name: "Cuma: 06:00 - 07:00", y: 60 },
						{ name: "Cuma: 07:00 - 08:00", y: 50 },
						{ name: "Cuma: 08:00 - 09:00", y: 55 },
						{ name: "Cuma: 09:00 - 10:00", y: 60 },
						{ name: "Cuma: 10:00 - 11:00", y: 65 },
						{ name: "Cuma: 11:00 - 12:00", y: 70 },
						{ name: "Cuma: 12:00 - 13:00", y: 65 },
						{ name: "Cuma: 13:00 - 14:00", y: 60 },
						{ name: "Cuma: 14:00 - 15:00", y: 55 },
						{ name: "Cuma: 15:00 - 16:00", y: 50 },
						{ name: "Cuma: 16:00 - 17:00", y: 55 },
						{ name: "Cuma: 17:00 - 18:00", y: 60 },
						{ name: "Cuma: 18:00 - 19:00", y: 65 },
						{ name: "Cuma: 19:00 - 20:00", y: 70 },
						{ name: "Cuma: 20:00 - 21:00", y: 65 },
						{ name: "Cuma: 21:00 - 22:00", y: 60 },
						{ name: "Cuma: 22:00 - 23:00", y: 55 },
						{ name: "Cuma: 23:00 - 24:00", y: 50 },
						{ name: "Cumartesi: 00:00 - 01:00", y: 50 },
						{ name: "Cumartesi: 01:00 - 02:00", y: 55 },
						{ name: "Cumartesi: 02:00 - 03:00", y: 60 },
						{ name: "Cumartesi: 03:00 - 04:00", y: 65 },
						{ name: "Cumartesi: 04:00 - 05:00", y: 70 },
						{ name: "Cumartesi: 05:00 - 06:00", y: 65 },
						{ name: "Cumartesi: 06:00 - 07:00", y: 60 },
						{ name: "Cumartesi: 07:00 - 08:00", y: 50 },
						{ name: "Cumartesi: 08:00 - 09:00", y: 55 },
						{ name: "Cumartesi: 09:00 - 10:00", y: 60 },
						{ name: "Cumartesi: 10:00 - 11:00", y: 65 },
						{ name: "Cumartesi: 11:00 - 12:00", y: 70 },
						{ name: "Cumartesi: 12:00 - 13:00", y: 65 },
						{ name: "Cumartesi: 13:00 - 14:00", y: 60 },
						{ name: "Cumartesi: 14:00 - 15:00", y: 55 },
						{ name: "Cumartesi: 15:00 - 16:00", y: 50 },
						{ name: "Cumartesi: 16:00 - 17:00", y: 55 },
						{ name: "Cumartesi: 17:00 - 18:00", y: 60 },
						{ name: "Cumartesi: 18:00 - 19:00", y: 65 },
						{ name: "Cumartesi: 19:00 - 20:00", y: 70 },
						{ name: "Cumartesi: 20:00 - 21:00", y: 65 },
						{ name: "Cumartesi: 21:00 - 22:00", y: 60 },
						{ name: "Cumartesi: 22:00 - 23:00", y: 55 },
						{ name: "Cumartesi: 23:00 - 24:00", y: 50 },
						{ name: "Pazartesi: 00:00 - 01:00", y: 50 },
						{ name: "Pazartesi: 01:00 - 02:00", y: 55 },
						{ name: "Pazartesi: 02:00 - 03:00", y: 60 },
						{ name: "Pazartesi: 03:00 - 04:00", y: 65 },
						{ name: "Pazartesi: 04:00 - 05:00", y: 70 },
						{ name: "Pazartesi: 05:00 - 06:00", y: 65 },
						{ name: "Pazartesi: 06:00 - 07:00", y: 60 },
						{ name: "Pazartesi: 07:00 - 08:00", y: 50 },
						{ name: "Pazartesi: 08:00 - 09:00", y: 55 },
						{ name: "Pazartesi: 09:00 - 10:00", y: 60 },
						{ name: "Pazartesi: 10:00 - 11:00", y: 65 },
						{ name: "Pazartesi: 11:00 - 12:00", y: 70 },
						{ name: "Pazartesi: 12:00 - 13:00", y: 65 },
						{ name: "Pazartesi: 13:00 - 14:00", y: 60 },
						{ name: "Pazartesi: 14:00 - 15:00", y: 55 },
						{ name: "Pazartesi: 15:00 - 16:00", y: 50 },
						{ name: "Pazartesi: 16:00 - 17:00", y: 55 },
						{ name: "Pazartesi: 17:00 - 18:00", y: 60 },
						{ name: "Pazartesi: 18:00 - 19:00", y: 65 },
						{ name: "Pazartesi: 19:00 - 20:00", y: 70 },
						{ name: "Pazartesi: 20:00 - 21:00", y: 65 },
						{ name: "Pazartesi: 21:00 - 22:00", y: 60 },
						{ name: "Pazartesi: 22:00 - 23:00", y: 55 },
						{ name: "Pazartesi: 23:00 - 24:00", y: 50 },
						{ name: "Salı: 00:00 - 01:00", y: 50 },
						{ name: "Salı: 01:00 - 02:00", y: 55 },
						{ name: "Salı: 02:00 - 03:00", y: 60 },
						{ name: "Salı: 03:00 - 04:00", y: 65 },
						{ name: "Salı: 04:00 - 05:00", y: 70 },
						{ name: "Salı: 05:00 - 06:00", y: 65 },
						{ name: "Salı: 06:00 - 07:00", y: 60 },
						{ name: "Salı: 07:00 - 08:00", y: 50 },
						{ name: "Salı: 08:00 - 09:00", y: 55 },
						{ name: "Salı: 09:00 - 10:00", y: 60 },
						{ name: "Salı: 10:00 - 11:00", y: 65 },
						{ name: "Salı: 11:00 - 12:00", y: 70 },
						{ name: "Salı: 12:00 - 13:00", y: 65 },
						{ name: "Salı: 13:00 - 14:00", y: 60 },
						{ name: "Salı: 14:00 - 15:00", y: 55 },
						{ name: "Salı: 15:00 - 16:00", y: 50 },
						{ name: "Salı: 16:00 - 17:00", y: 55 },
						{ name: "Salı: 17:00 - 18:00", y: 60 },
						{ name: "Salı: 18:00 - 19:00", y: 65 },
						{ name: "Salı: 19:00 - 20:00", y: 70 },
						{ name: "Salı: 20:00 - 21:00", y: 65 },
						{ name: "Salı: 21:00 - 22:00", y: 60 },
						{ name: "Salı: 22:00 - 23:00", y: 55 },
						{ name: "Salı: 23:00 - 24:00", y: 50 },
						{ name: "Çarşamba: 00:00 - 01:00", y: 50 },
						{ name: "Çarşamba: 01:00 - 02:00", y: 55 },
						{ name: "Çarşamba: 02:00 - 03:00", y: 60 },
						{ name: "Çarşamba: 03:00 - 04:00", y: 65 },
						{ name: "Çarşamba: 04:00 - 05:00", y: 70 },
						{ name: "Çarşamba: 05:00 - 06:00", y: 65 },
						{ name: "Çarşamba: 06:00 - 07:00", y: 60 },
						{ name: "Çarşamba: 07:00 - 08:00", y: 50 },
						{ name: "Çarşamba: 08:00 - 09:00", y: 55 },
						{ name: "Çarşamba: 09:00 - 10:00", y: 60 },
						{ name: "Çarşamba: 10:00 - 11:00", y: 65 },
						{ name: "Çarşamba: 11:00 - 12:00", y: 70 },
						{ name: "Çarşamba: 12:00 - 13:00", y: 65 },
						{ name: "Çarşamba: 13:00 - 14:00", y: 60 },
						{ name: "Çarşamba: 14:00 - 15:00", y: 55 },
						{ name: "Çarşamba: 15:00 - 16:00", y: 50 },
						{ name: "Çarşamba: 16:00 - 17:00", y: 55 },
						{ name: "Çarşamba: 17:00 - 18:00", y: 60 },
						{ name: "Çarşamba: 18:00 - 19:00", y: 65 },
						{ name: "Çarşamba: 19:00 - 20:00", y: 70 },
						{ name: "Çarşamba: 20:00 - 21:00", y: 65 },
						{ name: "Çarşamba: 21:00 - 22:00", y: 60 },
						{ name: "Çarşamba: 22:00 - 23:00", y: 55 },
						{ name: "Çarşamba: 23:00 - 24:00", y: 50 }
					]
				}, {
					name: 'Düşük Verimli Makineler',
					color: '#EF3936',
					data: [
						{ name: "Perşembe: 00:00 - 01:00", y: 10 },
						{ name: "Perşembe: 01:00 - 02:00", y: 15 },
						{ name: "Perşembe: 02:00 - 03:00", y: 20 },
						{ name: "Perşembe: 03:00 - 04:00", y: 25 },
						{ name: "Perşembe: 04:00 - 05:00", y: 30 },
						{ name: "Perşembe: 05:00 - 06:00", y: 25 },
						{ name: "Perşembe: 06:00 - 07:00", y: 20 },
						{ name: "Perşembe: 07:00 - 08:00", y: 15 },
						{ name: "Perşembe: 08:00 - 09:00", y: 10 },
						{ name: "Perşembe: 09:00 - 10:00", y: 15 },
						{ name: "Perşembe: 10:00 - 11:00", y: 20 },
						{ name: "Perşembe: 11:00 - 12:00", y: 25 },
						{ name: "Perşembe: 12:00 - 13:00", y: 30 },
						{ name: "Perşembe: 13:00 - 14:00", y: 25 },
						{ name: "Perşembe: 14:00 - 15:00", y: 20 },
						{ name: "Perşembe: 15:00 - 16:00", y: 15 },
						{ name: "Perşembe: 16:00 - 17:00", y: 10 },
						{ name: "Perşembe: 17:00 - 18:00", y: 15 },
						{ name: "Perşembe: 18:00 - 19:00", y: 20 },
						{ name: "Perşembe: 19:00 - 20:00", y: 25 },
						{ name: "Perşembe: 20:00 - 21:00", y: 30 },
						{ name: "Perşembe: 21:00 - 22:00", y: 25 },
						{ name: "Perşembe: 22:00 - 23:00", y: 20 },
						{ name: "Perşembe: 23:00 - 24:00", y: 15 },
						{ name: "Cuma: 00:00 - 01:00", y: 10 },
						{ name: "Cuma: 01:00 - 02:00", y: 15 },
						{ name: "Cuma: 02:00 - 03:00", y: 20 },
						{ name: "Cuma: 03:00 - 04:00", y: 25 },
						{ name: "Cuma: 04:00 - 05:00", y: 30 },
						{ name: "Cuma: 05:00 - 06:00", y: 25 },
						{ name: "Cuma: 06:00 - 07:00", y: 20 },
						{ name: "Cuma: 07:00 - 08:00", y: 15 },
						{ name: "Cuma: 08:00 - 09:00", y: 10 },
						{ name: "Cuma: 09:00 - 10:00", y: 15 },
						{ name: "Cuma: 10:00 - 11:00", y: 20 },
						{ name: "Cuma: 11:00 - 12:00", y: 25 },
						{ name: "Cuma: 12:00 - 13:00", y: 30 },
						{ name: "Cuma: 13:00 - 14:00", y: 25 },
						{ name: "Cuma: 14:00 - 15:00", y: 20 },
						{ name: "Cuma: 15:00 - 16:00", y: 15 },
						{ name: "Cuma: 16:00 - 17:00", y: 10 },
						{ name: "Cuma: 17:00 - 18:00", y: 15 },
						{ name: "Cuma: 18:00 - 19:00", y: 20 },
						{ name: "Cuma: 19:00 - 20:00", y: 25 },
						{ name: "Cuma: 20:00 - 21:00", y: 30 },
						{ name: "Cuma: 21:00 - 22:00", y: 25 },
						{ name: "Cuma: 22:00 - 23:00", y: 20 },
						{ name: "Cuma: 23:00 - 24:00", y: 15 },
						{ name: "Cumartesi: 00:00 - 01:00", y: 10 },
						{ name: "Cumartesi: 01:00 - 02:00", y: 15 },
						{ name: "Cumartesi: 02:00 - 03:00", y: 20 },
						{ name: "Cumartesi: 03:00 - 04:00", y: 25 },
						{ name: "Cumartesi: 04:00 - 05:00", y: 30 },
						{ name: "Cumartesi: 05:00 - 06:00", y: 25 },
						{ name: "Cumartesi: 06:00 - 07:00", y: 20 },
						{ name: "Cumartesi: 07:00 - 08:00", y: 15 },
						{ name: "Cumartesi: 08:00 - 09:00", y: 10 },
						{ name: "Cumartesi: 09:00 - 10:00", y: 15 },
						{ name: "Cumartesi: 10:00 - 11:00", y: 20 },
						{ name: "Cumartesi: 11:00 - 12:00", y: 25 },
						{ name: "Cumartesi: 12:00 - 13:00", y: 30 },
						{ name: "Cumartesi: 13:00 - 14:00", y: 25 },
						{ name: "Cumartesi: 14:00 - 15:00", y: 20 },
						{ name: "Cumartesi: 15:00 - 16:00", y: 15 },
						{ name: "Cumartesi: 16:00 - 17:00", y: 10 },
						{ name: "Cumartesi: 17:00 - 18:00", y: 15 },
						{ name: "Cumartesi: 18:00 - 19:00", y: 20 },
						{ name: "Cumartesi: 19:00 - 20:00", y: 25 },
						{ name: "Cumartesi: 20:00 - 21:00", y: 30 },
						{ name: "Cumartesi: 21:00 - 22:00", y: 25 },
						{ name: "Cumartesi: 22:00 - 23:00", y: 20 },
						{ name: "Cumartesi: 23:00 - 24:00", y: 15 },
						{ name: "Pazartesi: 00:00 - 01:00", y: 10 },
						{ name: "Pazartesi: 01:00 - 02:00", y: 15 },
						{ name: "Pazartesi: 02:00 - 03:00", y: 20 },
						{ name: "Pazartesi: 03:00 - 04:00", y: 25 },
						{ name: "Pazartesi: 04:00 - 05:00", y: 30 },
						{ name: "Pazartesi: 05:00 - 06:00", y: 25 },
						{ name: "Pazartesi: 06:00 - 07:00", y: 20 },
						{ name: "Pazartesi: 07:00 - 08:00", y: 15 },
						{ name: "Pazartesi: 08:00 - 09:00", y: 10 },
						{ name: "Pazartesi: 09:00 - 10:00", y: 15 },
						{ name: "Pazartesi: 10:00 - 11:00", y: 20 },
						{ name: "Pazartesi: 11:00 - 12:00", y: 25 },
						{ name: "Pazartesi: 12:00 - 13:00", y: 30 },
						{ name: "Pazartesi: 13:00 - 14:00", y: 25 },
						{ name: "Pazartesi: 14:00 - 15:00", y: 20 },
						{ name: "Pazartesi: 15:00 - 16:00", y: 15 },
						{ name: "Pazartesi: 16:00 - 17:00", y: 10 },
						{ name: "Pazartesi: 17:00 - 18:00", y: 15 },
						{ name: "Pazartesi: 18:00 - 19:00", y: 20 },
						{ name: "Pazartesi: 19:00 - 20:00", y: 25 },
						{ name: "Pazartesi: 20:00 - 21:00", y: 30 },
						{ name: "Pazartesi: 21:00 - 22:00", y: 25 },
						{ name: "Pazartesi: 22:00 - 23:00", y: 20 },
						{ name: "Pazartesi: 23:00 - 24:00", y: 15 },
						{ name: "Salı: 00:00 - 01:00", y: 10 },
						{ name: "Salı: 01:00 - 02:00", y: 15 },
						{ name: "Salı: 02:00 - 03:00", y: 20 },
						{ name: "Salı: 03:00 - 04:00", y: 25 },
						{ name: "Salı: 04:00 - 05:00", y: 30 },
						{ name: "Salı: 05:00 - 06:00", y: 25 },
						{ name: "Salı: 06:00 - 07:00", y: 20 },
						{ name: "Salı: 07:00 - 08:00", y: 15 },
						{ name: "Salı: 08:00 - 09:00", y: 10 },
						{ name: "Salı: 09:00 - 10:00", y: 15 },
						{ name: "Salı: 10:00 - 11:00", y: 20 },
						{ name: "Salı: 11:00 - 12:00", y: 25 },
						{ name: "Salı: 12:00 - 13:00", y: 30 },
						{ name: "Salı: 13:00 - 14:00", y: 25 },
						{ name: "Salı: 14:00 - 15:00", y: 20 },
						{ name: "Salı: 15:00 - 16:00", y: 15 },
						{ name: "Salı: 16:00 - 17:00", y: 10 },
						{ name: "Salı: 17:00 - 18:00", y: 15 },
						{ name: "Salı: 18:00 - 19:00", y: 20 },
						{ name: "Salı: 19:00 - 20:00", y: 25 },
						{ name: "Salı: 20:00 - 21:00", y: 30 },
						{ name: "Salı: 21:00 - 22:00", y: 25 },
						{ name: "Salı: 22:00 - 23:00", y: 20 },
						{ name: "Salı: 23:00 - 24:00", y: 15 },
						{ name: "Çarşamba: 00:00 - 01:00", y: 10 },
						{ name: "Çarşamba: 01:00 - 02:00", y: 15 },
						{ name: "Çarşamba: 02:00 - 03:00", y: 20 },
						{ name: "Çarşamba: 03:00 - 04:00", y: 25 },
						{ name: "Çarşamba: 04:00 - 05:00", y: 30 },
						{ name: "Çarşamba: 05:00 - 06:00", y: 25 },
						{ name: "Çarşamba: 06:00 - 07:00", y: 20 },
						{ name: "Çarşamba: 07:00 - 08:00", y: 15 },
						{ name: "Çarşamba: 08:00 - 09:00", y: 10 },
						{ name: "Çarşamba: 09:00 - 10:00", y: 15 },
						{ name: "Çarşamba: 10:00 - 11:00", y: 20 },
						{ name: "Çarşamba: 11:00 - 12:00", y: 25 },
						{ name: "Çarşamba: 12:00 - 13:00", y: 30 },
						{ name: "Çarşamba: 13:00 - 14:00", y: 25 },
						{ name: "Çarşamba: 14:00 - 15:00", y: 20 },
						{ name: "Çarşamba: 15:00 - 16:00", y: 15 },
						{ name: "Çarşamba: 16:00 - 17:00", y: 10 },
						{ name: "Çarşamba: 17:00 - 18:00", y: 15 },
						{ name: "Çarşamba: 18:00 - 19:00", y: 20 },
						{ name: "Çarşamba: 19:00 - 20:00", y: 25 },
						{ name: "Çarşamba: 20:00 - 21:00", y: 30 },
						{ name: "Çarşamba: 21:00 - 22:00", y: 25 },
						{ name: "Çarşamba: 22:00 - 23:00", y: 20 },
						{ name: "Çarşamba: 23:00 - 24:00", y: 15 }
					]
				}]
			});

			$('.show-chart').click(function(event){
				event.preventDefault();
				$('.chart-title').html( $( this ).attr('title') );
				$('.chart-section').hide();
				$('.show-chart').removeClass('active');
				$( $( this ).attr('href') ).show();
				$( this ).addClass('active');
			});

			$( window ).load(function(event){
				$('.chart-section').hide();
				$('.chart-title').html( $('.show-chart.active').attr('title') );
				$($('.show-chart.active').attr('href')).show();
			});
		</script>
		<?php require_once 'include/footer.php'; ?>
	</body>
</html>