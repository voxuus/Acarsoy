<!DOCTYPE html>
<html lang="tr" dir="ltr">
	<head>
		<?php require_once 'include/head.php'; ?>
	</head>
	<body>
		<header id="gb-header">
			<div class="colgroup col-middle">
				<div class="col-hd-6 col-lg-6 col-md-4 col-xs-12">
					<hgroup>
						<h1>MAKİNELER</h1>
						<h6>Uygun Kurdele Makine İzleme</h6>
					</hgroup>
				</div>
				<div class="col-hd-6 col-lg-6 col-md-8 col-xs-12">
					<div class="colgroup col-middle">
						<div class="col-hd-4 col-lg-4 col-pv-3">
							<a href="" title="" class="button">
								<span>BİLGİ GİRİŞİ</span>
								<img src="assets/images/icon/header-info.png" width="20" alt="">
							</a>
						</div>
						<div class="col-hd-4 col-lg-4 col-pv-3 button-scope">
							<a href="" title="" class="button">
								<span>DASHBOARD</span>
								<img src="assets/images/icon/header-home.png" width="20" alt="">
							</a>
						</div>
						<div class="col-hd-4 col-lg-4 col-pv-6">
							<a href="" title="" class="user-dropdown">Selçuk Aker</a>
						</div>
					</div>
				</div>
			</div>
		</header>
		<div id="container">
			<div class="colgroup">
				<div class="col-hd-10 col-lg-9 col-md-8 col-xs-12">
					<div class="events-open">OLAYLARI GÖRÜNTÜLE</div>
					<div class="panel">
						<div class="panel-title">
							<h4>Yüksek Verimli Makineler (25)</h4>
						</div>
						<div class="panel-content" style="padding-bottom: 0">
							<div class="colgroup col-hd-4 col-lg-6 col-md-12" id="machines">
								<?php for ($i=1; $i < 5; $i++) { ?>
								<div>
									<a href="" title="" class="on">
										<table>
											<caption>INT LOREM IPSUM DOLOR SIT AMET 0<?php echo $i; ?></caption>
											<tbody>
												<tr>
													<td width="30%" rowspan="3">
														<div class="pouse">
															<img src="assets/images/icon/pouse-on.png" alt="">
															<h5>Durma Adeti</h5>
															<h6>14</h6>
														</div>
														<img src="assets/images/icon/machines.png" width="110" height="95" alt="" class="machines">
													</td>
													<td width="40%">
														<h5>ÇALIŞMA SÜRESİ</h5>
														<h6>14 SAAT</h6>
													</td>
													<td width="30%" rowspan="3">
														<h3>VERİMLİLİK</h3>
														<?php $percent = rand(0,100); ?>
														<div class="svg">
															<span><?php echo $percent; ?></span>
															<svg x="0px" y="0px" viewBox="0 0 110 110" enable-background="new 0 0 110 100" xml:space="preserve">
																<circle	class="circle" cx="55" cy="55" r="52.5"/>    
																<circle class="circle-color" cx="55" cy="55" r="52.5" stroke-dasharray="<?php echo (330 / 100) * $percent; ?>, 330"/>               
															</svg>
														</div>
													</td>
												</tr>
												<tr>
													<td>
														<h5>SENSÖR ADET</h5>
														<h6>22</h6>
													</td>
												</tr>
												<tr>
													<td>
														<h5>DURMA SÜRESİ</h5>
														<h6>5 SAAT</h6>
													</td>
												</tr>
											</tbody>
											<tfoot>
												<tr>
													<td colspan="3">Selçuk Aker</td>
												</tr>
											</tfoot>
										</table>
									</a>
								</div>
								<?php } ?>
							</div>
						</div>
					</div>
					<div class="panel">
						<div class="panel-title">
							<h4>Yüksek Verimli Makineler (25)</h4>
						</div>
						<div class="panel-content" style="padding-bottom: 0">
							<div class="colgroup col-hd-4 col-lg-6 col-md-12" id="machines">
								<?php for ($i=1; $i < 5; $i++) { ?>
								<div>
									<a href="" title="" class="off">
										<table>
											<caption>INT 0<?php echo $i; ?></caption>
											<tbody>
												<tr>
													<td width="30%" rowspan="3">
														<div class="pouse">
															<img src="assets/images/icon/pouse-off.png" alt="">
															<h5>Durma Adeti</h5>
															<h6>14</h6>
														</div>
														<img src="assets/images/icon/machines.png" width="110" height="95" alt="" class="machines">
													</td>
													<td width="40%">
														<h5>ÇALIŞMA SÜRESİ</h5>
														<h6>14 SAAT</h6>
													</td>
													<td width="30%" rowspan="3">
														<h3>VERİMLİLİK</h3>
														<?php $percent = rand(0,100); ?>
														<div class="svg">
															<span><?php echo $percent; ?></span>
															<svg x="0px" y="0px" viewBox="0 0 110 110" enable-background="new 0 0 110 100" xml:space="preserve">
																<circle	class="circle" cx="55" cy="55" r="52.5"/>    
																<circle class="circle-color" cx="55" cy="55" r="52.5" stroke-dasharray="<?php echo (330 / 100) * $percent; ?>, 330"/>               
															</svg>
														</div>
													</td>
												</tr>
												<tr>
													<td>
														<h5>SENSÖR ADET</h5>
														<h6>22</h6>
													</td>
												</tr>
												<tr>
													<td>
														<h5>DURMA SÜRESİ</h5>
														<h6>5 SAAT</h6>
													</td>
												</tr>
											</tbody>
											<tfoot>
												<tr>
													<td colspan="3">Selçuk Aker</td>
												</tr>
											</tfoot>
										</table>
									</a>
								</div>
								<?php } ?>
							</div>
						</div>
					</div>
				</div>
				<div class="col-hd-2 col-lg-3 col-md-4 col-xs-12">
					<div class="panel">
						<div class="panel-title">
							<h4>Olaylar</h4>
						</div>
						<div class="panel-content" style="padding-bottom: 0">
							<div id="events">
								<div class="events-close">
									<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 52 52" xml:space="preserve">
										<path d="M26,0C11.664,0,0,11.663,0,26s11.664,26,26,26s26-11.663,26-26S40.336,0,26,0z M26,50C12.767,50,2,39.233,2,26 S12.767,2,26,2s24,10.767,24,24S39.233,50,26,50z"/>
										<path d="M35.707,16.293c-0.391-0.391-1.023-0.391-1.414,0L26,24.586l-8.293-8.293c-0.391-0.391-1.023-0.391-1.414,0 s-0.391,1.023,0,1.414L24.586,26l-8.293,8.293c-0.391,0.391-0.391,1.023,0,1.414C16.488,35.902,16.744,36,17,36 s0.512-0.098,0.707-0.293L26,27.414l8.293,8.293C34.488,35.902,34.744,36,35,36s0.512-0.098,0.707-0.293 c0.391-0.391,0.391-1.023,0-1.414L27.414,26l8.293-8.293C36.098,17.316,36.098,16.684,35.707,16.293z"/>
									</svg>
								</div>
								<ul>
									<?php for ($i=0; $i < 10; $i++) { ?>
									<li>
										<time datetime="2017-01-12">2017-01-12</time>
										<p>INT 28 Çok Isındı.</p>
									</li>
									<?php } ?>
								</ul>
							</div>
							<div class="events-open" style="margin-bottom: 15px">OLAYLARI GÖRÜNTÜLE</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php require_once 'include/footer.php'; ?>
		<script type="text/javascript">
			App.event.eventToggleClick();
		</script>
	</body>
</html>