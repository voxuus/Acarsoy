<!DOCTYPE html>
<html lang="en" dir="ltr">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
		<title>Makine İzleme - Robosoft</title>
		<link href="http://developers.tingoon.com/relocation/relocation.css" rel="stylesheet">
	</head>
	<body>
		<header>
			<h6>Robosoft</h6>
			<h1>Makine İzleme</h1>
			<p>Aşağıdaki linklere tıklayarak mevcut tüm projeleri görebilirsiniz.</p>
			<nav>
				<a href="index.php" title="Projeye git">
					<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 31.494 31.494" xml:space="preserve" width="18px" height="18px">
						<path d="M10.273,5.009c0.444-0.444,1.143-0.444,1.587,0c0.429,0.429,0.429,1.143,0,1.571l-8.047,8.047h26.554  c0.619,0,1.127,0.492,1.127,1.111c0,0.619-0.508,1.127-1.127,1.127H3.813l8.047,8.032c0.429,0.444,0.429,1.159,0,1.587  c-0.444,0.444-1.143,0.444-1.587,0l-9.952-9.952c-0.429-0.429-0.429-1.143,0-1.571L10.273,5.009z"/>
					</svg>
				</a>
				<a href="http://robosoft.com.tr/" title="Robosoft'a git" target="_blank">
					<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 83.668 83.669" xml:space="preserve" width="16.5px" height="16.5px">
						<path d="M41.834,0c0,0-28.514,39.405-28.514,55.151c0,15.749,12.767,28.518,28.514,28.518c15.749,0,28.514-12.769,28.514-28.518 C70.348,39.405,41.834,0,41.834,0z M23.37,43.167c0,0-0.703,13.895,14.291,32.265C37.661,75.432,14.438,65.008,23.37,43.167z"/>
					</svg>
				</a>
			</nav>
		</header>
		<section>
			<ul class="ul-file-item">
				<li class="li-file-item"><a href="index.php" title="Anasayafa" target="_blank" class="a-file-item">Anasayfa</a></li>
				<li class="li-file-item"><a href="machines.php" title="Makineler" target="_blank" class="a-file-item">Makineler</a></li>
				<li class="li-file-item"><a href="addinfo.php" title="Bilgi Ekle" target="_blank" class="a-file-item">Bilgi Ekle</a></li>
				<li class="li-file-item"><a href="signin.php" title="Giriş Yap" target="_blank" class="a-file-item">Giriş Yap</a></li>
			</ul>
		</section>
	</body>
</html>