<!DOCTYPE html>
<html lang="tr" dir="ltr">
	<head>
		<?php require_once 'include/head.php'; ?>
		<link rel="stylesheet" href="plugin/bootstrap-datepicker/bootstrap-datepicker.css">
		<link rel="stylesheet" href="plugin/bootstrap-datepicker/bootstrap-datepicker3.min.css">
		<link rel="stylesheet" href="plugin/bootstrap-datepicker/bootstrap-datepicker3.standalone.min.css">
		<script src="plugin/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
		<script src="plugin/bootstrap-datepicker/bootstrap-datepicker.tr.min.js"></script>
	</head>
	<body>
		<header id="gb-header">
			<div class="colgroup col-middle">
				<div class="col-hd-6 col-lg-6 col-md-4 col-xs-12">
					<hgroup>
						<h1>MAKİNELER</h1>
						<h6>Uygun Kurdele Makine İzleme</h6>
					</hgroup>
				</div>
				<div class="col-hd-6 col-lg-6 col-md-8 col-xs-12">
					<div class="colgroup col-middle">
						<div class="col-hd-4 col-lg-4 col-pv-3">
							<a href="" title="" class="button">
								<span>BİLGİ GİRİŞİ</span>
								<img src="assets/images/icon/header-info.png" width="20" alt="">
							</a>
						</div>
						<div class="col-hd-4 col-lg-4 col-pv-3 button-scope">
							<a href="" title="" class="button">
								<span>DASHBOARD</span>
								<img src="assets/images/icon/header-home.png" width="20" alt="">
							</a>
						</div>
						<div class="col-hd-4 col-lg-4 col-pv-6">
							<a href="" title="" class="user-dropdown">Selçuk Aker</a>
						</div>
					</div>
				</div>
			</div>
		</header>
		<div id="container">
			<div id="machines">
				<div class="colgroup">
					<div class="col-hd-2 col-lg-2 col-md-3 col-sm-6 col-pv-12">
						<input type="text" class="form-control" placeholder="Başlangıç">
					</div>
					<div class="col-hd-2 col-lg-2 col-md-3 col-sm-6 col-pv-12">
						<input type="text" class="form-control" placeholder="Bitiş">
					</div>
					<div class="col-hd-2 col-lg-2 col-md-3 col-sm-6 col-pv-12">
						<select name="">
							<option value="">Son bir gün</option>
							<option value="">Son bir hafta</option>
							<option value="">Son bir ay</option>
							<option value="">Son bir yıl</option>
						</select>
					</div>
					<div class="col-hd-6 col-lg-6 col-md-3 col-sm-6 col-pv-12">
						<button type="submit">ARA</button>
					</div>
					<script>
						$(function(){
							$('.form-control').each(function(){
								$(this).datepicker('clearDates');
							});
						});
					</script>
				</div>
				<hr>
				<div class="colgroup">
					<?php for ($i=1; $i < 10; $i++) { ?>
					<div class="col-hd-4 col-lg-4 col-md-6 col-sm-12">
						<a href="" title="">
							<table>
								<caption>INT 0<?php echo $i; ?></caption>
								<tbody>
									<tr>
										<td width="30%" rowspan="3">
											<div class="pouse">
												<img src="assets/images/icon/pouse-off.png" alt="">
												<h5>Durma Adeti</h5>
												<h6>14</h6>
											</div>
											<img src="assets/images/icon/machines.png" width="110" height="95" alt="" class="machines">
										</td>
										<td width="40%">
											<h5>ÇALIŞMA SÜRESİ</h5>
											<h6>14 SAAT</h6>
										</td>
										<td width="30%" rowspan="3">
											<h3>VERİMLİLİK</h3>
											<?php $percent = rand(0,100); ?>
											<div class="svg">
												<span><?php echo $percent; ?></span>
												<svg x="0px" y="0px" viewBox="0 0 110 110" enable-background="new 0 0 110 100" xml:space="preserve">
													<circle	class="circle" cx="55" cy="55" r="52.5"/>    
													<circle class="circle-color" cx="55" cy="55" r="52.5" stroke-dasharray="<?php echo (330 / 100) * $percent; ?>, 330"/>               
												</svg>
											</div>
										</td>
									</tr>
									<tr>
										<td>
											<h5>SENSÖR ADET</h5>
											<h6>22</h6>
										</td>
									</tr>
									<tr>
										<td>
											<h5>DURMA SÜRESİ</h5>
											<h6>5 SAAT</h6>
										</td>
									</tr>
								</tbody>
							</table>
						</a>
					</div>
					<?php } ?>
				</div>
			</div>
		</div>
		<?php require_once 'include/footer.php'; ?>
		<script type="text/javascript">
			App.event.eventToggleClick();
		</script>
	</body>
</html>