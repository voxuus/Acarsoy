<!DOCTYPE html>
<html lang="tr" dir="ltr">
	<head>
		<?php require_once 'include/head.php'; ?>
	</head>
	<body>
		<div id="signin-backface"></div>
		<div id="signin">
			<div style="display: table-cell; vertical-align: middle;">
				<div id="signin-scope">
					<div class="child-1 sm-none-i">
						<h1>MAKİNE İZLEME YAZILIMI</h1>
						<h6>Üretim gücünüzü<br>kontrol edin!</h6>
					</div>
					<div class="child-2">
						<h2>Sisteme Giriş Yapın</h2>
						<form action="" method="get" accept-charset="utf-8">
							<input type="text" placeholder="Kullanıcı Adı">
							<input type="password" placeholder="Şifre">
							<button type="submit">GİRİŞ YAP</button>
							<div class="colgroup col-middle">
								<div class="col-hd-6 col-lg-6">
									<div style="font-size: 0;">
										<input type="checkbox" name="rememberme" id="rememberme">
										<label for="rememberme">Beni hatırla</label>
									</div>
								</div>
								<div class="col-hd-6 col-lg-6">
									<div style="text-align: right;">
										<a href="" title="" class="iforgot">Şifremi unuttum.</a>
									</div>
								</div>
							</div>
							<p>© 2017 Uygun Kurdele Makine İzleme</p>
						</form>
					</div>
				</div>
			</div>
		</div>
		<style type="text/css" media="screen">
			.uygun {
				position: absolute;
				bottom: 15px;
				left: 15px;
				height: 18px;
				z-index: 500;
			}
		</style>
		<svg class="uygun" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 604.17 87.37"><defs><linearGradient id="linear-gradient" x1="76.98" y1="41.13" x2="160.7" y2="41.58" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#9b000f"/><stop offset="0.07" stop-color="#ed1c24"/><stop offset="0.07" stop-color="#ff929a"/><stop offset="0.22" stop-color="#af000d"/><stop offset="0.7" stop-color="#960010"/><stop offset="0.86" stop-color="#cf0e19"/><stop offset="0.9" stop-color="#dd535e"/></linearGradient><linearGradient id="linear-gradient-2" x1="83.09" y1="35.08" x2="114.61" y2="35.08" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#600002"/><stop offset="0.21" stop-color="#9e000e"/><stop offset="1" stop-color="#510000"/></linearGradient><linearGradient id="linear-gradient-3" x1="101.83" y1="37.07" x2="14.1" y2="7.68" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#9b000f"/><stop offset="0.07" stop-color="#ed1c24"/><stop offset="0.07" stop-color="#ff929a"/><stop offset="0.21" stop-color="#ed1c24"/><stop offset="0.28" stop-color="#d7121c"/><stop offset="0.37" stop-color="#c50a15"/><stop offset="0.48" stop-color="#b80410"/><stop offset="0.62" stop-color="#b1010e"/><stop offset="0.96" stop-color="#af000d"/></linearGradient></defs><title>Varlık 2</title><g id="katman_2" data-name="katman 2"><g id="Objects"><path d="M94,87.37a33.71,33.71,0,0,1-13.76-2.84,37.4,37.4,0,0,1-11.3-7.64A35.24,35.24,0,0,1,58.49,51.77V0H72V51.77a21.54,21.54,0,0,0,1.7,8.46A22.26,22.26,0,0,0,85.32,72.09a20.42,20.42,0,0,0,8.4,1.77h55.43V0h13.51V87.37Z" style="fill:#fff"/><path d="M272.37,0V51.89a34.39,34.39,0,0,1-2.78,13.76A36.52,36.52,0,0,1,262,77a35.25,35.25,0,0,1-25.13,10.42H174.52V73.86h62.37a21.09,21.09,0,0,0,8.4-1.7,22.46,22.46,0,0,0,6.94-4.61,22.4,22.4,0,0,0,6.63-15.28H203.68a33.71,33.71,0,0,1-13.76-2.84,37.39,37.39,0,0,1-11.3-7.64,35.24,35.24,0,0,1-10.42-25.12V0h13.51V16.67a21.53,21.53,0,0,0,1.7,8.46A22.26,22.26,0,0,0,195,37a20.42,20.42,0,0,0,8.4,1.77h55.43V0Z" style="fill:#fff"/><path d="M286.89,77a36,36,0,0,1-7.7-11.43,34.49,34.49,0,0,1-2.78-13.7V35.6a34.16,34.16,0,0,1,2.84-13.82A35.93,35.93,0,0,1,298.19,2.84,34.15,34.15,0,0,1,312,0h70.7V13.64H312A22.05,22.05,0,0,0,296.42,20,22.82,22.82,0,0,0,291.69,27a20.72,20.72,0,0,0-1.77,8.52V51.89a21.1,21.1,0,0,0,1.7,8.4,22.7,22.7,0,0,0,4.67,7,22.26,22.26,0,0,0,6.94,4.8,20.72,20.72,0,0,0,8.52,1.77h57.32V51H316.81V37.5h65.91V87.37H312a34.8,34.8,0,0,1-13.83-2.78A35.49,35.49,0,0,1,286.89,77Z" style="fill:#fff"/><path d="M426,87.37a33.71,33.71,0,0,1-13.76-2.84A37.39,37.39,0,0,1,401,76.89a35.24,35.24,0,0,1-10.42-25.12V0h13.51V51.77a21.53,21.53,0,0,0,1.71,8.46,22.25,22.25,0,0,0,11.62,11.87,20.42,20.42,0,0,0,8.4,1.77h55.43V0H494.7V87.37Z" style="fill:#fff"/><path d="M568.69,0a33.72,33.72,0,0,1,13.76,2.84,37.47,37.47,0,0,1,11.3,7.64,34.9,34.9,0,0,1,7.64,11.36,35.31,35.31,0,0,1,2.78,13.89V87.37H590.66V35.73a21.41,21.41,0,0,0-1.7-8.52,22.73,22.73,0,0,0-4.67-7,22.31,22.31,0,0,0-6.94-4.8,20.45,20.45,0,0,0-8.4-1.77H513.51V87.37H500V0Z" style="fill:#fff"/><path d="M84.86,41.87l-1.57,9.08s-1.59,5.54,8.5,5.74S123,42.19,132.67,47.2c0,0-7.37-8.5-12.91-10.41a131.94,131.94,0,0,1,7.87-10.86S107,25.93,84.86,41.87Z" style="fill:url(#linear-gradient)"/><path d="M114.61,21.95l-4.12,12.3s.31,4.62-8.4,5.61-18.21,4.75-19,12.27l3.36-19.51s6.45-8.4,6.59-9,11.62-4.95,12.41-5.54S114.61,21.95,114.61,21.95Z" style="fill:url(#linear-gradient-2)"/><path d="M15.79,7.27s19.85,10.56,39.63,10c38.75-1,43.11-22.59,58.19-13.9,4.06,2.34,3.26,8.26,3.26,8.45a31,31,0,0,1-1.28,6.78c-1,3.91-5.74,17.42-5.74,17.42s1.31-3.79-1.27-5.91c-.82-.67-6.27-4.35-14.8,1.94C89.31,35.4,57.7,66.31,0,40.18L21.53,29.76Z" style="fill:url(#linear-gradient-3)"/></g></g></svg>
	</body>
</html>