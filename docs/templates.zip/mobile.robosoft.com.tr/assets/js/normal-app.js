$(function(){
	
	'use strict';

	var header = function()
	{
		var windowOuterHeight = $( window ).outerHeight(),
			headerOuterHeight = $("#gb-header").outerHeight();					

		$("#gb-view").css({
			marginTop: headerOuterHeight
		});

		$("#gb-view.fullheight").css({
			height   : windowOuterHeight - headerOuterHeight
		});

		var viewInnerHeight   = $("#gb-view").innerHeight(),
			viewPadding       = parseInt($("#gb-view").css('padding-top')),
			titleOuterHeight  = $("#gb-view > h1").outerHeight();

			viewInnerHeight = ( viewInnerHeight - ( titleOuterHeight + viewPadding ) );

		$("#gb-content").css({
			height: viewInnerHeight
		});

		$("#menu-open").click(function(event){
			event.preventDefault();
			$("body").css("overflow","hidden");
			$("#gb-nav").fadeIn();
		});

		$("#menu-close").click(function(event){
			event.preventDefault();
			$("body").css("overflow","");
			$("#gb-nav").fadeOut();
		});
	};

	$("#mobile-nav-open span").click(function(event){
		event.preventDefault();
		$("body").css("overflow","hidden");
		$("#md-mobilemenu").fadeIn();
	});

	$("#md-mobilemenu-close").click(function(event){
		event.preventDefault();
		$("body").css("overflow","");
		$("#md-mobilemenu").fadeOut();
	});

	$('#call-form-open').click(function(event){
		event.preventDefault();
		$('#call-form').fadeIn();
	});

	$('#call-form-close').click(function(event){
		event.preventDefault();
		$('#call-form').fadeOut();
	});

	$( window ).resize(function(event)
	{
		/* The page adjusts its height above it. */
		header();
	})

	$( window ).load(function(event)
	{
		/* The page adjusts its height above it. */
		header();

		setTimeout(function(){
			$('#loading-mask').fadeOut();
		}, 2000);
	});

});