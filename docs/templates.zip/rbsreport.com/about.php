<!DOCTYPE html>
<html lang="en" dir="ltr">
	<head>
		<?php require_once('include/head.php'); ?>
	</head>
	<body>
		<?php require_once('include/header.php'); ?>
		<div id="global-title">
			<div class="container">
				<h1>About Us</h1>
			</div>
		</div>
		<div class="container main">
			<div class="colgroup">
				<div class="col-hd-6 col-lg-6 col-xs-12">
					<img src="media/about.jpg" width="100%" alt="">
					<div class="hd-none lg-none xs-show">
						<br>
					</div>
				</div>
				<div class="col-hd-6 col-lg-6 col-xs-12">
					<div class="normal-text">
						<h2>RBS Report</h2>
						<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic.<br><br> Typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently.</p>
						<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic.</p>
					</div>
				</div>
			</div>
		</div>
		<div id="page-nav-links">
			<div class="container">
				<div class="colgroup col-hd-4 col-lg-4 col-lg-4 col-xs-12">
					<div>
						<a href="" title="" class="contact-us-link">
							<h6>Contact Us</h6>
							<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</p>
						</a>
					</div>
					<div>
						<a href="" title="" class="support-link">
							<h6>Support</h6>
							<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</p>
						</a>
					</div>
					<div>
						<a href="" title="" class="faq-link">
							<h6>FAQ</h6>
							<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</p>
						</a>
					</div>
				</div>
			</div>
		</div>
		<?php require_once('include/footer.php'); ?>
	</body>
</html>