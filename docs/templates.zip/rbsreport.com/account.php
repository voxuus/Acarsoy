<!DOCTYPE html>
<html lang="en" dir="ltr">
	<head>
		<?php require_once('include/head.php'); ?>
	</head>
	<body>
		<?php require_once('include/header.php'); ?>
		<div id="global-title">
			<div class="container">
				<h1>Account</h1>
			</div>
		</div>
		<div class="container main">
			<div class="colgroup">
				<div class="col-hd-3 col-lg-3 col-xs-12">
					<aside class="sidebar">
						<ul>
							<li><a href="account" title="" class="active">Bilgi güncelleme</a></li>
							<li><a href="transfer-notice-form" title="">Havale Bildirim Formu</a></li>
							<li><a href="my-purchases" title="">Satın Aldıklarım</a></li>
						</ul>
					</aside>
				</div>
				<div class="col-hd-9 col-lg-9 col-xs-12">
					<div class="normal-text"><h2>Bilgileri Güncelle</h2></div>
					<form action="" method="get" accept-charset="utf-8">
						<div class="form-row">
							<div class="colgroup col-hd-6 col-lg-6 col-xs-12">
								<div>
									<input type="" name="" placeholder="First name" value="Aras">
								</div>
								<div>
									<input type="" name="" placeholder="Last name" value="Ekinci">
								</div>
							</div>
						</div>
						<div class="form-row">
							<div class="colgroup col-hd-6 col-lg-6 col-xs-12">
								<div>
									<input type="" name="" placeholder="E-mail" value="info@arasekinci.com.tr">
								</div>
								<div>
									<input type="" name="" placeholder="Phone" value="0544 268 47 15">
								</div>
							</div>
						</div>
						<div class="form-row">
							<textarea type="" name="" placeholder="Address">Sincap sokak, yalı mahallesi no:2 - Kadıköy / İstanbul</textarea>
						</div>
						<div class="form-row ta-r">
							<button type="submit">UPDATE</button>
						</div>
					</form>
				</div>
			</div>
		</div>
		<?php require_once('include/footer.php'); ?>
	</body>
</html>