/*/
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
#                                                                           #
#   Copyright © ISBU UZMAN                                                  #
#                                                                           #
#   @author    : ARAS EKINCI                                                #
#   @url       : www.arasekinci.com.tr                                      #
#   @mail      : info@arasekinci.com.tr                                     #
#   @starting  : February 13, 2017                                          #
#   @example   : isteuzman.com                                              #
#                                                                           #
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
/*/

'use strict';

var app;

$(function(){

	if ( $( window ).outerWidth() >= 991 )
	{
		$(".todobox").lightbox({
			fixed: true,
			labels: {
				close         : '',
				count         : '. Fotoğraf, Toplam',
				next          : '<svg enable-background="new 0 0 32 32" width="35px" height="35px" version="1.1" viewBox="0 0 32 32" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><path clip-rule="evenodd" d="M21.698,15.286l-9.002-8.999  c-0.395-0.394-1.035-0.394-1.431,0c-0.395,0.394-0.395,1.034,0,1.428L19.553,16l-8.287,8.285c-0.395,0.394-0.395,1.034,0,1.429  c0.395,0.394,1.036,0.394,1.431,0l9.002-8.999C22.088,16.325,22.088,15.675,21.698,15.286z" fill="#fff" fill-rule="evenodd"/></svg>',
				previous      : '<svg enable-background="new 0 0 32 32" width="35px" height="35px" version="1.1" viewBox="0 0 32 32" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><path clip-rule="evenodd" d="M11.262,16.714l9.002,8.999  c0.395,0.394,1.035,0.394,1.431,0c0.395-0.394,0.395-1.034,0-1.428L13.407,16l8.287-8.285c0.395-0.394,0.395-1.034,0-1.429  c-0.395-0.394-1.036-0.394-1.431,0l-9.002,8.999C10.872,15.675,10.872,16.325,11.262,16.714z" fill="#fff" fill-rule="evenodd"/></svg>',
				captionClosed : "Yazıyı Görüntüle",
				captionOpen   : "Yazıyı Görüntüle"
			}
		});
	}
	else
	{
		$(".todobox").lightbox({
			mobile: true,
			labels: {
				close         : '',
				count         : '. Fotoğraf, Toplam',
				next          : '<svg enable-background="new 0 0 32 32" width="35px" height="35px" version="1.1" viewBox="0 0 32 32" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><path clip-rule="evenodd" d="M21.698,15.286l-9.002-8.999  c-0.395-0.394-1.035-0.394-1.431,0c-0.395,0.394-0.395,1.034,0,1.428L19.553,16l-8.287,8.285c-0.395,0.394-0.395,1.034,0,1.429  c0.395,0.394,1.036,0.394,1.431,0l9.002-8.999C22.088,16.325,22.088,15.675,21.698,15.286z" fill="#fff" fill-rule="evenodd"/></svg>',
				previous      : '<svg enable-background="new 0 0 32 32" width="35px" height="35px" version="1.1" viewBox="0 0 32 32" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><path clip-rule="evenodd" d="M11.262,16.714l9.002,8.999  c0.395,0.394,1.035,0.394,1.431,0c0.395-0.394,0.395-1.034,0-1.428L13.407,16l8.287-8.285c0.395-0.394,0.395-1.034,0-1.429  c-0.395-0.394-1.036-0.394-1.431,0l-9.002,8.999C10.872,15.675,10.872,16.325,11.262,16.714z" fill="#fff" fill-rule="evenodd"/></svg>',
				captionClosed : "Yazıyı Görüntüle",
				captionOpen   : "Yazıyı Görüntüle"
			}
		});
	}

	$("#mobile-nav-open span").click(function(event){
		event.preventDefault();
		$("body").css("overflow","hidden");
		$("#md-mobilemenu").fadeIn();
	});

	$("#md-mobilemenu-close").click(function(event){
		event.preventDefault();
		$("body").css("overflow","");
		$("#md-mobilemenu").fadeOut();
	});

	$("#product-nav-open").click(function(event){
		event.preventDefault();
		$('html, body').animate({ scrollTop: $('#global-header').outerHeight() }, 1000);
		$("body").css('overflow','hidden');
		$("#product-nav").fadeIn().css('top', $('#global-header').outerHeight());
	});

	$("#product-nav-close").click(function(event){
		event.preventDefault();
		$('html, body').animate({ scrollTop: 0 }, 1000);
		$("body").css('overflow','');
		$("#product-nav").fadeOut();
	});

	$("#product-nav li").mouseover(function(event){
		$("#product-nav li a").removeClass("active");
		$("#product-nav .li-item").hide();
		$("#product-nav .li-item:eq("+ $( this ).index() +")").show();
	});
	
	var distributorIndex = -1;

	$(".distributors > ul > li > a").click(function(event){
		event.preventDefault();
		var parentIndex = $( this ).parent().index();

		if ( parentIndex === distributorIndex )
		{
			$(".distributors > ul > li > a").removeClass('active');
			$(".distributors > ul > li > .content").slideUp();
			distributorIndex = -1;
		}
		else
		{
			$(".distributors > ul > li > a").removeClass('active');
			$(".distributors > ul > li > .content").slideUp();

			$( this ).addClass('active');
			$( this ).siblings('.content').slideDown();
			
			distributorIndex = parentIndex;
		}
	});

});