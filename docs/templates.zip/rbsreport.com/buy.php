<!DOCTYPE html>
<html lang="en" dir="ltr">
	<head>
		<?php require_once('include/head.php'); ?>
	</head>
	<body>
		<?php require_once('include/header.php'); ?>
		<link rel="stylesheet" type="text/css" href="plugin/switchery/switchery.css">
		<script src="plugin/switchery/switchery.js" type="text/javascript" charset="utf-8"></script>
		<script type="text/javascript" charset="utf-8">
			$(function(){
				var elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));
				elems.forEach(function(html) {
					var switchery = new Switchery(html);
				});

				$('.js-switch').each(function(){
					
					if ( $(this).prop('checked') === false )
					{
						$( this ).parents('td').find('.row-subscription').show();
						$( this ).parents('td').find('.row-perpetual').hide();
					}
					else
					{
						$( this ).parents('td').find('.row-subscription').hide();
						$( this ).parents('td').find('.row-perpetual').show();
					}
				});

				$('.js-switch').change(function(){

					if ( $(this).prop('checked') === false )
					{
						$( this ).parents('td').find('.row-subscription').show();
						$( this ).parents('td').find('.row-perpetual').hide();
					}
					else
					{
						$( this ).parents('td').find('.row-subscription').hide();
						$( this ).parents('td').find('.row-perpetual').show();
					}
				});
			});
		</script>
		<div id="global-title">
			<div class="container">
				<h1>Buy</h1>
			</div>
		</div>
		<div class="container main">
			<div class="colgroup">
				<div class="col-hd-3 col-lg-3">
					<form action="" method="get" accept-charset="utf-8">
						<h3>Product Search</h3>
						<div class="form-row sequential-writing">
							<label for="">Product Type</label>
							<select name="">
								<option value="">Any</option>
								<option value="b6e969eb-5890-48e8-bd56-dd7f3a50e330">Advanced Plug-Ins</option>
								<option value="5f56e13c-b33e-4381-92b6-f4569860fb49">Suites</option>
								<option value="c258dc8b-ec42-48f6-9a6c-b6132dcab08d">Drivers</option>
							</select>
						</div>
						<div class="form-row sequential-writing">
							<label for="">Within Suite</label>
							<select name="">
								<option value="">Any</option>
								<option value="2aaeda65-fa36-4753-9147-32cfa668a537">Allen-Bradley Suite</option>
								<option value="b83e1a35-f73d-47ab-8e5c-548517af11e9">Aromat Suite</option>
								<option value="f180209c-c191-4acd-97e1-f11072be1a9f">AutomationDirect Suite</option>
								<option value="0b2239f3-8035-4f61-8532-298093baeb61">Building Automation Suite</option>
								<option value="ebe84b7d-6304-46c4-a6b8-d74c9d442094">Contrex Suite</option>
								<option value="2648a8a5-46c2-4b44-947c-5acdb90709b0">Cutler-Hammer Suite</option>
								<option value="063b1e3e-61c1-43be-b933-7c2e57110d63">DNP3 Suite</option>
								<option value="bdf81972-ab13-4fda-b9cf-a5858a9f55b2">EFM Suite</option>
								<option value="8885937b-77d7-47bd-a4c1-3f693d00cd75">Fanuc Focas Suite</option>
								<option value="e5959f58-70bc-4e33-9017-34f8adb06814">Fisher ROC Suite</option>
								<option value="acaf8982-b9cc-448b-8b30-38cbb078b76b">GE Suite</option>
								<option value="226951ba-5661-49f0-ad0d-e82dbe78aac2">Honeywell Suite</option>
								<option value="bae572a3-d8ed-4489-bf4c-3f9e35827122">IEC 60870-5 Suite</option>
								<option value="cf6172bd-5546-43b0-a296-a6b372345ce2">IT and Infrastructure Suite</option>
								<option value="5423aeb0-2057-47c9-a028-95ef9c64462d">Manufacturing Suite</option>
								<option value="f70f6ca6-5a5e-4b7a-912e-f6216efd3b63">Mitsubishi Suite</option>
								<option value="519570f9-50b3-436f-b826-a9ca6b0dc6fd">Modbus Suite</option>
								<option value="2edea7d4-ad6b-421d-bcdc-97d395874c1f">Oil and Gas Suite</option>
								<option value="92a2cf43-20d3-4aa0-85b2-cce9773c2b09">Omron Suite</option>
								<option value="a7722591-1cdd-4f27-a931-8233fb776675">OPC Connectivity Suite</option>
								<option value="e9d9f771-1e70-4eb9-b22b-e26a14f98e18">Power Suite</option>
								<option value="9ab3a5b2-e180-4800-ba33-79b38e8d3ffb">SattBus Suite</option>
								<option value="f1a0dc77-94ed-43ce-8e4e-219977c56903">Siemens Plus Suite</option>
								<option value="443c72dd-b869-4d8e-b9fc-6775c0c88a38">Siemens Suite</option>
								<option value="bb4b57e0-9a4c-455e-b6aa-6f00f3f57927">Simatic Suite</option>
								<option value="9cfeb849-b8b5-4a24-a3b0-f75b9aabc24a">Simulation Suite</option>
								<option value="f5e5add7-00c0-4628-807b-3fb483c7ef44">SIXNET Suite</option>
								<option value="5eaf276f-f01e-4dcd-b6c1-13f232b6d19e">SNMP Suite</option>
								<option value="83144027-a4f9-4fe2-892d-1863510092ff">Thermo Westronics Suite</option>
								<option value="0f55b100-6194-4f2a-962e-b26ece56afbc">Toshiba Suite</option>
								<option value="0f26ad5b-36ba-4b72-ab44-b4ca3b420f2f">Toyopuc Suite</option>
								<option value="38d04405-82f6-4056-bb69-db7816e8ecd0">WITS Suite</option>
								<option value="777576e8-26e6-49be-9495-8055cb12d3e3">Yaskawa Suite</option>
								<option value="5fc6f7ed-3bbb-46e2-8ed0-bd92800b8767">Yokogawa Suite</option>
							</select>
						</div>
						<div class="form-row sequential-writing">
							<label for="">Protocol</label>
							<select name="">
								<option selected="selected" value="">Any</option>
								<option value="71dc729d-41d7-4745-bbd4-b9e1d8844ba3">ABB DB1</option>
								<option value="e55db6a6-d008-43a5-b335-4b5563d3715f">ABB DB2</option>
								<option value="0b3654d8-be3d-4222-a483-9c6b4cc20916">Allen-Bradley Bulletin 900-TCx</option>
								<option value="6d16d353-720b-407e-afee-c82026f449af">Allen-Bradley DF1</option>
								<option value="971dd757-a4c3-4f8d-954c-3cbdec3bbe69">Allen-Bradley Ethernet</option>
								<option value="50860d1e-15cb-4d83-ad6f-c2a773d85267">Analog Devices ASCII with Optional Checksum</option>
								<option value="10e82187-274c-404a-90da-629067abc4c9">Aromat MEWTOCOL-COM</option>
								<option value="443fdf5b-12e6-4f15-9d04-f9d919443c7b">AutomationDirect EBC</option>
								<option value="d57c966a-3286-4e1d-9de9-3c0fda81326d">AutomationDirect ECOM</option>
								<option value="c8736f94-a542-4c62-b10f-cc1cc4e62807">AutomationDirect Modbus TCP for Productivity 3000</option>
								<option value="19093f87-570a-4fbd-9312-90c0b811bc02">BACnet/IP (Annex J)</option>
								<option value="d26936da-1b1d-43fc-9ea6-935156fbb101">Beckhoff ADS API</option>
								<option value="5f2935b2-0cb5-4062-9e40-b6c6d7a4324b">Bristol Standard Asynchronous Protocol (BSAP) over IP</option>
								<option value="60276474-9e4c-4fb8-850e-46fac3b86125">BUSWARE Modbus Ethernet</option>
								<option value="fab20bb8-f902-40d1-915e-84ad121df6fa">CODESYS V2.3 Ethernet over ARTI</option>
								<option value="c1b82e3f-b042-4658-9d85-19b415de8fe0">Computer Link</option>
								<option value="393a74f6-1768-4a3d-a28c-73569f005f38">CONT over Ethernet</option>
								<option value="1865ff47-b06e-41ff-8f40-a9c3a770227c">Cutler-Hammer ELC Modbus </option>
								<option value="c5dc1160-ef10-4d08-bfb6-4acf89b98621">Cutler-Hammer Hex Mode Protocol</option>
								<option value="8afc51b5-7d54-40b5-b75b-135bab5d344f">Cutler-Hammer Modbus ASCII</option>
								<option value="82d67b53-8d7a-4b80-aff9-a308b01666cc">CX-Series Serial Communications Binary Data-Link Protocol</option>
								<option value="3483f4ed-bb45-4872-8003-be822f5e0b6f">DeviceNet</option>
								<option value="60089b83-7807-4bef-8c49-d887d2b6fb21">DF1 Full Duplex</option>
								<option value="5a25aba9-80c0-4052-a046-f7893d41c543">DF1 Half-Duplex Master</option>
								<option value="2954fad0-6454-47c0-8bc8-1585feab30f8">DF1 Radio Modem</option>
								<option value="8e94ff65-5d5b-4ba1-936f-3cc902438bcb">DH485 / DH+ (Data Highway and Data Highway Plus)</option>
								<option value="7adac352-2109-4ad9-a52e-d44946d298fd">DNP 3 (Distributed Network Protocol)</option>
								<option value="46903fc6-56c3-4bfe-99da-76a5af294a78">Dynamic Data Exchange (DDE)</option>
								<option value="77e700b1-128f-456b-9ec5-0d9d7f3f720d">Enron Modbus</option>
								<option value="119c73ee-1050-4258-ab75-a5e0d64ac5ed">Ethernet Global Data (EGD)</option>
								<option value="e21d0d09-d486-4c99-994f-62f75d77b59b">EtherNet/IP</option>
								<option value="4a041979-fe84-45c4-b855-a4aead7528ec">Extended Lufkin Automation Modbus (ELAM)</option>
								<option value="363204e0-26bf-4309-9e36-f0a6349eff8c">FOCAS Ethernet</option>
								<option value="8ce6edb4-6664-4ca2-8ac6-043fd263291d">FOCAS HSSB (High Speed Serial Bus)</option>
								<option value="4eef60da-cd2e-42c8-9321-ff8bb8eec91f">Ford Ethernet Protocol (FEP)</option>
								<option value="de6ae078-cd9e-44fb-8969-7081709c1252">Fuji Computer Link</option>
								<option value="3a013716-3a88-49c3-8cfd-093ab05852e1">GE CCM</option>
								<option value="87202641-ad6d-4ecd-9efc-401a5be9de99">GE SNPX</option>
								<option value="481710f6-1650-4e39-9503-24749ead6ed3">Honeywell HC900 Modbus</option>
								<option value="ae9da3fd-3863-4b00-881d-82c5755bbd0b">Honeywell UDC Modbus</option>
								<option value="208bb7df-c2e4-49a6-99a3-e94dc353125a">Honeywell UDC Modbus Ethernet</option>
								<option value="3e393518-86af-4a7e-ae79-cda1d57d2af8">Idec ASCII Protocol</option>
								<option value="eeb7e401-7be4-4beb-90fc-ce7f09570e4d">IEC 60870-5-101 (Serial)</option>
								<option value="b63bec6f-6436-4c32-8199-dedd2a1a60da">IEC 60870-5-104 (Ethernet)</option>
								<option value="ac9f9f42-2604-481c-b50a-63bb913c084b">IEC 61850 MMS</option>
								<option value="084a159d-b37f-4114-8760-05d551985d7d">Internet Control Message Protocol (ICMP)</option>
								<option value="c98eb7dd-3120-4dfe-bc4c-39c4caf218c8">IOtech PointScan Modbus</option>
								<option value="c702e17e-bbd2-4560-b098-73e99a211047">ISOLYNX (Serial and Ethernet)</option>
								<option value="d6012cc6-1e6c-43b1-81ea-39eed8fd8e59">Koyo DirectNet Hex Mode Protocol</option>
								<option value="13194a08-49d3-4890-884c-1421395336ef">Koyo K Sequence</option>
								<option value="05a194c4-2893-4745-b878-ca89edad7ec9">Krauss Maffei MC4 Ethernet</option>
								<option value="85428565-9ce3-4f88-92f0-f03a7ac9a4e9">MELSEC</option>
								<option value="f5aca4d3-a37f-444f-8bcd-658fdc569b4a">Memobus Ethernet</option>
								<option value="0c3910ad-63a7-4f68-bf96-4324615c7b78">Memobus Plus</option>
								<option value="1489313b-4fa1-4de3-80b9-fbf98af97dee">Memobus Serial</option>
								<option value="340dd270-8809-40d0-b340-e517537099ac">Mettler Toledo SICS Continuous Output Mode</option>
								<option value="deb3b4a1-97c1-4172-94af-7643df1fc6b3">Micro-DCI DataLink</option>
								<option value="e8cb33fb-7e72-4f2e-852d-885393577bd0">Microsoft Performance Data Helper API</option>
								<option value="8e80ef79-53e3-46da-83a5-5858d384d9db">Mitsubishi Format 1</option>
								<option value="dcba1051-c63a-4833-bd2f-414253915a06">Mitsubishi FX Direct Serial</option>
								<option value="1e55f0bd-03c3-4196-94ec-f3acb967efb2">MMIO Ethernet</option>
								<option value="6561e63c-8c36-4cd4-8b87-c9a02ee9dd8d">Modbus ASCII </option>
								<option value="0d576cd7-7432-4dc2-978d-f5a61fa45c8d">Modbus Ethernet</option>
								<option value="e523c944-7cc8-4176-9630-fc84cdbdc5b1">Modbus Plus</option>
								<option value="24809a75-2691-433f-bba4-a577b3ca62a8">Modbus RTU Protocol</option>
								<option value="d965c11c-702b-4663-9d36-2e947a0af454">MQTT Client</option>
								<option value="986b3057-55cf-4b5c-a406-e5d37374615d">M-Series Data-Link Protocol(4-byte/8-byte)</option>
								<option value="9b58d3c4-43e0-4d56-840e-ee4c50dc9eb4">MTConnect Standard</option>
								<option value="95f40c79-671d-4dc4-a7c6-96bf886c6c3d">Multi Point Interface (MPI) S7-300/400 Communications Protocol</option>
								<option value="4d375258-42e3-46df-a880-39dd297ff0a7">Non-Intelligent Terminal Protocol (NITP)</option>
								<option value="7ed4b5e0-ee63-4e5d-a432-56730d444a70">Non-Vital Custom Modbus TCP/IP Protocol</option>
								<option value="d180af1a-aad2-476b-b233-a4b3a953abd3">ODBC API</option>
								<option value="8772a65b-3140-4402-b001-2be5610507f4">Omni Modbus</option>
								<option value="7e26faec-730f-4812-8815-d13ec9151ae2">Omron FINS over Ethernet</option>
								<option value="d33ef03e-96b4-4fcc-807a-190a6139e1c9">Omron FINS over Serial</option>
								<option value="e4d658fa-31f2-43b2-af52-9eb9ea418fa1">Omron Host Link</option>
								<option value="0a7e4096-35b1-45dc-aede-3b16e8e1c3e2">Omron Toolbus</option>
								<option value="e2aacfeb-21aa-4e81-bfea-a8e3b9559269">OPC Alarms and Events (AE)</option>
								<option value="5c54f3f2-217a-4f05-bde6-c6cfcb49107a">OPC Data Access (DA)</option>
								<option value="9c4d2288-b04b-4e4c-836f-6bb34d31db70">OPC Historical Data Access (HDA)</option>
								<option value="07e8740e-73a1-420f-857c-7c654be47926">OPC Unified Architecture (UA)</option>
								<option value="252e63ad-d4d2-49fe-a136-30cb0f28918b">OPC XML-DA</option>
								<option value="3f21393c-7198-4ae5-b3ed-7233d44261a5">OptiLogic</option>
								<option value="0fd4808b-137d-4e58-90ae-20a64d6aa9f7">Oracle MES/MOC API</option>
								<option value="86517494-25b8-4aff-9934-899a9815e9a6">Partlow ASCII</option>
								<option value="3598fcf8-515a-42fb-bf89-35bc2b3a5b78">PCLink</option>
								<option value="be249369-bb73-46bd-92e1-6f0da530383a">Philips Programmable Controller Communication Protocol (PPCCOM)</option>
								<option value="5b57c13f-0807-428a-9633-f310348fe919">Point-to-Point (PPI) S7-200 Communications Protocol</option>
								<option value="96723810-dc17-4adb-a11a-317752ac11ac">Point-to-Point Modem (PPM) S7-200 Communications Protocol</option>
								<option value="7314cd52-5ec1-4bd1-98aa-b5f9fd8831c9">Profibus DP</option>
								<option value="2c604837-cbf1-47d9-83a2-8f518eb66b5f">RESTful Web Services Client</option>
								<option value="e1272316-d2c3-4258-b055-9ba507197145">RESTful Web Services Server</option>
								<option value="ef48df69-7d22-4375-8df9-254d544c43da">ROC</option>
								<option value="99350ac1-452b-4c32-aca8-84b67c953700">ROC Plus</option>
								<option value="03512660-a547-456b-bc27-0620b7a5cce8">Rockwell Automation Fragmentation Protocol (CIP over DF1)</option>
								<option value="192cb7ba-2846-42ee-8c81-93733baa9e9c">SattBus</option>
								<option value="22f9510c-5d81-4d5d-a5f4-e46629f3bb4b">SattBus Ethernet</option>
								<option value="deca0e0d-7f3b-436a-9671-7e33b0cce244">Scanivalve Ethernet</option>
								<option value="eabdf78a-4766-484c-8912-9567c6afdef6">Siemens Industrial Ethernet</option>
								<option value="f67292be-f041-4a7c-be23-ce0b9c241d49">Siemens S5 3964(R)</option>
								<option value="0c98fd22-b9a2-4b96-b58a-6b6638d99232">Siemens S5 AS511 Current Loop</option>
								<option value="e9eb899e-a572-4cad-9116-4b0eea9982db">SIMATIC CAMP / CAMP Packed Task Code</option>
								<option value="09007439-6018-4ea1-aaee-f06429ffcd64">SIXNET EtherTRAK Modbus</option>
								<option value="2b559daf-1599-4df0-8e17-e15641e30986">SIXNET UDR</option>
								<option value="29bfd41d-b87f-42a8-9c32-474bd2fc7c26">SNMP</option>
								<option value="3b361094-91fb-4757-ac95-916940f1b82d">Splunk API</option>
								<option value="6fdd504e-e3e6-42cd-8532-0083d8d0d819">Super SEL and X-Sel Controllers: Serial Communication Protocols</option>
								<option value="8b17d5e8-439b-40d9-b23c-2cc4dc62e5b2">SY/MAX Point-to-Point Communications Protocol</option>
								<option value="29810259-8351-4375-84d2-638a6bbd61f9">Sysway</option>
								<option value="d4d5c487-f250-4ed5-9bea-08641c5bdada">Thermo Westronics Modbus</option>
								<option value="d2b500cb-3d93-4373-8f6f-d23859c9f863">ThingWorx® AlwaysOn™</option>
								<option value="6778869f-0dc7-43b7-89a3-de05219bd273">Torque Tool Open Ethernet</option>
								<option value="921aaac7-4a04-41e6-8336-1c42953ab034">Toshiba ASCII Computer Link Protocol</option>
								<option value="e2d64998-acff-4f47-af13-67dd9cffdae9">Toshiba ASCII Ethernet</option>
								<option value="52f29f1d-2eae-4aae-8615-013cdff1feb4">Toyopuc PC3/PC2 Ethernet Computer Link Protocol</option>
								<option value="8a78d9eb-7e2d-40d7-a301-8d64a4305bff">Transparent Byte Protocol (TB)</option>
								<option value="16db2ab8-3267-4934-b666-97ec6bc7cf46">Triconex System Access Application (TSAA)</option>
								<option value="555f313a-c3a0-4b4d-8870-acb31e850e7a">Uni-Telway</option>
								<option value="7d82b469-2a5d-4f53-84d0-0370aaa2561c">WAGO Modbus Ethernet</option>
								<option value="dcc89f73-6b58-471c-8a57-a4fee7a4bcc5">Weatherford 8500 Protocol</option>
								<option value="36e045c2-bff7-4536-a403-799a8684471f">WITS Level 0 Active (solicited)</option>
								<option value="22cdf293-fc4b-4f10-8ac4-3adb64e13772">WITS Level 0 Passive (unsolicited)</option>
								<option value="bab1af08-e3c4-4e86-86e3-a77c46ee5c53">Yaskawa MP Modbus Ethernet</option>
								<option value="0d4ef727-6ad9-4f12-94d1-4f2d0245ba49">Yokogawa Controller ASCII</option>
								<option value="36709029-6d67-4a59-9626-3a8ac285e6c1">Yokogawa Data Acquisition Protocols (CX, DX, DXP, MW, MP, HR, Darwin)</option>
								<option value="54b36ebf-a478-40d1-9760-d0c82d308424">YS100 command-response message format</option>
							</select>
						</div>
						<div class="form-row sequential-writing">
							<label for="">Product Name</label>
							<input type="text" name="">
						</div>
						<div class="sequential-writing ta-r">
							<button type="submit">Search</button>
						</div>
					</form>
				</div>
				<div class="col-hd-9 col-lg-9">
					<div id="product-buy">
						<div class="colgroup col-middle">
							<div class="col-hd-6 col-lg-6">
								<div class="filtered">
									<h6>FILTERED BY:</h6>
									<a href="" title="">Drivers</a>
									<a href="" title="">Lorem</a>
									<a href="" title="">İpsum</a>
								</div>
							</div>
							<div class="col-hd-6 col-lg-6">
								<div class="filtered-results">137 RESULTS (PAGE 1 / 4)</div>
							</div>
						</div>
						<table>
							<thead>
								<tr>
									<th width="215">PRODUCT</th>
									<th>DETAILS</th>
									<th width="275" class="ta-r">PRICING</th>
								</tr>
							</thead>
							<tbody>
								<?php for ($i=0; $i < 4; $i++) { ?>
								<tr>
									<td>
										<a href="" title="" class="product-name">ABB Totalflow</a>
									</td>
									<td>
										<p class="product-explanation">The ABB Totalflow driver for KEPServerEX connects to ABB Totalflow devices that support the native Totalflow serial protocol. The Totalflow protocol is typically used in upstream Oil & Gas for process control and hydrocarbon...</p>
										<a href="" title="" class="product-more">(Learn More)</a>
									</td>
									<td class="ta-r">
										<div class="row-subscription">
											<p class="product-explanation">Subscription</p>
											<span class="product-price"><sup>$</sup>1230.00/yr.</span>
										</div>
										<div class="row-perpetual">
											<p class="product-explanation">Perpetual</p>
											<span class="product-price"><sup>$</sup>3690.00</span>
										</div>
										<div class="checkbox">
											<span>Subscription</span>
											<input type="checkbox" name="" value="" class="js-switch">
											<span>Perpetual</span>
										</div>
										<a href="" title="" class="button add">Add To Cart</a>
										<a href="" title="" class="button more">Learn More</a>
									</td>
								</tr>
								<?php } ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
		<?php require_once('include/footer.php'); ?>
	</body>
</html>