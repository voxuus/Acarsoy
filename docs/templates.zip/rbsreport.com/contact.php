<!DOCTYPE html>
<html lang="en" dir="ltr">
	<head>
		<?php require_once('include/head.php'); ?>
	</head>
	<body>
		<?php require_once('include/header.php'); ?>
		<div id="global-title">
			<div class="container">
				<h1>Contact</h1>
			</div>
		</div>
		<div class="container main">
			<div class="colgroup">
				<div class="col-hd-6 col-lg-6 col-sm-8 col-xs-12">
					<div class="normal-text">
						<h3>Türkiye</h3>
						<p>Poligon Cad. Buyaka İş Kuleleri - Kule 3 Giriş Kat Fatih Sultan Mehmet Mah. 34771 Ümraniye/İstanbul</p>
						<p>
							Email: <a href="mailto:sales@rbsreport.com" title="">sales@rbsreport.com</a>
							<br>
							Skype: <a href="" title="">RBSReport</a>
						</p>
						<h6>For Your Order</h6>
						<p>
							Email: <a href="mailto:order@rbsreport.com" title="">order@rbsreport.com</a>
							<br>
							Phone: <a href="tel:15127824592" title="">+1 (512) 782-4592</a>
						</p>
					</div>
				</div>
				<div class="col-hd-6 col-lg-6 col-sm-8 col-xs-12">
					<div class="normal-text">
						<h3>Londra</h3>
						<p>Poligon Cad. Buyaka İş Kuleleri - Kule 3 Giriş Kat Fatih Sultan Mehmet Mah. 34771 Ümraniye/İstanbul</p>
						<p>
							Email: <a href="mailto:sales@rbsreport.com" title="">sales@rbsreport.com</a>
							<br>
							Skype: <a href="" title="">RBSReport</a>
						</p>
						<h6>For Your Order</h6>
						<p>
							Email: <a href="mailto:order@rbsreport.com" title="">order@rbsreport.com</a>
							<br>
							Phone: <a href="tel:15127824592" title="">+1 (512) 782-4592</a>
						</p>
					</div>
				</div>
			</div>
			<div class="distributors">
				<ul>
					<?php for ($a=0; $a < 4; $a++) { ?>
					<li>
						<a href="" title="">Asia Pacific and Oceania</a>
						<div class="colgroup content">
							<?php for ($i=0; $i < 2; $i++) { ?>
							<div class="col-hd-6 col-lg-6 col-xs-12">
								<section>
									<div class="colgroup">
										<div class="col-hd-6 col-lg-5 col-pv-12">
											<img src="https://robosoft.com.tr/upload/images/default/15727ddaa6c151a.jpg" alt="" class="center">
											<hr class="hd-none lg-none pv-block">
										</div>
										<div class="col-hd-6 col-lg-7 col-pv-12">
											<h5>Allied Solutions Pte Ltd.</h5>
											<p>Indonesia, Malaysia, Singapore, and Vietnam</p>
											<p>+65-64844050</p>
											<a href="" title="">www.alliedsolutions.com.sg</a>
										</div>
									</div>
								</section>
							</div>
							<?php } ?>
						</div>
					</li>
					<?php } ?>
				</ul>
			</div>
			<form action="" method="get" accept-charset="utf-8">
				<h3>Bize ulaşın!</h3>
				<div class="form-row">
					<div class="colgroup col-hd-6 col-lg-6 col-xs-12">
						<div>
							<input type="" name="" placeholder="First name">
						</div>
						<div>
							<input type="" name="" placeholder="Last name">
						</div>
					</div>
				</div>
				<div class="form-row">
					<div class="colgroup col-hd-6 col-lg-6 col-xs-12">
						<div>
							<input type="" name="" placeholder="E-mail">
						</div>
						<div>
							<input type="" name="" placeholder="Phone">
						</div>
					</div>
				</div>
				<div class="form-row">
					<textarea type="" name="" placeholder="Message"></textarea>
				</div>
				<div class="form-row">
					<button type="submit">SEND MESSAGE</button>
				</div>
			</form>
		</div>
		<?php require_once('include/footer.php'); ?>
	</body>
</html>