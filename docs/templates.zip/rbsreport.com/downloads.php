<!DOCTYPE html>
<html lang="en" dir="ltr">
	<head>
		<?php require_once('include/head.php'); ?>
	</head>
	<body>
		<?php require_once('include/header.php'); ?>
		<div id="global-title">
			<div class="container">
				<h1>Support</h1>
			</div>
		</div>
		<div class="container main">
			<div id="support-tabs">
				<ul>
					<li><a href="support-form" title="">Support Form</a></li>
					<li><a href="faq" title="">FAQ</a></li>
					<li><a href="downloads" title="" class="active">Downloads</a></li>
				</ul>
			</div>
			<h2 id="support-title">DOWNLOADS</h2>
			<div id="downloads">
				<ul>
					<?php for ($i=0; $i < 8; $i++) { ?>
					<li><a href="" title="">RBSReport V2.0 32 Bit</a></li>
					<?php } ?>
				</ul>
			</div>
		</div>
		<?php require_once('include/footer.php'); ?>
	</body>
</html>