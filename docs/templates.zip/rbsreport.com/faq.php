<!DOCTYPE html>
<html lang="en" dir="ltr">
	<head>
		<?php require_once('include/head.php'); ?>
	</head>
	<body>
		<?php require_once('include/header.php'); ?>
		<div id="global-title">
			<div class="container">
				<h1>Support</h1>
			</div>
		</div>
		<div class="container main">
			<div id="support-tabs">
				<ul>
					<li><a href="support-form" title="">Support Form</a></li>
					<li><a href="faq" title="" class="active">FAQ</a></li>
					<li><a href="downloads" title="">Downloads</a></li>
				</ul>
			</div>
			<h2 id="support-title">FAQS</h2>
			<div id="faq">
				<ul>
					<?php for ($i=0; $i < 7; $i++) { ?>
					<li>
						<h6>What is RBS Report?</h6>
						<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English.</p>
					</li>
					<?php } ?>
				</ul>
			</div>
			<div class="pagination">
				<a href="" title="">1</a>
				<a href="" title="">2</a>
				<a href="" title="" class="active">3</a>
				<a href="" title="">4</a>
				<a href="" title="">5</a>
			</div>
		</div>
		<?php require_once('include/footer.php'); ?>
	</body>
</html>