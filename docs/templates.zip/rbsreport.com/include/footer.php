<footer id="global-footer">
    <div id="infobar">
        <div class="container">
            <div class="colgroup col-middle">
                <div class="col-hd-8 col-lg-8 col-sm-12">
                    <div id="subscribe">
                        <div class="d-t">
                            <div class="d-tc va-m nowrap">
                                <h6>NEWSLETTER</h6>
                            </div>
                            <div class="d-tc va-m">
                                <div class="input-group">
                                    <input type="text" name="" placeholder="E-mail Address">
                                    <button type="submit">Submit</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-hd-4 col-lg-4 sm-none-i">
                    <div id="socials">
                        <a href="" title=""><img src="assets/images/icon/stwitter.png" alt=""></a>
                        <a href="" title=""><img src="assets/images/icon/sgoogle-plus.png" alt=""></a>
                        <a href="" title=""><img src="assets/images/icon/slinkedin.png" alt=""></a>
                        <h6>SOCIAL!</h6>
                    </div>
                </div>
            </div>
        </div>
        <hr>
        <nav class="nav-1">
            <ul>
                <li><a href="" title="">Home</a></li>
                <li><a href="" title="">About</a></li>
                <li><a href="" title="">Support</a></li>
                <li><a href="" title="">References</a></li>
                <li><a href="" title="">Contact</a></li>
            </ul>
        </nav>
        <nav class="nav-2">
            <ul>
                <li><a href="" title="">DataLogger</a></li>
                <li><a href="" title="">ExcelTrend</a></li>
                <li><a href="" title="">Mail</a></li>
                <li><a href="" title="">.Net Control</a></li>
            </ul>
        </nav>
    </div>
    <div id="copyright">
        <div class="container">
            <div class="colgroup col-middle">
                <div class="col-hd-6 col-lg-6 col-xs-12">
                    <p id="copyright-text">© Copyright 2017. RBS Report.</p>
                </div>
                <div class="col-hd-6 col-lg-6 xs-none-i">
                    <div class="ta-r">
                        <a href="" title=""><img src="assets/images/main/robosoft.png" alt=""></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>