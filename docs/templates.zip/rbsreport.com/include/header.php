<header id="global-header">
    <div class="container">
        <div class="colgroup col-middle">
            <div class="col-hd-3 col-lg-3 col-md-4 col-sm-7">
                <a href="home" id="app"><img src="assets/images/main/app.png" width="257" height="45" alt=""></a>
            </div>
            <div class="col-hd-9 col-lg-9 col-md-8 col-sm-5">
                <ul id="languages">
                    <li><a href="#" title="Türkçe">TR</a></li>
                    <li class="active"><a href="#" title="English">EN</a></li>
                    <div id="mobile-nav-open">
                        <span><img src="assets/images/icon/menu-bar.png" width="26" height="17" alt=""></span>
                    </div>
                </ul>
                <nav id="globalnav">
                    <ul>
                        <li class="active"><a href="home" title="">Home</a></li>
                        <li><a href="about" title="">About</a></li>
                        <li class="dropdown" id="product-nav-open"><a href="" title="">Products</a></li>
                        <li><a href="support-form" title="">Support</a></li>
                        <li><a href="contact" title="contact">Contact</a></li>
                        <li class="login"><a href="login" title="">Login</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</header>
<div id="md-mobilemenu">
    <header id="md-mobilemenu-header" class="clearfix">
        <a href="" title="Menüyü Kapat" id="md-mobilemenu-close"><svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 64 64" xml:space="preserve" width="15px" height="15px"><path d="M28.941,31.786L0.613,60.114c-0.787,0.787-0.787,2.062,0,2.849c0.393,0.394,0.909,0.59,1.424,0.59   c0.516,0,1.031-0.196,1.424-0.59l28.541-28.541l28.541,28.541c0.394,0.394,0.909,0.59,1.424,0.59c0.515,0,1.031-0.196,1.424-0.59 c0.787-0.787,0.787-2.062,0-2.849L35.064,31.786L63.41,3.438c0.787-0.787,0.787-2.062,0-2.849c-0.787-0.786-2.062-0.786-2.848,0 L32.003,29.15L3.441,0.59c-0.787-0.786-2.061-0.786-2.848,0c-0.787,0.787-0.787,2.062,0,2.849L28.941,31.786z"></path></svg></a>
    </header>
    <ul id="md-mobilemenu-list">
        <li class="md-mobilmenu-item"><a href="home" title="">Home</a></li>
        <li class="md-mobilmenu-item"><a href="about" title="">About</a></li>
        <li class="md-mobilmenu-item">
            <a href="" title="">Products</a>
            <ul>
                <li><a href="" title="">Product 1</a></li>
                <li><a href="" title="">Product 2</a></li>
                <li><a href="" title="">Product 3</a></li>
                <li><a href="" title="">Product 4</a></li>
            </ul>
        </li>
        <li class="md-mobilmenu-item"><a href="support-form" title="">Support</a></li>
        <li class="md-mobilmenu-item"><a href="contact" title="contact">Contact</a></li>
        <li class="md-mobilmenu-item"><a href="" title="">Login</a></li>
    </ul>
</div>
<div id="product-nav">
    <div class="container d-t">
        <div class="d-tc va-m">
            <div class="colgroup col-middle">
                <div class="col-hd-5 col-lg-5">
                    <ul>
                        <li><a href="" title="">DataLogger</a></li>
                        <li><a href="" title="">ExcelTrend</a></li>
                        <li><a href="" title="">Mail</a></li>
                        <li><a href="" title="">.Net Control</a></li>
                    </ul>
                </div>
                <div class="col-hd-7 col-lg-7">
                    <div class="li-item" style="display: block;">
                        <h3>DataLogger</h3>
                        <img src="media/product-2.png" alt="" class="max-true">
                        <a href="product" title="">VIEW APP</a>
                    </div>
                    <div class="li-item">
                        <h3>ExcelTrend</h3>
                        <img src="media/product-2.png" alt="" class="max-true">
                        <a href="product" title="">VIEW APP</a>
                    </div>
                    <div class="li-item">
                        <h3>Mail</h3>
                        <img src="media/product-2.png" alt="" class="max-true">
                        <a href="product" title="">VIEW APP</a>
                    </div>
                    <div class="li-item">
                        <h3>.Net Control</h3>
                        <img src="media/product-2.png" alt="" class="max-true">
                        <a href="product" title="">VIEW APP</a>
                    </div>
                </div>
            </div>
        </div>
        <div id="product-nav-close"></div>
    </div>
</div>