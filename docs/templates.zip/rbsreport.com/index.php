<!DOCTYPE html>
<html lang="en" dir="ltr">
	<head>
		<?php require_once('include/head.php'); ?>
	</head>
	<body>
		<?php require_once('include/header.php'); ?>
		<script type="text/javascript">
			$(function(){

				$("#slideshow ul").bxSlider({
					mode: 'fade',
					auto: false,
					pause: 7000,
					controls: false,
					pagerCustom: $("#slideshow-pag")
				});

				$("#product-gallery ul").bxSlider({
					mode: 'horizontal',
					auto: false,
					pause: 7000,
					nextSelector: $('#product-gallery-con .container'),
					prevSelector: $('#product-gallery-con .container'),
					nextText: '<img src="assets/images/icon/product-gallery-next.png" alt="">',
					prevText: '<img src="assets/images/icon/product-gallery-prev.png" alt="">',
					pagerCustom: $("#product-gallery-pag")
				});

			});
		</script>
		<div id="slideshow">
			<ul>
				<?php for ($i=0; $i < 6; $i++) { ?>
				<li style="background-image: url('media/slideshow.png')">
					<div class="container">
						<div class="d-t width">
							<div class="d-tc va-m ta-r">
								<h2>Easily query your systems efficiency!</h2>
							</div>
						</div>
					</div>
				</li>
				<?php } ?>
			</ul>
			<div id="slideshow-pag">
				<div class="container">
					<?php for ($i=0; $i < 6; $i++) { ?>
					<a href="" data-slide-index="<?php echo $i; ?>"></a>
					<?php } ?>
				</div>
			</div>
		</div>
		<div id="company-future">
			<div class="container">
				<hgroup>
					<h3>RBS Report</h3>
					<h6>With RBSReport, reporting is ever so easy</h6>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.</p>
				</hgroup>
			</div>
		</div>
		<div id="product-gallery">
			<div class="container">
				<ul>
					<?php for ($i=0; $i < 4; $i++) { ?>
					<li>
						<div class="d-t">
							<div class="d-tc va-m">
								<div class="colgroup col-middle col-hd-6 col-lg-6 col-xs-12">
									<div>
										<hgroup>
											<h1>Data Logger</h1>
											<h4>Easily collect data with a system that can connect to any standard OPC server and log the collected data into an MS SQL Server® database.</h4>
											<a href="" title="">LEARN MORE</a>
										</hgroup>
									</div>
									<div class="xs-none-i">
										<img src="media/product.png" alt="" class="center">
									</div>
								</div>
							</div>
						</div>
					</li>
					<?php } ?>
				</ul>
			</div>
			<div id="product-gallery-con"><div class="container"></div></div>
			<div id="product-gallery-pag">
				<div class="container">
					<?php for ($i=0; $i < 4; $i++) { ?>
					<a href="" title="" data-slide-index="<?php echo $i; ?>"><?php echo $i + 1; ?></a>
					<?php } ?>
				</div>
			</div>
		</div>
		<?php require_once('include/footer.php'); ?>
	</body>
</html>