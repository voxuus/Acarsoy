<!DOCTYPE html>
<html lang="en" dir="ltr">
	<head>
		<?php require_once('include/head.php'); ?>
	</head>
	<body>
		<?php require_once('include/header.php'); ?>
		<div id="global-title">
			<div class="container">
				<h1>Lisans Bilgileri</h1>
			</div>
		</div>
		<div class="container main">
			<div class="colgroup">
				<div class="col-hd-3 col-lg-3 col-xs-12">
					<aside class="sidebar">
						<ul>
							<li><a href="account" title="">Bilgi güncelleme</a></li>
							<li><a href="transfer-notice-form" title="">Havale Bildirim Formu</a></li>
							<li><a href="my-purchases" title="" class="active">Satın Aldıklarım</a></li>
						</ul>
					</aside>
				</div>
				<div class="col-hd-9 col-lg-9 col-xs-12">
					<div class="normal-text">
						<h2>DataLogger</h2>
						<h5>Makine Kodu</h5>
						<form action="" method="get" accept-charset="utf-8">
							<div class="colgroup form-row">
								<div class="col-hd-5 col-lg-5">
									<input type="text" name="" placeholder="CiNTEyeTXBoSQn2KLm1rShoZVLw47t43mDJbCzOR" maxlength="40">
								</div>
								<div class="col-hd-5 col-lg-5">
									<button type="submit" style="margin-top: 0">Lisan Kodunu Değiştir</button>
								</div>
							</div>
						</form>
						<br><br>
						<dl>
							<dt><h5>Lisans Kodu</h5></dt>
							<dd>a4nhkGrQA_'_q7qPCdQHhsP\UPES:5eVe@%/XsBBbDP!O4%@i3eDkks@19V=24M1h=!X!GjvLgkQVQAaxO1K748kAFDjRDyw47tmDJbCzORmFKRFypW5AZpVn3yfYYBsMm0q9ONzzds1B15s09ooMh5B5pOW61TQFBqD8ee9KO2Zm6STPYt</dd>
						</dl>
					</div>
				</div>
			</div>
		</div>
		<?php require_once('include/footer.php'); ?>
	</body>
</html>