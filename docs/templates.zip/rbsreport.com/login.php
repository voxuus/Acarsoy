<!DOCTYPE html>
<html lang="en" dir="ltr">
	<head>
		<?php require_once('include/head.php'); ?>
	</head>
	<body>
		<?php require_once('include/header.php'); ?>
		<div id="global-title">
			<div class="container">
				<h1>Login</h1>
			</div>
		</div>
		<div class="container main">
			<div class="colgroup">
				<div class="col-hd-4 col-lg-4 col-xs-12"></div>
				<div class="col-hd-4 col-lg-4 col-xs-12">
					<form action="" method="get" accept-charset="utf-8">
						<div class="form-row">
							<input type="text" name="" placeholder="E-MAIL">
						</div>
						<div class="form-row">
							<input type="password" name="" placeholder="PASSWORD">
						</div>
						<div class="form-row">
							<button type="submit" class="width ta-c">SIGN IN</button>
							<div class="normal-text">
								<ul>
									<li><a href="reset-password" title="">Did you forget your password ?</a></li>
									<li><a href="register" title="">Register</a></li>
								</ul>
							</div>
						</div>
					</form>
				</div>
				<div class="col-hd-4 col-lg-4 col-xs-12"></div>
			</div>
		</div>
		<?php require_once('include/footer.php'); ?>
	</body>
</html>