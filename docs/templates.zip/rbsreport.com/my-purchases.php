<!DOCTYPE html>
<html lang="en" dir="ltr">
	<head>
		<?php require_once('include/head.php'); ?>
	</head>
	<body>
		<?php require_once('include/header.php'); ?>
		<div id="global-title">
			<div class="container">
				<h1>Account</h1>
			</div>
		</div>
		<div class="container main">
			<div class="colgroup">
				<div class="col-hd-3 col-lg-3 col-xs-12">
					<aside class="sidebar">
						<ul>
							<li><a href="account" title="">Bilgi güncelleme</a></li>
							<li><a href="transfer-notice-form" title="">Havale Bildirim Formu</a></li>
							<li><a href="my-purchases" title="" class="active">Satın Aldıklarım</a></li>
						</ul>
					</aside>
				</div>
				<div class="col-hd-9 col-lg-9 col-xs-12">
					<div class="normal-text">
						<h2>Satın Aldıklarım</h2>
						<form action="" method="get" accept-charset="utf-8">
							<div class="form-row">
								<div class="colgroup">
									<div class="col-hd-5 col-lg-5 col-xs-12">
										<input type="" name="" placeholder="Ürün Adı">
									</div>
									<div class="col-hd-5 col-lg-5 col-xs-12">
										<input type="" name="" placeholder="Proje Adı">
									</div>
									<div class="col-hd-2 col-lg-2 col-xs-12">
										<button type="submit" style="margin-top: 0; text-align: center; width: 100%;">SEARCH</button>
									</div>
								</div>
							</div>
						</form>
						<table>
							<thead>
								<tr>
									<th width="30"></th>
									<th nowrap></th>
									<th width="90">Ürün Adı</th>
									<th>Proje Adı</th>
									<th width="90">Alım Tarihi</th>
									<th width="75">Lisans</th>
									<th width="75">Fiyatı</th>
									<th width="75">Toplam</th>
									<th width="100">Kodlar</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td>1</td>
									<td><img src="media/product-3.jpg" width="50" height="50" alt="" class="not-max-width"></td>
									<td class="ta-l"><a href="" title="">DataLogger</a></td>
									<td>
										<form action="" method="get" accept-charset="utf-8" class="different">
											<input type="text" name="" value="Lorem ipsum dolor sit">
											<button type="submit">
												<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="15px" height="15px" viewBox="0 0 344.37 344.37" xml:space="preserve">
													<path d="M334.485,37.463c-6.753-1.449-13.396,2.853-14.842,9.603l-9.084,42.391C281.637,40.117,228.551,9.155,170.368,9.155 c-89.603,0-162.5,72.896-162.5,162.5c0,6.903,5.596,12.5,12.5,12.5c6.903,0,12.5-5.597,12.5-12.5 c0-75.818,61.682-137.5,137.5-137.5c49.429,0,94.515,26.403,118.925,68.443l-41.674-8.931c-6.752-1.447-13.396,2.854-14.841,9.604 c-1.446,6.75,2.854,13.396,9.604,14.842l71.536,15.33c1.215,0.261,2.449,0.336,3.666,0.234c2.027-0.171,4.003-0.836,5.743-1.962 c2.784-1.801,4.738-4.634,5.433-7.875l15.331-71.536C345.535,45.555,341.235,38.911,334.485,37.463z"/>
													<path d="M321.907,155.271c-6.899,0.228-12.309,6.006-12.081,12.905c1.212,36.708-11.942,71.689-37.042,98.504 c-25.099,26.812-59.137,42.248-95.844,43.46c-1.53,0.05-3.052,0.075-4.576,0.075c-47.896-0.002-92.018-24.877-116.936-65.18 l43.447,11.65c6.668,1.787,13.523-2.168,15.311-8.837c1.788-6.668-2.168-13.522-8.836-15.312l-70.664-18.946 c-3.202-0.857-6.615-0.409-9.485,1.247c-2.872,1.656-4.967,4.387-5.826,7.589L0.43,293.092 c-1.788,6.668,2.168,13.522,8.836,15.311c1.085,0.291,2.173,0.431,3.245,0.431c5.518,0,10.569-3.684,12.066-9.267l10.649-39.717 c29.624,46.647,81.189,75.367,137.132,75.365c1.797,0,3.604-0.029,5.408-0.089c43.381-1.434,83.608-19.674,113.271-51.362 s45.209-73.031,43.776-116.413C334.586,160.453,328.805,155.026,321.907,155.271z"/>
												</svg>
											</button>
										</form>
									</td>
									<td>09.05.2017</td>
									<td>2 Yıl</td>
									<td>£150.00</td>
									<td>£300.00</td>
									<td>
										<a href="license-code" title="">Lisans No</a>
										<a href="license-code" title="">Makine Kodu</a>
									</td>
								</tr>
								<tr>
									<td>2</td>
									<td><img src="media/product-4.jpg" width="50" height="50" alt="" class="not-max-width"></td>
									<td class="ta-l"><a href="" title="">ExcelTrend</a></td>
									<td>
										<form action="" method="get" accept-charset="utf-8" class="different">
											<input type="text" name="" value="Lorem ipsum dolor sit">
											<button type="submit">
												<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="15px" height="15px" viewBox="0 0 344.37 344.37" xml:space="preserve">
													<path d="M334.485,37.463c-6.753-1.449-13.396,2.853-14.842,9.603l-9.084,42.391C281.637,40.117,228.551,9.155,170.368,9.155 c-89.603,0-162.5,72.896-162.5,162.5c0,6.903,5.596,12.5,12.5,12.5c6.903,0,12.5-5.597,12.5-12.5 c0-75.818,61.682-137.5,137.5-137.5c49.429,0,94.515,26.403,118.925,68.443l-41.674-8.931c-6.752-1.447-13.396,2.854-14.841,9.604 c-1.446,6.75,2.854,13.396,9.604,14.842l71.536,15.33c1.215,0.261,2.449,0.336,3.666,0.234c2.027-0.171,4.003-0.836,5.743-1.962 c2.784-1.801,4.738-4.634,5.433-7.875l15.331-71.536C345.535,45.555,341.235,38.911,334.485,37.463z"/>
													<path d="M321.907,155.271c-6.899,0.228-12.309,6.006-12.081,12.905c1.212,36.708-11.942,71.689-37.042,98.504 c-25.099,26.812-59.137,42.248-95.844,43.46c-1.53,0.05-3.052,0.075-4.576,0.075c-47.896-0.002-92.018-24.877-116.936-65.18 l43.447,11.65c6.668,1.787,13.523-2.168,15.311-8.837c1.788-6.668-2.168-13.522-8.836-15.312l-70.664-18.946 c-3.202-0.857-6.615-0.409-9.485,1.247c-2.872,1.656-4.967,4.387-5.826,7.589L0.43,293.092 c-1.788,6.668,2.168,13.522,8.836,15.311c1.085,0.291,2.173,0.431,3.245,0.431c5.518,0,10.569-3.684,12.066-9.267l10.649-39.717 c29.624,46.647,81.189,75.367,137.132,75.365c1.797,0,3.604-0.029,5.408-0.089c43.381-1.434,83.608-19.674,113.271-51.362 s45.209-73.031,43.776-116.413C334.586,160.453,328.805,155.026,321.907,155.271z"/>
												</svg>
											</button>
										</form>
									</td>
									<td>09.05.2017</td>
									<td>4 Yıl</td>
									<td>£200.00</td>
									<td>£800.00</td>
									<td>
										<a href="license-code" title="">Lisans No</a>
										<a href="license-code" title="">Makine Kodu</a>
									</td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
		<?php require_once('include/footer.php'); ?>
	</body>
</html>