<!DOCTYPE html>
<html lang="en" dir="ltr">
	<head>
		<?php require_once('include/head.php'); ?>
	</head>
	<body>
		<?php require_once('include/header.php'); ?>
		<script type="text/javascript">
			$(function(){

				var resized = function() {
					$(".screen-bg-scope, .screen").css("height", $( window ).outerHeight() );
				};

				var screenActive      = null,
					screenActiveIndex = null,
					maxScrolEffect    = null,
					oldScreenIndex    = 0;

				var scrolled = function() {
					
					var scrollTop = $( window ).scrollTop(),
						productPositionTop = $("#product-scroll").offset().top;

					maxScrolEffect = $("#product-scroll").outerHeight();
					maxScrolEffect = maxScrolEffect + productPositionTop;
					maxScrolEffect = maxScrolEffect - $( window ).outerHeight();
					maxScrolEffect = maxScrolEffect + 10;

					if ( scrollTop < maxScrolEffect )
					{
						$(".screen-next").fadeIn();
						$(".screen-next, .screen-bg-scope").css({
							position: 'fixed',
							top: 0,
							bottom: 'auto'
						});

						if ( scrollTop > productPositionTop )
						{
							screenActiveIndex = Math.floor(( scrollTop - productPositionTop ) / $( window ).outerHeight());

							if ( oldScreenIndex != screenActiveIndex )
							{
								$(".screen-bg").hide().eq( screenActiveIndex ).fadeIn(300);
							
								oldScreenIndex = screenActiveIndex;
							}
						}
						else
						{
							$(".screen-next, .screen-bg-scope").css({
								position: ''
							});
						}
					}
					else
					{
						$(".screen-bg-scope").css({
							position: 'absolute',
							top: 'auto',
							bottom: 0
						});

						$(".screen-next").fadeOut();
					}
				};

				$(".screen-bg").eq( 0 ).fadeIn(300);

				$(".screen-next").click(function(event){
					event.preventDefault();
					var go = $(".screen").eq( screenActiveIndex + 1 ).offset().top;
					$('html, body').animate({ scrollTop: go }, 1000);
				});

				resized();

				scrolled();

				$( window ).resize(function(){
					resized();
				}).scroll(function(){
					scrolled();
				});
			})
		</script>
		<div id="product">
			<div id="product-welcome" style="background-image: url('media/product-bg.jpg')">
				<div class="container">
					<h1>RBS Data Logger</h1>
					<h5>Lorem Ipsum is simply dummy text of <br>the printing and typesetting</h5>
					<div class="colgroup col-hd-4 col-lg-4 col-sm-6 xs-none-i">
						<div>
							<ul>
								<li>
									<h6>Lorem Ipsum Dolor</h6>
									<p>Lorem Ipsum is simply dummy text of the printing and typesetting </p>
								</li>
								<li>
									<h6>Lorem Ipsum Dolor</h6>
									<p>Lorem Ipsum is simply dummy text of the printing and typesetting </p>
								</li>
								<li>
									<h6>Lorem Ipsum Dolor</h6>
									<p>Lorem Ipsum is simply dummy text of the printing and typesetting </p>
								</li>
							</ul>
						</div>
						<div class="sm-none-i">
							<div class="product-image">
								<img src="media/product-2.png" alt="" class="center">
								<a href="" title="">BUY NOW</a>
							</div>
						</div>
						<div>
							<ul>
								<li>
									<h6>Lorem Ipsum Dolor</h6>
									<p>Lorem Ipsum is simply dummy text of the printing and typesetting </p>
								</li>
								<li>
									<h6>Lorem Ipsum Dolor</h6>
									<p>Lorem Ipsum is simply dummy text of the printing and typesetting </p>
								</li>
								<li>
									<h6>Lorem Ipsum Dolor</h6>
									<p>Lorem Ipsum is simply dummy text of the printing and typesetting </p>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<div id="product-scroll">
				<a href="" title="" class="screen-next"><img src="assets/images/icon/screen-next.png" alt=""></a>
				<?php for ($i=0; $i < 5; $i++) { ?>
				<div class="screen" data-background-path="media/product-screen-<?php echo $i; ?>.jpg">
					<div class="container">
						<div class="d-t">
							<div class="d-tc">
								<div class="text">
									<h6>SLOGAN IS HERE</h6>
									<h4>Lorem ipsum dolor sit consensus.</h4>
									<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
								</div>
							</div>
						</div>
					</div>
				</div>
				<?php } ?>
				<div class="screen-bg-scope">
					<?php for ($i=0; $i < 5; $i++) { ?>
					<div class="screen-bg" style="background-image: url('media/product-screen-<?php echo $i; ?>.jpg')"></div>
					<?php } ?>
				</div>
			</div>
		</div>
		<div id="page-nav-links">
			<div class="container">
				<div class="colgroup col-hd-4 col-lg-4 col-lg-4 col-xs-12">
					<div>
						<a href="" title="" class="contact-us-link">
							<h6>Contact Us</h6>
							<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</p>
						</a>
					</div>
					<div>
						<a href="" title="" class="support-link">
							<h6>Support</h6>
							<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</p>
						</a>
					</div>
					<div>
						<a href="" title="" class="faq-link">
							<h6>FAQ</h6>
							<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</p>
						</a>
					</div>
				</div>
			</div>
		</div>
		<?php require_once('include/footer.php'); ?>
	</body>
</html>