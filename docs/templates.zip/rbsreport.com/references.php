<!DOCTYPE html>
<html lang="en" dir="ltr">
	<head>
		<?php require_once('include/head.php'); ?>
	</head>
	<body>
		<?php require_once('include/header.php'); ?>
		<div id="global-title">
			<div class="container">
				<h1>Referanslar</h1>
			</div>
		</div>
		<div class="container main">
			<?php for ($i=0; $i < 5; $i++) { ?>
			<div class="references" onclick="location.href='referans-detay/schlumberger-emerson/2'">
				<div class="colgroup col-middle">
					<div class="col-hd-3 col-lg-3 col-sm-3 xs-none-i">
						<img src="https://robosoft.com.tr/upload/images/default/thumb/b4fc3cd6c0c2e2b4.jpg" width="100%" alt="SCHLUMBERGER-EMERSON">
					</div>
					<div class="col-hd-6 col-lg-6 col-sm-9 col-xs-12">
						<div class="references-text">
							<h6>SCHLUMBERGER-EMERSON </h6>
							<p>Firmamız Schlumberger ve Emerson firmalarına geliştirmiş olduğu test yazılım sistemi ile BP şirketinin Azerbaycan’daki Shah Deniz Projesi'nde kuyuların ön analizlerinin yapılmasını sağlamaktadır. Böylece analizi yapılan petrol veya doğalgaz kuyusu için daha derine inilmesi için kuyu analizleri RBSReport yazılım ve raporlama sisteminden çıkmaktadır. Milyonla..</p>
						</div>
					</div>
					<div class="col-hd-3 col-lg-3 sm-none-i">
						<div class="ta-c">
							<img src="https://robosoft.com.tr/upload/images/default/15727ddaa6c151a.jpg" alt="SCHLUMBERGER-EMERSON">
						</div>
					</div>
				</div>
				<a href="" class="overlay-link"></a>
			</div>
			<?php } ?>
		</div>
		<?php require_once('include/footer.php'); ?>
	</body>
</html>