<!DOCTYPE html>
<html lang="en" dir="ltr">
	<head>
		<?php require_once('include/head.php'); ?>
	</head>
	<body>
		<?php require_once('include/header.php'); ?>
		<div id="global-title">
			<div class="container">
				<h1>Support</h1>
			</div>
		</div>
		<div class="container main">
			<div id="support-tabs">
				<ul>
					<li><a href="support-form" title="" class="active">Support Form</a></li>
					<li><a href="faq" title="">FAQ</a></li>
					<li><a href="downloads" title="">Downloads</a></li>
				</ul>
			</div>
			<h2 id="support-title" class="ta-c">CREATE A SERVICE RECORD</h2>
			<div class="colgroup">
				<div class="col-hd-3 col-lg-3 col-pv-12"></div>
				<div class="col-hd-6 col-lg-6 col-pv-12">
					<form action="" method="get" accept-charset="utf-8">
						<table>
							<tbody>
								<tr>
									<td width="140"><label for="">Product</label></td>
									<td>
										<select name="">
											<option value="">Data Report</option>
											<option value="">Data Import</option>
											<option value="">Data Export</option>
										</select>
									</td>
								</tr>
								<tr>
									<td><label for="">Your E-mail</label></td>
									<td><input type="text" name=""></td>
								</tr>
								<tr>
									<td><label for="">Message Title</label></td>
									<td><input type="text" name=""></td>
								</tr>
								<tr>
									<td valign="top"><label for="">Your Message</label></td>
									<td><textarea name="" class="large"></textarea></td>
								</tr>
							</tbody>
						</table>
						<div class="ta-r">
							<button type="submit">SEND SERVICE RECORD</button>
						</div>
					</form>
				</div>
				<div class="col-hd-3 col-lg-3 col-pv-12"></div>
			</div>
		</div>
		<?php require_once('include/footer.php'); ?>
	</body>
</html>