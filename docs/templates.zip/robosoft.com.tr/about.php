<!DOCTYPE html>
<html lang="tr-TR" dir="ltr">
	<head>
		<?php require_once 'include/head.php'; ?>
	</head>
	<body>
		<?php require_once 'include/header.php'; ?>
		<script type="text/javascript">
			$(function(){
				$('#page-header').addClass('before-true').css('background-image','url("media/bg-news.png")');
			});
		</script>
		<div class="container content">
			<h4>Yenilikçi Teknolojiler</h4>
			<h2>Kurumsal Kimliğimiz</h2>
			<div class="colgroup col-hd-6 col-lg-6 col-sm-12">
				<div>
					<h5 class="content-title">HAKKIMIZDA </h5>
					<div class="normal-text">
						2009 tarihinden beri otomasyon ve dijitalizasyon alanlarına odaklanan Robosoft, birçok firmaya hizmet vermektedir. Firma, enerji verimliliği ve kaynak tasarrufu sağlayan teknolojilerin üretiminde, verimlilikle ilgili raporlama ve veri analizi desteği sağlayarak BT alanında önde gelen şirketlerden biri olmak için hizmet etmektedir. Robosoft, Enerji ( HES, RES, Petrol, vs.), Gıda, Üretim, Yiyecek ve İçecek sektörleri dahil birçok sektörde, raporlama, verimlilik, MES, ERP projeleri ve Uzaktan İzleme gibi birçok faaliyet desteği vermektedir.
					</div>
					<br>
				</div>
				<div>
					<h5 class="content-title">YETKİNLİKLERİMİZ</h5>
					<div class="normal-text">
						Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
						tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam
						<ul>
							<li>Yüksek Ar-Ge değerine sahip endüstriyel yazılımları geliştirmek.</li>
							<li>Türkiye’de olmayan ürünleri geliştirip, ülke ekonomisine katkıda bulunmak.</li>
							<li>Endüstriyel IT alanında, sadece IT olarak değil; saha uygulamalarıyla da tüm sisteme hakim olmak.</li>
							<li>Yüksek katma değere sahip yazılımlarımızla, sistemlerin verimliliğini arttırmak.</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<div class="useful-ideas">
			<div class="container">
				<h5>Faydalı fikirler!</h5>
				<div class="colgroup col-hd-4 col-lg-4 col-sm-6 col-xs-12">
					<div>
						<article>
							<img src="media/product.jpg" alt="">
							<h4>VİZYON</h4>
							<p>Teknolojik açıdan değişime hızlı adaptasyon sağlanması, kuruma katkı sağlamakla birlikte; çağın ötesinde hizmet vermeyi kendisine hedef edinen ve kendini geliştiren personeli, büyüme trendinin sürdürülmesi, modern yönetim ilkelerini benimseyerek, teknolojiyle entegre olmuş bir şirket olmak.</p>
						</article>
					</div>
					<div>
						<article>
							<img src="media/product.jpg" alt="">
							<h4>MİSYON</h4>
							<p>Türkiye’deki teknolojik sistemlerde farklılaşmak ve çözüm odaklı projeler üreterek iş ortaklarımıza maksimum faydayı sağlamak.</p>
						</article>
					</div>
					<div>
						<article>
							<img src="media/product.jpg" alt="">
							<h4>DEĞERLER</h4>
							<p>
								.	Müşteri memnuniyetini sağlamak. <br>
								.	Açık ve dürüst iletişim. <br>
								.	Yenilik ve süreçlere adaptasyon sağlamak. <br>
								.	Çalışanlarımızın memnuniyeti. <br>
								.	Mükemmellik.
							</p>
						</article>
					</div>
				</div>
			</div>
		</div>
		<?php require_once 'include/footer.php'; ?>
	</body>
</html>