var App = {};

$(function(){

	App.boolean = {
		false: true	
	};

	App.sizzle = {
		header: $('#sticky-header'),
		parallaxSlide: $('#parallax-slide'),
		services: $('.services'),
		customers: $('.customers'),
		products: $('.products'),
		mobileOpen: $('#mobile-nav-open'),
		mobileClose: $('#mobile-nav-close'),
		mobilenav: $('#mobile-nav')
	};
	
	'use strict';

	App.plugin = {

		slideshow: function()
		{
			App.sizzle.parallaxSlide.children('ul').bxSlider({
				mode: 'fade',
				auto: true,
				pause: 6000,
				prevSelector: App.sizzle.parallaxSlide.find(".sctrl .container"),
				nextSelector: App.sizzle.parallaxSlide.find(".sctrl .container"),
				prevText: '<img src="assets/images/icon/parallax-prev.png" width="40" height="40" class="wow fadeInLeft" data-wow-delay="950ms">',
				nextText: '<img src="assets/images/icon/parallax-next.png" width="40" height="40" class="wow fadeInRight" data-wow-delay="950ms">',
				pagerCustom: App.sizzle.parallaxSlide.find(".pager")
			});

			App.event.slideshowItemSpace();

			App.sizzle.parallaxSlide.find('.next-section').click(function(event){
				event.preventDefault();
				$('html, body').animate({ scrollTop: $( window ).outerHeight() }, 500);
			});
		},
		services: function()
		{
			App.sizzle.services.find('ul').bxSlider({
				mode: 'horizontal',
				auto: false,
				pager: false,
				slideWidth: 338,
				minSlides: 1,
				maxSlides: 8,
				moveSlides: 1,
				infiniteLoop: false,
				nextSelector: App.sizzle.services.find('.ctrl'),
				prevSelector: App.sizzle.services.find('.ctrl'),
				prevText: '<img src="assets/images/icon/parallax-prev.png" width="40" height="40">',
				nextText: '<img src="assets/images/icon/parallax-next.png" width="40" height="40">',
			});
		},
		customers: function()
		{
			App.sizzle.customers.find('ul').bxSlider({
				mode: 'horizontal',
				auto: false,
				pager: false,
				slideWidth: 197,
				minSlides: 1,
				maxSlides: 10,
				moveSlides: 1,
				slideMargin: 10,
				infiniteLoop: false,
				nextSelector: App.sizzle.customers.find('.ctrl'),
				prevSelector: App.sizzle.customers.find('.ctrl'),
				prevText: '<img src="assets/images/icon/parallax-prev.png" width="40" height="40">',
				nextText: '<img src="assets/images/icon/parallax-next.png" width="40" height="40">',
			});
		},
		products: function()
		{
			App.sizzle.products.find('ul').bxSlider({
				mode: 'horizontal',
				auto: false,
				pager: false,
				slideWidth: 270,
				minSlides: 1,
				maxSlides: 10,
				moveSlides: 1,
				slideMargin: 20,
				infiniteLoop: false,
				nextSelector: App.sizzle.products.find('.ctrl'),
				prevSelector: App.sizzle.products.find('.ctrl'),
				prevText: '<img src="assets/images/icon/parallax-prev.png" width="40" height="40">',
				nextText: '<img src="assets/images/icon/parallax-next.png" width="40" height="40">',
			});
		}
	};

	App.event = {
		
		slideshowItemSpace: function()
		{
			var spaceTop = App.sizzle.header.outerHeight();

			App.sizzle.parallaxSlide.find('.slide-item').css({
				paddingTop: spaceTop
			});

			App.sizzle.parallaxSlide.find('.sctrl').css('top', spaceTop);
		},
		mobileOpen: function()
		{
			App.sizzle.mobilenav.fadeIn();
		},
		mobileClose: function()
		{
			App.sizzle.mobilenav.fadeOut();
		}
	};

	App.page = {
		
		home: function()
		{
			App.sizzle.header.addClass('is_home');
			App.plugin.slideshow();
			App.plugin.services();
			App.plugin.customers();
			App.plugin.products();
		}
	};

	$( window ).resize(function(){
		App.event.slideshowItemSpace();
	});
	
	$( window ).load(function(){
		// code
	});

	App.sizzle.mobileOpen.click(function(event){
		event.preventDefault();
		App.event.mobileOpen();
	});

	App.sizzle.mobileClose.click(function(event){
		event.preventDefault();
		App.event.mobileClose();
	});

	new WOW().init();

	/** Contact Form **/

	$('form.footer-contact button[type=submit]').click(function(){
		var reply = new FormData($('form.footer-contact')[0]);
		$.ajax({
			dataType: "json",
			type:"post",
			url:"pages/contact_form_ajax.php",
			data:reply,
			async: true,
			cache: false,
			contentType: false,
			processData: false,
			beforeSend :function()
			{
				$('.preloader-gif').show();
			},
			success: function(reply){
				$('.preloader-gif').hide();
				$('body').append(reply.message);
				if(reply.status === "success"){
					$('form.footer-contact button[type=reset]').trigger("click");
				}
			}
		});
	});

	$('form.contact-form button[type=submit]').click(function(){
		var reply = new FormData($('form.contact-form')[0]);
		$.ajax({
			dataType: "json",
			type:"post",
			url:"pages/contact_form2_ajax.php",
			data:reply,
			async: true,
			cache: false,
			contentType: false,
			processData: false,
			beforeSend :function()
			{
				$('.preloader-gif').show();
			},
			success: function(reply){
				$('.preloader-gif').hide();
				$('body').append(reply.message);
				if(reply.status === "success"){
					$('form.contact-form button[type=reset]').trigger("click");
				}
			}
		});
	});

	/** E-Bulten **/

	$('div.newsletter button[type=submit]').click(function(){
		var reply = $('div.newsletter input[type=text]').val();
		$.ajax({
			dataType:"json",
			type:"post",
			url:"pages/ebulten_ajax.php",
			data:{"email":reply},
			beforeSend :function()
			{
				$('.preloader-gif').show();
			},
			success: function(reply){
				$('.preloader-gif').hide();
				$('body').append(reply.message);
				if(reply.status === "success"){
					$('div.newsletter input[type=text]').val("");
				}
			}
		});
	});

});