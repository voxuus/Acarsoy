/*/
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
#                                                                           #
#   Copyright © ROBOSOFT                                                    #
#                                                                           #
#   @author    : ARAS EKINCI                                                #
#   @url       : www.arasekinci.com.tr                                      #
#   @mail      : info@arasekinci.com.tr                                     #
#   @starting  : February 22, 2017                                          #
#   @example   : robosoft.com.tr                                            #
#                                                                           #
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
/*/

'use strict';

var app;

$(function(){

	$('#navigation-open').click(function(event){
		event.preventDefault();

		$('#page-nav-bg, #page-nav').fadeIn('400');
		$('body').css('overflow','hidden');
	});

	$('#navigation-close').click(function(event){
		event.preventDefault();

		$('#page-nav-bg, #page-nav').fadeOut('400');
		$('body').css('overflow','');
	});

	/** Contact Form **/

	$('form.footer-contact button[type=submit]').click(function(){
		var reply = new FormData($('form.footer-contact')[0]);
		$.ajax({
			dataType: "json",
			type:"post",
			url:"pages/contact_form_ajax.php",
			data:reply,
			async: true,
			cache: false,
			contentType: false,
			processData: false,
			beforeSend :function()
			{
				$('.preloader-gif').show();
			},
			success: function(reply){
				$('.preloader-gif').hide();
				$('body').append(reply.message);
				if(reply.status === "success"){
					$('form.footer-contact button[type=reset]').trigger("click");
				}
			}
		});
	});

	$('form.contact-form button[type=submit]').click(function(){
		var reply = new FormData($('form.contact-form')[0]);
		$.ajax({
			dataType: "json",
			type:"post",
			url:"pages/contact_form2_ajax.php",
			data:reply,
			async: true,
			cache: false,
			contentType: false,
			processData: false,
			beforeSend :function()
			{
				$('.preloader-gif').show();
			},
			success: function(reply){
				$('.preloader-gif').hide();
				$('body').append(reply.message);
				if(reply.status === "success"){
					$('form.contact-form button[type=reset]').trigger("click");
				}
			}
		});
	});

	/** E-Bulten **/

	$('div.newsletter button[type=submit]').click(function(){
		var reply = $('div.newsletter input[type=text]').val();
		$.ajax({
			dataType:"json",
			type:"post",
			url:"pages/ebulten_ajax.php",
			data:{"email":reply},
			beforeSend :function()
			{
				$('.preloader-gif').show();
			},
			success: function(reply){
				$('.preloader-gif').hide();
				$('body').append(reply.message);
				if(reply.status === "success"){
					$('div.newsletter input[type=text]').val("");
				}
			}
		});
	});
	
});