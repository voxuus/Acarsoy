<!DOCTYPE html>
<html lang="tr-TR" dir="ltr">
	<head>
		<?php require_once 'include/head.php'; ?>
	</head>
	<body>
		<?php require_once 'include/header.php'; ?>
		<script type="text/javascript">
			$(function(){
				$('#page-header').addClass('before-true').css('background-image','url("media/bg-news.png")');
				$('#page-footer').css('padding-top','0px').children(".container").remove();
				$('#page-footer').children(".copyright").css('margin-top','0px');
			});
		</script>
		<div class="container main" id="contact">
			<div class="nav-tabs">
				<a href="" title="" class="active">TÜRKİYE OFİSİ</a>
				<a href="" title="">USA OFFICE</a>
			</div>
			<div class="colgroup col-middle nav-item" style="min-height: 100px;">
				<div class="col-hd-3 col-lg-3 col-xs-12">
					<address>
						<div class="icon phone"></div>
						<h6>Telefon</h6>
						<a href="tel:02165945431" title="">0 (216) 594 54 31</a>
					</address>
				</div>
				<div class="col-hd-5 col-lg-5 col-xs-12">
					<address>
						<div class="icon address"></div>
						<h6>Ofis Adresimiz</h6>
						<p>Poligon Cad. Buyaka İş Kuleleri - Kule  3 Giriş Kat Fatih Sultan Mehmet Mah. 34771 Ümraniye/İstanbul</p>
					</address>
				</div>
				<div class="col-hd-4 col-lg-4 col-xs-12">
					<address>
						<div class="icon email"></div>
						<h6>E-Mail</h6>
						<a href="mailto:destek@robosoft.com.tr" title="">destek@robosoft.com.tr</a>
						<div class="clearfix"></div>
						<a href="mailto:tasarim@robosoft.com.tr" title="">tasarim@robosoft.com.tr</a>
					</address>
				</div>
			</div>
			<div class="colgroup col-middle nav-item" style="min-height: 100px; display: none;">
				<div class="col-hd-3 col-lg-3 col-xs-12">
					<address>
						<div class="icon phone"></div>
						<h6>Phone</h6>
						<a href="tel:+857475475" title="">+857 475 475</a>
					</address>
				</div>
				<div class="col-hd-5 col-lg-5 col-xs-12">
					<address>
						<div class="icon address"></div>
						<h6>Office Address</h6>
						<p>Sit adipisicing esse velit aute do ad minim qui deserunt aute veniam laborum duis.</p>
					</address>
				</div>
				<div class="col-hd-4 col-lg-4 col-xs-12">
					<address>
						<div class="icon email"></div>
						<h6>E-Mail</h6>
						<a href="mailto:info@robosoft.com.tr" title="">info@robosoft.com.tr</a>
						<div class="clearfix"></div>
						<a href="mailto:design@robosoft.com.tr" title="">design@robosoft.com.tr</a>
					</address>
				</div>
			</div>
			<div class="socials">
				<a href="" title="" style="background-color: #CF4332">GOOGLE +</a>
				<a href="" title="" style="background-color: #33CCFF">TWITTER</a>
				<a href="" title="" style="background-color: #0086B6">LINKEDIN</a>
			</div>
			<div class="form-title">
				<h4>İLETİŞİM FORMU</h4>
				<p>HER KONUDA YAZABİLİRSİNİZ</p>
			</div>
			<form action="" method="get" accept-charset="utf-8">
				<div class="form-row colgroup col-hd-4 col-lg-4 col-sm-12">
					<div><input type="text" name="" placeholder="ADINIZ"></div>
					<div><input type="text" name="" placeholder="TELEFON NUMARANIZ"></div>
					<div><input type="text" name="" placeholder="E-MAIL ADRESİNİZ"></div>
				</div>
				<div class="form-row">
					<textarea name="" placeholder="MESAJINIZ"></textarea>
				</div>
				<div class="form-row ta-r">
					<button type="">GÖNDER</button>
				</div>
			</form>
			<script type="text/javascript">
				$(function(){
					$('.nav-tabs a').click(function(event){
						event.preventDefault();
						$('.nav-tabs a').removeClass('active');
						$('.nav-item').hide();
						$( this ).addClass('active');
						$('.nav-item').eq( $( this ).index() ).show();
					});
				});
			</script>
		</div>
		<?php require_once 'include/footer.php'; ?>
	</body>
</html>