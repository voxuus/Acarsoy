<div id="subscribe">
    <div class="container">
        <div class="colgroup col-middle">
            <div class="col-hd-6 col-lg-6 col-xs-12">
                <h3>E-Mail Bültenimize Katılın</h3>
                <p>Yeniliklerimizden faydalanın!</p>
            </div>
            <div class="col-hd-6 col-lg-6 col-xs-12">
                <div class="input-group">
                    <input type="text" placeholder="E-mail adresiniz..">
                    <button type="submit">KAYDET</button>
                </div>
            </div>
        </div>
    </div>
</div>
<footer id="page-footer">
    <div class="container">
        <h2>BİZE ULAŞIN</h2>
        <p>Lorem Ipsum is simply dummy text of theprinting and typesetting.</p>
        <div class="colgroup col-top">
            <div class="col-hd-5 col-lg-5 col-sm-12">
                <address>
                    <dl class="address">
                        <dt>Adres Bilgilerimiz</dt>
                        <dd>Poligon Cad. Buyaka İş Kuleleri - Kule 3 Giriş Kat Fatih Sultan Mehmet Mah. 34771 Ümraniye/İstanbul</dd>
                    </dl>
                    <dl class="phone">
                        <dt>Telefon Numaramız</dt>
                        <dd><a href="tel:+02165945431">+0 (216) 594 54 31</a></dd>
                    </dl>
                    <dl class="email">
                        <dt>Email:</dt>
                        <dd><a href="mailto:info@robosoft.com.tr">info@robosoft.com.tr</a></dd>
                    </dl>
                </address>
            </div>
            <div class="col-hd-7 col-lg-7 col-sm-12">
                <form action="" method="get" accept-charset="utf-8">
                    <div class="form-row colgroup col-hd-6 col-lg-6 col-pv-12">
                        <div><input type="text" name="" placeholder="Adınız"></div>
                        <div><input type="text" name="" placeholder="Firma Adı"></div>
                        <div><input type="text" name="" placeholder="Telefon Numaranız"></div>
                        <div><input type="text" name="" placeholder="E-Mail Adresiniz"></div>
                    </div>
                    <div class="form-row">
                        <textarea name="" placeholder="Mesajınız"></textarea>
                    </div>
                    <div class="form-row">
                        <button type="">GÖNDER</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="copyright">
        <div class="container">
            <div class="colgroup col-middle col-hd-4 col-lg-4 col-sm-6 col-xs-12">
                <div class="xs-none-i">
                    <img src="assets/images/main/robosoft.png" alt="">
                </div>
                <div class="sm-none-i">
                    <div class="ta-c">
                        <img src="assets/images/main/footer-center-img.png" alt="">
                    </div>
                </div>
                <div>
                    <p class="copyright-text">Copyright & 2017 Robosoft. Tüm Hakları Saklıdır.</p>
                </div>
            </div>
        </div>
    </div>
</footer>