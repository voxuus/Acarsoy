<header id="page-header">
	<div class="container">
		<div class="colgroup col-middle">
			<div class="col-hd-6 col-lg-6 col-sm-9">
				<a href="" id="app"><img src="assets/images/main/robosoft.png" width="160" height="25" alt=""></a>
			</div>
			<div class="col-hd-6 col-lg-6 col-sm-3 col-right">
				<a href="" id="navigation-open"><img src="assets/images/icon/navigation-open.png" width="30" height="22" alt=""></a>
			</div>
		</div>
	</div>
	<hr>
	<div id="page-title">
		<h1>YENİ NELER VAR?</h1>
		<div class="breadcrumb">
			<a href="">ANASAYFA</a>
			<a href="">ÜRÜNLER</a>
		</div>
	</div>
</header>
<div id="page-nav-bg"></div>
<div id="page-nav">
	<div class="d-t">
		<div class="d-tc va-m">
			<header class="page-header-menu">
				<div class="container">
					<div class="colgroup col-middle">
						<div class="col-hd-4 col-lg-4 sm-none-i">
							<a href="" id="app"><img src="assets/images/main/robosoft.png" width="160" height="25" alt=""></a>
						</div>
						<div class="col-hd-4 col-lg-4 col-sm-9">
							<ul class="lang">
								<li><a href="" tilte="" class="active">Türkçe</a></li>
								<li><a href="" tilte="">English</a></li>
							</ul>
						</div>
						<div class="col-hd-4 col-lg-4 col-sm-3 col-right">
							<a href="" id="navigation-close"><img src="assets/images/icon/navigation-open.png" width="30" height="22" alt=""></a>
						</div>
					</div>
				</div>
				<hr>
			</header>
			<div class="container">
				<ul class="nav">
					<li><a href="">ANASAYFA</a></li>
					<li><a href="">KURUMSAL</a></li>
					<li><a href="">ÜRÜNLER</a></li>
					<li><a href="" class="active">HİZMETLERİMİZ</a></li>
					<li><a href="">REFERANSLARIMIZ</a></li>
					<li><a href="">İLETİŞİM</a></li>
				</ul>
			</div>
			<footer class="download">
				<p>Download Robosoft mobile application on platforms.</p>
				<div class="colgroup colmin">
					<div class="col-hd-6 col-lg-6">
						<div class="ta-r">
							<a href="" title=""><img src="assets/images/main/download-ios.png" alt=""></a>
						</div>
					</div>
					<div class="col-hd-6 col-lg-6">
						<div class="ta-l">
							<a href="" title=""><img src="assets/images/main/download-android.png" alt=""></a>
						</div>
					</div>
				</div>
			</footer>
		</div>
	</div>
</div>