<!DOCTYPE html>
<html lang="tr-TR" dir="ltr">
	<head>
		<?php require_once 'include/head.php'; ?>
	</head>
	<body>
		<?php require_once 'include/header.php'; ?>
		<script type="text/javascript">
			$(function(){
				$("#slideshow ul").bxSlider({
					mode: 'fade',
					auto: false,
					pause: 7000,
					prevSelector: $("#slideshow-con .container"),
					nextSelector: $("#slideshow-con .container"),
					prevText: '<img src="assets/images/icon/slideshow-prev.png" width="36" height="67">',
					nextText: '<img src="assets/images/icon/slideshow-next.png" width="36" height="67">',
					pagerCustom: $("#slideshow-pag")
				});

				$("#our-services ul").bxSlider({
					mode: 'horizontal',
					auto: false,
					pause: 7000,
					minSlides: 1,
					maxSlides: 4,
					slideMargin: 15,
					slideWidth: 275,
					controls: false,
					pagerCustom: $("#ourservices-pag")
				});

				$("#page-header").addClass("homepage");
				
				$("#page-title").remove();

				$("body").addClass('homepage');
			});
		</script>
		<div id="slideshow">
			<ul>
				<?php for ($i=0; $i < 3; $i++) { ?>
				<li style="background-image: url('media/slideshow.jpg')">
					<div class="container d-t">
						<div class="d-tc va-m">
							<hgroup>
								<h1>Robosoft ile</h1>
								<h2>ENDÜSTRİYEL YAZILIMDA <?php echo $a = $i + 1; ?></h2>
								<h3>İnovatif Çözümler</h3>
								<a href="">PROJELER +</a>
							</hgroup>
						</div>
					</div>
				</li>
				<?php } ?>
			</ul>
			<div id="slideshow-con" class="sm-none"><div class="container"></div></div>
			<div id="slideshow-pag">
				<div class="container">
					<?php for ($i=0; $i < 3; $i++) { ?>
					<a href="" data-slide-index="<?php echo $i; ?>"></a>
					<?php } ?>
				</div>
			</div>
		</div>
		<div id="tech-integration">
			<div class="container">
				<h6>Modern Yönetim İlkeleri ile </h6>
				<h3>Teknolojik Entegrasyon</h3>
				<p>Teknolojik açıdan değişime hızlı adaptasyon sağlanması, kuruma katkı sağlamakla birlikte; çağın ötesinde hizmet vermeyi kendisine hedef edinen ve kendini geliştiren personeli, büyüme trendinin sürdürülmesi, modern yönetim ilkelerini benimseyerek, teknolojiyle entegre olmuş bir şirket olmak.</p>
				<a href="">Daha Fazla Bilgi +</a>
			</div>
		</div>
		<div id="our-services">
			<div class="container">
				<h6>Neler Yapıyoruz?</h6>
				<h4>HİZMETLER</h4>
				<ul>
					<?php for ($i=0; $i < 5; $i++) { ?>
					<li>
						<article>
							<img src="media/our-services.png" alt="">
							<h5>Enerji</h5>
							<p>Robosoft® Kontrol firmasının öncelikli hizmetlerinden bir tanesi enerji raporlaması; diğerleri ise faturalama ve izleme projeleridir.</p>
							<div>
								<span></span>
								<span></span>
								<span></span>
							</div>
							<a href="" class="overlay-link"></a>
						</article>
					</li>
					<?php } ?>
				</ul>
				<div id="ourservices-pag">
					<?php for ($i=0; $i < 5; $i++) { ?>
					<a href="" title="" data-slide-index="<?php echo $i; ?>"></a>
					<?php } ?>
				</div>
			</div>
		</div>
		<div id="our-partners" class="xs-none">
			<div class="container">
				<h3>PARTNERLERİMİZ</h3>
				<p>Lorem Ipsum is simply dummy text of theprinting and typesetting it has the randomised words Lorem ipsum dolor sit amet</p>
				<div class="colgroup col-middle col-hd-3 col-lg-3 col-sm-6">
					<div>
						<div class="partners">
							<img src="media/partners-1.png" alt="">
						</div>
					</div>
					<div>
						<div class="partners">
							<img src="media/partners-2.png" alt="">
						</div>
					</div>
					<div>
						<div class="partners">
							<img src="media/partners-3.png" alt="">
						</div>
					</div>
					<div>
						<div class="partners">
							<img src="media/partners-4.png" alt="">
						</div>
					</div>
				</div>
			</div>
		</div>
		<div id="news">
			<div class="container">
				<h2>ÜRÜNLERİMİZ</h2>
				<p>Verimli Sistemler için Çözümlerimiz</p>
				<div class="colgroup col-hd-3 col-lg-3 col-xs-6 col-pv-12">
					<?php for ($i=0; $i < 4; $i++) { ?>
					<div>
						<article style="padding-left: 0">
							<h4>RBSReport®</h4>
							<img src="media/news.png" alt="">
							<p>RBSReport®, bilgi işlem çalışanları ve endüstriyel cihazlardan veri toplamak isteyen uzmanlar için geliştirilmiş Excel® ve Trend raporlama programıdır.</p>
							<a href="" title="">DEVAMINI OKU</a>
						</article>
					</div>
					<?php } ?>
				</div>
			</div>
		</div>
		<?php require_once 'include/footer.php'; ?>
	</body>
</html>