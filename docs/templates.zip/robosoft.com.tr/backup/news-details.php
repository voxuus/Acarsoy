<!DOCTYPE html>
<html lang="tr-TR" dir="ltr">
	<head>
		<?php require_once 'include/head.php'; ?>
	</head>
	<body>
		<?php require_once 'include/header.php'; ?>
		<script type="text/javascript">
			$(function(){
				$('#page-header').addClass('before-true').css('background-image','url("media/bg-news.png")');
			});
		</script>
		<div class="container main" id="news-details">
			<div class="colgroup col-middle">
				<div class="col-hd-8 col-lg-8 col-pv-12">
					<img src="media/news-details.png" width="100%" alt="">
					<br><br>
				</div>
				<div class="col-hd-4 col-lg-4 col-pv-12">
					<img src="media/news-details.png" width="100%" alt="">
					<br><br>
					<img src="media/news-details.png" width="100%" alt="">
				</div>
			</div>
			<time class="news-time">3 OCAK, SALI</time>
			<div class="normal-text">
				<b>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it </b>
			</div>
			<br>
			<div class="colgroup col-hd-6 col-lg-6 col-sm-12">
				<div>
					<div class="normal-text">
						Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
						<br><br>
					</div>
				</div>
				<div>
					<div class="normal-text">
						Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
					</div>
				</div>
			</div>
		</div>
		<?php require_once 'include/footer.php'; ?>
	</body>
</html>