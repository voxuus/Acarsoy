<!DOCTYPE html>
<html lang="tr-TR" dir="ltr">
	<head>
		<?php require_once 'include/head.php'; ?>
	</head>
	<body>
		<?php require_once 'include/header.php'; ?>
		<script type="text/javascript">
			$(function(){
				$('#page-header').addClass('before-true').css('background-image','url("media/bg-news.png")');
			});
		</script>
		<div class="container">
			<div class="page-inner">
				<h4>Yenilikçi Teknolojiler</h4>
				<h2>Endüstriyel Hizmetlerimiz  </h2>
				<div class="colgroup col-hd-6 col-lg-6 col-sm-12">
					<div>
						<h5 class="page-inner-title">ENDÜSTRİYEL HİZMETLERİMİZ</h5>
						<div class="normal-text">
							Robosoft® Kontrol firması, endüstriyel tüm sistemlere uygun raporlama ve IT çözümleri vermektedir. Gıda, Arıtma, Enerji, vb. tüm üretim süreçlerini yazılımlarımızla takip edebilirsiniz.
							<br><br>
							Robosoft® Kontrol, öncelikle, verdiği hizmette standardını, hem sektörün hem de müşterisinin isteğine göre belirlemektedir. Robosoft® Kontrol, yüksek kalite yazılımlarıyla sektöre hizmet vermektedir. Bu amaçla geliştirilmiş RBSReport yazılımımızla, endüstriyel tüm sistemlerin verilerini toplayabilir, reçete bazında ve tarih bazında istediğiniz an raporlayabilirsiniz.
						</div>
						<br>
					</div>
					<div>
						<h5 class="page-inner-title">ENDÜSTRİYEL HİZMETLERİMİZ</h5>
						<div class="normal-text">
							Robosoft® Kontrol firması, endüstriyel tüm sistemlere uygun raporlama ve IT çözümleri vermektedir. Gıda, Arıtma, Enerji, vb. tüm üretim süreçlerini yazılımlarımızla takip edebilirsiniz.
							<br><br>
							Robosoft® Kontrol, öncelikle, verdiği hizmette standardını, hem sektörün hem de müşterisinin isteğine göre belirlemektedir. Robosoft® Kontrol, yüksek kalite yazılımlarıyla sektöre hizmet vermektedir. Bu amaçla geliştirilmiş RBSReport yazılımımızla, endüstriyel tüm sistemlerin verilerini toplayabilir, reçete bazında ve tarih bazında istediğiniz an raporlayabilirsiniz.
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="our-services-inner">
			<div class="container">
				<h5>HİZMETLERİMİZ</h5>
				<p>Yenilikçi Teknolojiler</p>
				<div class="colgroup col-hd-3 col-lg-3 col-md-4 col-sm-6 col-xs-12">
					<?php for ($i=0; $i < 8; $i++) { ?>
					<div>
						<article>
							<img src="assets/images/icon/our-services.png" width="28"  alt="">
							<h4>RBSReport® ile HES Veri Toplama ve Raporlama</h4>
							<p>HES Veri Toplama ve Raporlama Sistemleri Robosoft® Kontrol firmasının geliştirmiş...</p>
						</article>
					</div>
					<?php } ?>
				</div>
			</div>
		</div>
		<?php require_once 'include/footer.php'; ?>
	</body>
</html>