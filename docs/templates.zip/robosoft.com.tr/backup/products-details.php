<!DOCTYPE html>
<html lang="tr-TR" dir="ltr">
	<head>
		<?php require_once 'include/head.php'; ?>
	</head>
	<body>
		<?php require_once 'include/header.php'; ?>
		<script type="text/javascript">
			$(function(){
				$('#page-header').addClass('before-true').css('background-image','url("media/bg-news.png")');

				$("#products-details #slide ul").bxSlider({
					auto: false,
					pause: 7000,
					adaptiveHeight: true,
					prevSelector: $("#slide-con"),
					nextSelector: $("#slide-con"),
					prevText: '<img src="assets/images/icon/product-prev.png" width="40" height="40">',
					nextText: '<img src="assets/images/icon/product-next.png" width="40" height="40">',
					pager: false
				});
			});
		</script>
		<div class="container main" id="products-details">
			<div class="colgroup col-middle">
				<div class="col-hd-9 col-lg-9 col-sm-8 col-xs-12">
					<header>
						<h4>Verimli Sistemler için Çözümlerimiz</h4>
						<h2>ENERJİ İZLEME</h2>
					</header>
				</div>
				<div class="col-hd-3 col-lg-3 col-sm-4 col-xs-12">
					<a href="" title="" class="micro-site">MİKRO SİTEYE GİT</a>
				</div>
			</div>
			<div id="slide">
				<ul>
					<li>
						<div class="d-t">
							<div class="d-tc va-m">
								<img src="media/product.png" alt="">
							</div>
						</div>
					</li>
				</ul>
				<div id="slide-con"></div>
			</div>
			<div class="colgroup pv-none-i">
				<div class="col-hd-8 col-lg-8 col-sm-6">
					<div class="product-img d-t">
						<div class="d-tc va-m">
							<img src="media/product.png" alt="">
						</div>
					</div>
				</div>
				<div class="col-hd-4 col-lg-4 col-sm-6">
					<div class="product-img d-t">
						<div class="d-tc va-m">
							<img src="media/product.png" alt="">
						</div>
					</div>
				</div>
			</div>
			<br class="pv-none-i"><br class="pv-none-i">
			<div class="colgroup">
				<div class="col-hd-8 col-lg-8 col-xs-12">
					<div class="normal-text">
						<h3>VERİ TOPLAMA VE RAPORLAMA</h3>
						<h4><em>Veri toplama ve raporlama sistemleri</em></h4>
						<br>
						Sisteminizde var olan PLC, DCS veya kontrol cihazlarından alınan verileri analiz edip, sisteminizin verimliliklerini ölçen sistemler tasarlamaktayız. İster otomatik kayıt ile alınan bilgiler, ister manuel veri giriş ekranlarıyla alınan bilgiler olsun; fabrikanızdaki kağıt israfını engelleyecek ve birçok verimlilik projesine öncülük yapacak verileri size sağlayacak raporlama sistemleri kurmaktayız. 
						<br><br>
						RBSReport®, Veri toplamaya yönelik otomasyon sistemleri kurulumu;<br><br>
						⦁	HES, RES ve GÜNEŞ enerji üretim tesisleri raporlama uygulamaları<br>
						⦁	Enerji faturalama uygulamaları<br>
						⦁	Gıda sektörüne yönelik raporlama uygulamaları<br>
						⦁	PLC, DCS’li sistemlerin raporlama ve IT uygulamaları<br>
						⦁	iPad, iPhone,Android izleme ve raporlama<br><br>
						manuel veri giriş ekranlarıyla istediğiniz otomasyonda olmayan tüm bilgileri de kayıt altına almanızı sağlamaktadır. Böylece HES (Hidro Elektrik Santrali), RES (Rüzgar Enerji Santrali) ve üretim tesisindeki dijital verimliliği arttırmaktadır. Detaylı bilgi için bizimle irtibata geçiniz..
						<hr>
						<a href="">Veri toplama broşürü için tıklayınız.</a>
					</div>
				</div>
				<div class="col-hd-4 col-lg-4 col-xs-12">
					<div class="product-info">
						<div class="colgroup col-hd-12 col-lg-12 col-xs-6 col-pv-12">
							<div>
								<h6>ÜRÜN</h6>
								<p>RBSReport®</p>
							</div>
							<div>
								<h6>YAYINLANMA TARİHİ</h6>
								<p>3 Şubat 2017</p>
							</div>
							<div>
								<h6>KULLANILAN TEKNOLOJİLER</h6>
								<p>Adobe Fireworks,  .NET, CSS 3, HTML 5, PHP 5</p>
							</div>
							<div>
								<h6>ÜRÜNÜ PAYLAŞIN</h6>
								<p>
									<a href="" title=""><img src="assets/images/icon/product-twitter.png" alt=""></a>
									<a href="" title=""><img src="assets/images/icon/product-facebook.png" alt=""></a>
								</p>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="controls">
				<div class="colgroup col-hd-6 col-lg-6">
					<div><a href="" title="" class="prev">ÖNCEKİ ÜRÜN</a></div>
					<div class="col-right"><a href="" title="" class="next">SONRAKİ ÜRÜN</a></div>
				</div>
			</div>
		</div>
		<?php require_once 'include/footer.php'; ?>
	</body>
</html>