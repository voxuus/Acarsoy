<!DOCTYPE html>
<html lang="tr-TR" dir="ltr">
	<head>
		<?php require_once 'include/head.php'; ?>
	</head>
	<body>
		<?php require_once 'include/header.php'; ?>
		<script type="text/javascript">
			$(function(){
				$('#page-header').addClass('before-true').css('background-image','url("media/bg-news.png")');
			});
		</script>
		<div class="container main">
			<div class="product-cat">
				<a href="" title="" class="active">TÜM ÜRÜNLER</a>
				<a href="" title="">KATEGORİ 1</a>
				<a href="" title="">KATEGORİ 2</a>
				<a href="" title="">KATEGORİ 3</a>
			</div>
			<div class="colgroup col-hd-4 col-lg-4 col-sm-6 col-xs-12">
				<?php for ($i=0; $i < 6; $i++) { ?>
				<div>
					<div class="product" style="background-image: url('media/product.png')">
						<div class="overlay">
							<div class="top">İNCELE</div>
							<div class="bottom">
								<h6>Enerji İzmele Yazılımı</h6>
								<h5>ROBOSOFT ENERGY</h5>
							</div>
						</div>
						<a href="urun-detay" title="" class="overlay-link"></a>
					</div>
				</div>
				<?php } ?>
			</div>
			<br><br>
			<div class="product-cat">
				<a href="" title="" class="active">TÜM ÜRÜNLER</a>
				<a href="" title="">KATEGORİ 1</a>
				<a href="" title="">KATEGORİ 2</a>
				<a href="" title="">KATEGORİ 3</a>
			</div>
			<div class="colgroup col-hd-4 col-lg-4 col-sm-6 col-xs-12">
				<?php for ($i=0; $i < 6; $i++) { ?>
				<div>
					<div class="product" style="background-image: url('media/product.png')">
						<div class="overlay">
							<div class="top">İNCELE</div>
							<div class="bottom">
								<h6>Enerji İzmele Yazılımı</h6>
								<h5>ROBOSOFT ENERGY</h5>
							</div>
						</div>
						<a href="" title="" class="overlay-link"></a>
					</div>
				</div>
				<?php } ?>
			</div>
		</div>
		<?php require_once 'include/footer.php'; ?>
	</body>
</html>