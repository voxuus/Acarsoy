<header id="sticky-header">
	<div class="navigation">
		<div class="container">
			<div class="colgroup col-middle">
				<div class="col-hd-3 col-lg-3 col-sm-3">
					<div class="notfs">
						<a href="" title="">
							<img src="assets/images/main/robosoft.png" width="165" height="30" alt="" class="app wow fadeIn">
						</a>
					</div>
				</div>
				<div class="col-hd-9 col-lg-9 col-sm-9 col-right">
					<ul class="sm-none-i">
						<li><a href="" title="" class="wow fadeIn active" data-wow-delay="0ms">Anasayfa</a></li>
						<li><a href="" title="" class="wow fadeIn" data-wow-delay="100ms">Kurumsal</a></li>
						<li><a href="" title="" class="wow fadeIn" data-wow-delay="300ms">Ürünler</a></li>
						<li><a href="" title="" class="wow fadeIn" data-wow-delay="500ms">Hizmetler</a></li>
						<li><a href="" title="" class="wow fadeIn" data-wow-delay="600ms">Referanslar</a></li>
						<li><a href="" title="" class="wow fadeIn" data-wow-delay="700ms">Haberler</a></li>
						<li><a href="" title="" class="wow fadeIn" data-wow-delay="700ms">İletişim</a></li>
						<li><a href="" title="" class="wow fadeIn lang first-lang active" data-wow-delay="700ms">TR</a></li>
						<li><a href="" title="" class="wow fadeIn lang" data-wow-delay="800ms">EN</a></li>
					</ul>
					<a href="" id="mobile-nav-open" class="sm-show-i"><img src="assets/images/icon/navigation-open.png" alt=""></a>
				</div>
			</div>
		</div>
	</div>
	<div class="head-title">
		<h1>YENİ NELER VAR?</h1>
		<div class="breadcrumb">
			<a href="">ANASAYFA</a>
			<a href="">ÜRÜNLER</a>
		</div>
	</div>
</header>
<div id="mobile-nav">
	<header>
		<a href="" title="Menüyü Kapat" id="mobile-nav-close" class="wow flipX"><svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 64 64" xml:space="preserve" width="15px" height="15px"><path d="M28.941,31.786L0.613,60.114c-0.787,0.787-0.787,2.062,0,2.849c0.393,0.394,0.909,0.59,1.424,0.59   c0.516,0,1.031-0.196,1.424-0.59l28.541-28.541l28.541,28.541c0.394,0.394,0.909,0.59,1.424,0.59c0.515,0,1.031-0.196,1.424-0.59 c0.787-0.787,0.787-2.062,0-2.849L35.064,31.786L63.41,3.438c0.787-0.787,0.787-2.062,0-2.849c-0.787-0.786-2.062-0.786-2.848,0 L32.003,29.15L3.441,0.59c-0.787-0.786-2.061-0.786-2.848,0c-0.787,0.787-0.787,2.062,0,2.849L28.941,31.786z"></path></svg></a>
		<a href="" class="active">TR</a>
		<a href="">EN</a>
	</header>
	<ul>
		<li><a href="" title="">Home</a></li>
		<li><a href="" title="">Corporate</a></li>
		<li><a href="" title="Sectors">Sectors</a></li>
		<li><a href="" title="Services">Our Services</a></li>
		<li><a href="" title="">Products</a></li>
		<li><a href="" title="Projects">Projects</a></li>
		<li><a href="" title="News">News</a></li>
		<li><a href="" title="Contact">Contact</a></li>
	</ul>
</div>