<!DOCTYPE html>
<html lang="tr-TR" dir="ltr">
	<head>
		<?php require_once 'include/head.php'; ?>
		<script>
			$(function(){
				App.page.home();
			});
		</script>
	</head>
	<body>
		<?php require_once 'include/header.php'; ?>
		<div id="parallax-slide">
			<ul>
				<?php for ($i=0; $i < 5; $i++) { ?>
				<li class="slide-item" style="background-image: url('media/slideshow.jpg')">
					<div class="caption">
						<div class="caption-scope">
							<div class="container">
								<hgroup>
									<h3 class="wow fadeInUp" data-wow-delay="150ms">ENDÜSTRİ 4.0 İLE</h3>
									<h2 class="wow fadeInUp" data-wow-delay="350ms">İnovatif Çözümler</h2>
									<p class="wow fadeInUp" data-wow-delay="600ms">Dolor sit amet, consectetur adipisicing elit. Eveniet quam repellendus illum incidunt odio. Esse dolorem fuga alias quisquam nemo, hic architecto illo provident illum, veritatis vitae facilis repellendus est.</p>
									<a href="#" title="" class="wow fadeInUp" data-wow-delay="850ms">DEVAMI +</a>
								</hgroup>
							</div>
						</div>
					</div>
				</li>
				<?php }; ?>
			</ul>
			<div class="sctrl">
				<div class="container"></div>
			</div>
			<div class="pager">
				<div class="container">
					<?php for ($i=0; $i < 5; $i++) { ?>
					<a href="" title="" data-slide-index="<?php echo $i; ?>"></a>
					<?php }; ?>
				</div>
			</div>
			<a href=".about-the-company" class="next-section"><img src="assets/images/icon/home-next-section.png" alt=""></a>
		</div>
		<div class="home-box about-the-company">
			<div class="container">
				<h6 class="wow fadeInUp" data-wow-delay="100ms">Modern Yönetim İlkeleri ile</h6>
				<h3 class="wow fadeInUp" data-wow-delay="200ms">Teknolojik Entegrasyon</h3>
				<p class="wow fadeInUp" data-wow-delay="300ms">Teknolojik açıdan değişime hızlı adaptasyon sağlanması, kuruma katkı sağlamakla birlikte; çağın ötesinde hizmet vermeyi kendisine hedef edinen ve kendini geliştiren personeli, büyüme trendinin sürdürülmesi, modern yönetim ilkelerini benimseyerek, teknolojiyle entegre olmuş bir şirket olmak.</p>
				<a href="" class="wow fadeInDown" data-wow-delay="400ms">Daha Fazla Bilgi +</a>
			</div>
		</div>
		<div class="home-box services">
			<div class="container">
				<p class="home-box-slogan wow fadeInUp" data-wow-delay="100ms">Neler Yapıyoruz?</p>
				<h2 class="home-box-title wow fadeInDown" data-wow-delay="100ms">Hizmetlerimiz</h2>
			</div>
			<div style="position: relative;">
				<ul>
					<?php for ($i=1; $i < 8; $i++) { ?>
					<li>
						<a href="" title="" style="background-image: url('media/slideshow.jpg')">
							<article>
								<h3>SOLAR POWER PLANTS</h3>
								<p>YEO Solar delivers Turnkey EPC Solutions to all Solar Projects varying from Roof Mounted, Building Integrated Systems to Ground Mounted Large Scale Power Plants. In addition to the SCADA systems required per Turkish Grid Code, YEO Solar delivers its customers with a custom designed YEOREN software for plant monitoring.</p>
								<span>READ MORE+</span>
							</article>
						</a>
						<h4 class="to-ellipsis">SOLAR POWER PLANT</h4>
					</li>
					<?php } ?>
				</ul>
				<div class="ctrl"></div>
			</div>
		</div>
		<div class="home-box customers">
			<div class="container">
				<p class="home-box-slogan wow fadeInUp" data-wow-delay="100ms">Sizi de aramızda görmek isteriz.</p>
				<h2 class="home-box-title wow fadeInDown" data-wow-delay="100ms">Müşterilerimiz</h2>
				<div class="scope">
					<ul>
						<?php for ($i=0; $i < 15; $i++) { ?>
						<li class="wow fadeIn" data-wow-delay="<?php echo $i; ?>00ms">
							<a href="" title="">
								<div class="cell">
									<img src="media/customers.png" alt="">
								</div>
							</a>
						</li>
						<?php } ?>
					</ul>
					<div class="ctrl"></div>
				</div>
			</div>
		</div>
		<div class="home-box products">
			<div class="container">
				<p class="home-box-slogan wow fadeInUp" data-wow-delay="100ms">Verimli Sistemler için.</p>
				<h2 class="home-box-title wow fadeInDown" data-wow-delay="100ms">Ürünlerimiz</h2>
				<div class="scope">
					<ul>
						<?php for ($i=0; $i < 15; $i++) { ?>
						<li class="item wow fadeInUp" data-wow-delay="<?php echo $i; ?>00ms">
							<h4>RBSReport®</h4>
							<img src="media/product.jpg" width="100%" alt="">
							<p>RBSReport®, bilgi işlem çalışanları ve endüstriyel cihazlardan veri toplamak isteyen uzmanlar için geliştirilmiş Excel® ve Trend raporlama programıdır.</p>
							<a href="" title="">DEVAMINI OKU</a>
						</li>
						<?php } ?>
					</ul>
					<div class="ctrl"></div>
				</div>
			</div>
		</div>
		<?php require_once 'include/footer.php'; ?>
	</body>
</html>