<!DOCTYPE html>
<html lang="tr-TR" dir="ltr">
	<head>
		<?php require_once 'include/head.php'; ?>
	</head>
	<body>
		<?php require_once 'include/header.php'; ?>
		<div class="container content">
			<h4>Yenilikçi Teknolojiler</h4>
			<h2>Kurumsal Kimliğimiz</h2>
			<div class="colgroup">
				<div class="col-hd-6 col-lg-6 col-pv-12">
					<img src="media/slideshow.jpg" width="100%" alt="">
					<br><br>
				</div>
				<div class="col-hd-6 col-lg-6 col-pv-12">
					<div class="normal-text">
						<time>3 OCAK, SALI</time>
						<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it </p>
					</div>
				</div>
			</div>
		</div>
		<?php require_once 'include/footer.php'; ?>
	</body>
</html>