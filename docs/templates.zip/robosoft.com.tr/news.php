<!DOCTYPE html>
<html lang="tr-TR" dir="ltr">
	<head>
		<?php require_once 'include/head.php'; ?>
	</head>
	<body>
		<?php require_once 'include/header.php'; ?>
		<div class="container content news">
			<div class="colgroup col-hd-4 col-lg-4 col-xs-6 col-pv-12">
				<?php for ($i=0; $i < 9; $i++) { ?>
				<div>
					<article>
						<time datetime="2011-01-12">25 <span>ARALIK</span></time>
						<h4>Lorem Ipsum Dolor Sit</h4>
						<img src="media/product.jpg" alt="">
						<p>Lorem Ipsum is simply dummy text of theprinting and typesetting it has the randomised words Lorem ipsum dolor amet consecte tuer adipiscing elit Suspendisse et justo...z</p>
						<a href="haber-detay" title="">DEVAMINI OKU</a>
					</article>
				</div>
				<?php } ?>
			</div>
			<div class="pagination">
				<a href="" class="active">1</a>
				<?php for ($i=2; $i < 9; $i++) { ?>
				<a href=""><?php echo $i; ?></a>
				<?php } ?>
			</div>
		</div>
		<?php require_once 'include/footer.php'; ?>
	</body>
</html>