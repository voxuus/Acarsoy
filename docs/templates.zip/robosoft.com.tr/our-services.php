<!DOCTYPE html>
<html lang="tr-TR" dir="ltr">
	<head>
		<?php require_once 'include/head.php'; ?>
	</head>
	<body>
		<?php require_once 'include/header.php'; ?>
		<script type="text/javascript">
			$(function(){
				App.plugin.services();
			});
		</script>
		<div class="container content">
			<h4>Yenilikçi Teknolojiler</h4>
			<h2>Endüstriyel Hizmetlerimiz  </h2>
			<div class="colgroup col-hd-6 col-lg-6 col-sm-12">
				<div>
					<h5 class="content-title">ENDÜSTRİYEL HİZMETLERİMİZ</h5>
					<div class="normal-text">
						Robosoft® Kontrol firması, endüstriyel tüm sistemlere uygun raporlama ve IT çözümleri vermektedir. Gıda, Arıtma, Enerji, vb. tüm üretim süreçlerini yazılımlarımızla takip edebilirsiniz.
						<br><br>
						Robosoft® Kontrol, öncelikle, verdiği hizmette standardını, hem sektörün hem de müşterisinin isteğine göre belirlemektedir. Robosoft® Kontrol, yüksek kalite yazılımlarıyla sektöre hizmet vermektedir. Bu amaçla geliştirilmiş RBSReport yazılımımızla, endüstriyel tüm sistemlerin verilerini toplayabilir, reçete bazında ve tarih bazında istediğiniz an raporlayabilirsiniz.
					</div>
					<br>
				</div>
				<div>
					<h5 class="content-title">SEKTÖREL ÇALIŞMALARIMIZ</h5>
					<div class="normal-text">
						Robosoft® Kontrol firması, endüstriyel tüm sistemlere uygun raporlama ve IT çözümleri vermektedir. Gıda, Arıtma, Enerji, vb. tüm üretim süreçlerini yazılımlarımızla takip edebilirsiniz.
						<br><br>
						Robosoft® Kontrol, öncelikle, verdiği hizmette standardını, hem sektörün hem de müşterisinin isteğine göre belirlemektedir. Robosoft® Kontrol, yüksek kalite yazılımlarıyla sektöre hizmet vermektedir. Bu amaçla geliştirilmiş RBSReport yazılımımızla, endüstriyel tüm sistemlerin verilerini toplayabilir, reçete bazında ve tarih bazında istediğiniz an raporlayabilirsiniz.
					</div>
				</div>
			</div>
		</div>
		<div class="services" style="position: relative;">
			<ul>
				<?php for ($i=1; $i < 8; $i++) { ?>
				<li>
					<a href="" title="" style="background-image: url('media/slideshow.jpg')">
						<article>
							<h3>SOLAR POWER PLANTS</h3>
							<p>YEO Solar delivers Turnkey EPC Solutions to all Solar Projects varying from Roof Mounted, Building Integrated Systems to Ground Mounted Large Scale Power Plants. In addition to the SCADA systems required per Turkish Grid Code, YEO Solar delivers its customers with a custom designed YEOREN software for plant monitoring.</p>
							<span>READ MORE+</span>
						</article>
					</a>
					<h4 class="to-ellipsis">SOLAR POWER PLANT</h4>
				</li>
				<?php } ?>
			</ul>
			<div class="ctrl"></div>
		</div>		
		<?php require_once 'include/footer.php'; ?>
	</body>
</html>