<!DOCTYPE html>
<html lang="tr-TR" dir="ltr">
	<head>
		<?php require_once 'include/head.php'; ?>
	</head>
	<body>
		<?php require_once 'include/header.php'; ?>
		<div class="container content">
			<div class="products">
				<div class="colgroup col-hd-3 col-lg-3 col-md-4 col-sm-6 col-xs-12">
					<?php for ($i=0; $i < 15; $i++) { ?>
					<div class="item wow fadeInUp" data-wow-delay="<?php echo $i; ?>00ms">
						<h4>RBSReport®</h4>
						<img src="media/product.jpg" width="100%" alt="">
						<p>RBSReport®, bilgi işlem çalışanları ve endüstriyel cihazlardan veri toplamak isteyen uzmanlar için geliştirilmiş Excel® ve Trend raporlama programıdır.</p>
						<a href="" title="">DEVAMINI OKU</a>
					</div>
					<?php } ?>
				</div>
			</div>
		</div>
		<?php require_once 'include/footer.php'; ?>
	</body>
</html>