<!DOCTYPE html>
<html lang="tr-TR" dir="ltr">
	<head>
		<?php require_once 'include/head.php'; ?>
	</head>
	<body>
		<?php require_once 'include/header.php'; ?>
		<div class="container content">
			<?php for ($i=0; $i < 6; $i++) { ?>
			<div class="reference">
				<div class="colgroup col-middle">
					<div class="col-hd-3 col-lg-3 col-sm-4 xs-none-i">
						<img src="media/product.jpg" width="100%" alt="">
					</div>
					<div class="col-hd-6 col-lg-6 col-sm-8 col-xs-12">
						<div class="reference-text">
							<h6>SCHLUMBERGER-EMERSON</h6>
							<p>
								Firmamız Schlumberger ve Emerson firmalarına geliştirmiş olduğu test yazılım sistemi ile BP şirketinin Azerbaycan’daki Shah Deniz projesinde kuyuların ön analizlerinin yapılması sağlanmaktadır. Böylece analizi yapılan petrol veya doğalgaz kuyusu için daha derine inilmesi için kuyu analizleri RBSReport yazılım ve raporlama sisteminden çıkmaktadır. Milyonlarca veri üzerinde çalışan yazılımlarımız ile sistemin saniyelik veri kaydı ve trend analizleri yapılmaktadır.
							</p>
						</div>
					</div>
					<div class="col-hd-3 col-lg-3 sm-none-i">
						<div class="ta-c">
							<img src="media/customers.png" alt="">
						</div>
					</div>
				</div>
			</div>
			<?php } ?>
			<div class="pagination">
				<a href="" title="" class="active">1</a>
				<?php for ($i=2; $i < 9; $i++) { ?>
				<a href="" title=""><?php echo $i; ?></a>
				<?php } ?>
			</div>
		</div>
		<?php require_once 'include/footer.php'; ?>
	</body>
</html>